"""Barreno 3D: software de escritorio para geometría minera 2D/3D."""

NOMBRE_APP = "Barreno 3D"
VERSION = "3.1.0"
