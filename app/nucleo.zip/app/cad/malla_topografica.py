"""
Malla de perforación de tajo abierto sobre la topografía (TIN de curvas de nivel).

- Área de voladura: polígono cerrado (polilínea del CAD) o rectángulo (centro, largo, ancho, azimut).
- Filas paralelas a la cara libre; la 1.ª fila es la más cercana a la cara (dirección de salida).
- Patrón cuadrado/rectangular o tresbolillo (filas alternas desplazadas S/2).
- Cota del collar = cota del TIN en (x, y). Longitud hasta la cota de piso + sobreperforación
  (o altura de banco constante + sobreperforación), corregida por la inclinación.
- Carga = q·(L − taco), q = π/4·dc²·ρe. Retardos por filas (eslabonado) o en V.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from app.cad.topografia import TIN

PATRONES = ["Tresbolillo", "Cuadrada / rectangular"]
SECUENCIAS = ["Fila por fila", "En V (desde el centro)", "Sin retardos"]
MODOS_PISO = ["Hasta la cota de piso", "Altura de banco constante"]


class ErrorMallaTopo(ValueError):
    pass


@dataclass
class EntradaMallaTopo:
    poligono: list[tuple[float, float]]
    burden: float = 4.0
    espaciamiento: float = 4.5
    patron: str = "Tresbolillo"
    azimut_salida: float = 0.0  # ° (hacia donde sale el material: la cara libre)
    margen: float = 1.0  # m, distancia mínima de los taladros al borde del área
    modo_piso: str = "Hasta la cota de piso"
    cota_piso: float = 0.0
    altura_banco: float = 10.0
    sobreperforacion: float = 1.0
    taco: float = 3.0
    inclinacion: float = 90.0  # ° (90 = vertical); inclinado hacia la cara libre
    diametro_mm: float = 165.0
    densidad_explosivo: float = 0.85  # g/cm³
    diametro_carga_mm: float | None = None
    explosivo_id: str | None = None
    secuencia: str = "Fila por fila"
    ms_taladros: float = 25.0
    ms_filas: float = 67.0
    longitud_minima: float = 1.5


@dataclass
class TaladroTopo:
    x: float
    y: float
    z: float
    longitud: float
    fila: int
    orden: int
    carga_kg: float
    altura: float  # m de banco bajo el collar (collar − piso)
    retardo: int = 0
    tiempo_ms: float | None = None


@dataclass
class ResultadoMallaTopo:
    taladros: list[TaladroTopo] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)
    area_m2: float = 0.0
    volumen_m3: float = 0.0
    filas: int = 0

    @property
    def kg(self) -> float:
        return sum(t.carga_kg for t in self.taladros)

    @property
    def metros(self) -> float:
        return sum(t.longitud for t in self.taladros)


def area_poligono(pol) -> float:
    p = np.asarray(pol, float)
    x, y = p[:, 0], p[:, 1]
    return float(abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))) / 2)


def rectangulo(cx: float, cy: float, largo: float, ancho: float, azimut_largo: float) -> list[tuple[float, float]]:
    """Rectángulo centrado; «largo» corre en la dirección azimut_largo (° desde el Norte)."""
    a = math.radians(azimut_largo)
    u = np.array([math.sin(a), math.cos(a)])
    v = np.array([-u[1], u[0]])
    c = np.array([cx, cy])
    return [tuple(c + su * largo / 2 * u + sv * ancho / 2 * v) for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1))]


def _dentro(pol: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
    dentro = np.zeros(x.shape, bool)
    n = len(pol)
    for i in range(n):
        x1, y1 = pol[i]
        x2, y2 = pol[(i + 1) % n]
        cruza = ((y1 > y) != (y2 > y)) & (x < (x2 - x1) * (y - y1) / ((y2 - y1) if y2 != y1 else 1e-12) + x1)
        dentro ^= cruza
    return dentro


def _dist_borde(pol: np.ndarray, x: np.ndarray, y: np.ndarray) -> np.ndarray:
    d = np.full(x.shape, np.inf)
    n = len(pol)
    for i in range(n):
        a, b = pol[i], pol[(i + 1) % n]
        ab = b - a
        L2 = float(ab @ ab) or 1e-12
        t = np.clip(((x - a[0]) * ab[0] + (y - a[1]) * ab[1]) / L2, 0, 1)
        d = np.minimum(d, np.hypot(x - (a[0] + t * ab[0]), y - (a[1] + t * ab[1])))
    return d


def cotas(tin: TIN, xs, ys) -> np.ndarray:
    """Cota del TIN en cada punto (nan fuera de la superficie)."""
    return np.array([np.nan if (z := tin.cota(float(x), float(y))) is None else z for x, y in zip(xs, ys)])


def azimut_pendiente(tin: TIN, poligono) -> float | None:
    """Sugerencia de dirección de salida: hacia donde el terreno cae más justo fuera del área (la cara del
    banco); si alrededor es plano, hacia donde baja el plano ajustado dentro del área."""
    pol = np.asarray(poligono, float)
    c = pol.mean(axis=0)
    caidas_az = {}
    for az in range(0, 360, 5):
        a = math.radians(az)
        d = np.array([math.sin(a), math.cos(a)])
        ts = np.linspace(0, 4 * float(np.ptp(pol, axis=0).max()) + 1, 400)
        pts = c + ts[:, None] * d
        dentro = _dentro(pol, pts[:, 0], pts[:, 1])
        if not dentro.any():
            continue
        t_borde = ts[np.nonzero(dentro)[0].max()]
        borde = c + t_borde * d
        z0 = tin.cota(*borde)
        if z0 is None:
            continue
        caidas = [z0 - z for k in (5.0, 10.0, 20.0) if (z := tin.cota(*(borde + k * d))) is not None]
        if caidas:
            caidas_az[az] = max(caidas)
    mejor = None
    if caidas_az and max(caidas_az.values()) >= 2.0:
        tope = max(caidas_az.values())
        sel = [(az, c) for az, c in caidas_az.items() if c >= 0.85 * tope]
        sx = sum(c * math.sin(math.radians(az)) for az, c in sel)
        sy = sum(c * math.cos(math.radians(az)) for az, c in sel)
        return math.degrees(math.atan2(sx, sy)) % 360
    xs = np.linspace(pol[:, 0].min(), pol[:, 0].max(), 15)
    ys = np.linspace(pol[:, 1].min(), pol[:, 1].max(), 15)
    X, Y = np.meshgrid(xs, ys)
    m = _dentro(pol, X, Y)
    X, Y = X[m], Y[m]
    Z = cotas(tin, X, Y)
    ok = np.isfinite(Z)
    if ok.sum() < 3:
        return mejor
    A = np.c_[X[ok], Y[ok], np.ones(ok.sum())]
    (a, b, _), *_ = np.linalg.lstsq(A, Z[ok], rcond=None)
    if math.hypot(a, b) < 1e-4:
        return mejor
    return math.degrees(math.atan2(-a, -b)) % 360


def generar(e: EntradaMallaTopo, tin: TIN) -> ResultadoMallaTopo:
    if len(e.poligono) < 3:
        raise ErrorMallaTopo("El área de voladura necesita al menos 3 vértices")
    for nombre, v in (("El burden", e.burden), ("El espaciamiento", e.espaciamiento), ("El diámetro", e.diametro_mm)):
        if v <= 0:
            raise ErrorMallaTopo(f"{nombre} debe ser mayor que cero")
    if not 45 <= e.inclinacion <= 90:
        raise ErrorMallaTopo("La inclinación debe estar entre 45° y 90° (90° = vertical)")
    pol = np.asarray(e.poligono, float)
    r = ResultadoMallaTopo(area_m2=area_poligono(pol))
    a = math.radians(e.azimut_salida)
    salida = np.array([math.sin(a), math.cos(a)])  # hacia la cara libre
    lado = np.array([salida[1], -salida[0]])  # a lo largo de las filas
    c = pol.mean(axis=0)
    rel = pol - c
    pu, pv = rel @ lado, rel @ salida
    v_cara = pv.max()
    # filas: desde la cara libre hacia atrás
    filas = []
    v = v_cara - e.margen
    while v >= pv.min() + e.margen - 1e-9:
        filas.append(v)
        v -= e.burden
    if not filas:
        raise ErrorMallaTopo("El área es más angosta que dos márgenes: reduce el margen o agranda el área")
    u0 = pu.min()
    n_u = int(math.ceil((pu.max() - u0) / e.espaciamiento)) + 2

    def validos(us, vf):
        xs = c[0] + us * lado[0] + vf * salida[0]
        ys = c[1] + us * lado[1] + vf * salida[1]
        return _dentro(pol, xs, ys) & (_dist_borde(pol, xs, ys) >= e.margen - 1e-6)

    # centrado: un solo corrimiento para toda la malla (así el tresbolillo se conserva)
    base = u0 + np.arange(-1, n_u) * e.espaciamiento
    ok0 = validos(base, filas[0])
    ajuste = 0.0
    if ok0.any():
        lmin, lmax = _limites_fila(pol, c, lado, salida, filas[0], e.margen)
        ajuste = ((lmin - base[ok0].min()) + (lmax - base[ok0].max())) / 2
        if not validos(base[ok0] + ajuste, filas[0]).all():
            ajuste = 0.0
    cand = []
    for f, vf in enumerate(filas):
        desfase = e.espaciamiento / 2 if (e.patron == "Tresbolillo" and f % 2 == 1) else 0.0
        us = base + ajuste + desfase
        libres = us[validos(us, vf)]
        for k, u in enumerate(sorted(libres)):
            cand.append((f, k, c[0] + u * lado[0] + vf * salida[0], c[1] + u * lado[1] + vf * salida[1], u))
    if not cand:
        raise ErrorMallaTopo("No entra ningún taladro: reduce burden, espaciamiento o margen")
    zs = cotas(tin, [p[2] for p in cand], [p[3] for p in cand])
    sen = math.sin(math.radians(e.inclinacion))
    dc = (e.diametro_carga_mm or e.diametro_mm) / 1000
    q = math.pi / 4 * dc * dc * e.densidad_explosivo * 1000
    fuera = cortos = 0
    us_tal = []
    for (f, k, x, y, u), z in zip(cand, zs):
        if not np.isfinite(z):
            fuera += 1
            continue
        h = (z - e.cota_piso) if e.modo_piso == MODOS_PISO[0] else e.altura_banco
        L = (h + e.sobreperforacion) / sen
        if h <= 0 or L < e.longitud_minima or L <= e.taco:
            cortos += 1
            continue
        r.taladros.append(TaladroTopo(x=round(float(x), 3), y=round(float(y), 3), z=round(float(z), 3), longitud=round(float(L), 2),
                                      fila=f + 1, orden=k + 1, carga_kg=round(float(q * (L - e.taco)), 2),
                                      altura=round(float(h), 2)))
        us_tal.append(u)
    if fuera:
        r.avisos.append(f"{fuera} posiciones quedaron fuera de la superficie TIN y no se colocaron.")
    if cortos:
        r.avisos.append(f"{cortos} posiciones tienen el collar por debajo o muy cerca de la cota de piso "
                        f"(longitud < {max(e.longitud_minima, e.taco):.1f} m) y no se colocaron.")
    if not r.taladros:
        raise ErrorMallaTopo("Ningún taladro tiene altura de banco: revisa la cota de piso y la superficie")
    r.filas = len({t.fila for t in r.taladros})
    r.volumen_m3 = sum(e.burden * e.espaciamiento * t.altura for t in r.taladros)
    alturas = [t.altura for t in r.taladros]
    if max(alturas) - min(alturas) > 0.5 * max(alturas):
        r.avisos.append(f"La altura de banco varía mucho ({min(alturas):.1f}–{max(alturas):.1f} m): revisa la "
                        "cota de piso o divide el área.")
    _retardos(r, e, us_tal)
    return r


def _limites_fila(pol, c, lado, salida, vf, margen):
    """Extremos (u) de la fila dentro del área, descontando el margen (muestreo fino)."""
    rel = pol - c
    pu = rel @ lado
    us = np.linspace(pu.min() - 1, pu.max() + 1, 600)
    xs = c[0] + us * lado[0] + vf * salida[0]
    ys = c[1] + us * lado[1] + vf * salida[1]
    ok = _dentro(pol, xs, ys) & (_dist_borde(pol, xs, ys) >= margen)
    if not ok.any():
        return 0.0, 0.0
    return float(us[ok].min()), float(us[ok].max())


def _retardos(r: ResultadoMallaTopo, e: EntradaMallaTopo, us: list[float]) -> None:
    if e.secuencia == SECUENCIAS[2]:
        return
    tiempos = []
    uc = (min(us) + max(us)) / 2
    for t, u in zip(r.taladros, us):
        if e.secuencia == SECUENCIAS[1]:
            pasos = round(abs(u - uc) / e.espaciamiento)
        else:
            pasos = t.orden - 1
        tiempos.append((t.fila - 1) * e.ms_filas + pasos * e.ms_taladros)
    distintos = {v: k + 1 for k, v in enumerate(sorted(set(round(x, 3) for x in tiempos)))}
    for t, ms in zip(r.taladros, tiempos):
        t.tiempo_ms = round(ms, 3)
        t.retardo = distintos[round(ms, 3)]
