"""
Datos del frente para el simulador 3D, tomados del proyecto (sin inventar).

Marco local del simulador (m):
  X = horizontal sobre el frente (positivo a la derecha mirando al frente),
  Y = avance (positivo hacia dentro de la roca; el frente está en Y = 0),
  Z = altura desde el piso de la labor.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from app.core.modelo import Contorno, Perforacion, Proyecto
from app.core.resultados import carga_de_pozo

COLORES_FUNCION = {
    "Alivio": "#f2f2f2", "Arranque": "#ffd23f", "Ayuda": "#ff8c1a", "Contorno": "#2bb3a8",
    "Corona": "#3a8dde", "Arrastre": "#b06cff",
}


class ErrorSimulacion(Exception):
    pass


@dataclass
class TaladroSim:
    id: str
    x: float
    z: float
    direccion: np.ndarray  # unitario, marco local
    longitud: float
    diametro_mm: float
    alivio: bool
    funcion: str
    retardo: int
    tiempo_ms: float | None
    carga_kg: float
    longitud_carga: float
    taco: float
    explosivo: str
    cartuchos: int
    color_explosivo: str = "#ff8c1a"

    def collar(self) -> np.ndarray:
        return np.array([self.x, 0.0, self.z])

    def fondo(self) -> np.ndarray:
        return self.collar() + self.direccion * self.longitud


@dataclass
class FrenteSim:
    nombre: str
    seccion: list[tuple[float, float]]  # polígono (x, z) en sentido antihorario
    taladros: list[TaladroSim]
    avance: float  # m (del diseño del proyecto)
    densidad_roca: float
    origen: str = ""  # "documental", "automático" ...
    avisos: list[str] = field(default_factory=list)

    @property
    def ancho(self) -> float:
        xs = [p[0] for p in self.seccion]
        return max(xs) - min(xs)

    @property
    def alto(self) -> float:
        zs = [p[1] for p in self.seccion]
        return max(zs) - min(zs)

    def longitud_perforacion(self) -> float:
        return max((t.longitud for t in self.taladros), default=self.avance)

    def orden_salida(self) -> list[float]:
        """Instante relativo de salida de cada taladro (0–1).

        Si el proyecto tiene tiempos (ms) se usan; si solo hay N.º de retardo, se usa
        su ORDEN (rango) con separación uniforme: no es una escala de tiempo real.
        """
        cargados = [t for t in self.taladros if not t.alivio]
        if cargados and all(t.tiempo_ms is not None for t in cargados):
            tmax = max(t.tiempo_ms for t in cargados) or 1.0
            return [0.0 if t.alivio else (t.tiempo_ms / tmax) for t in self.taladros]
        valores = sorted({t.retardo for t in cargados})
        rango = {v: i for i, v in enumerate(valores)}
        n = max(len(valores) - 1, 1)
        return [0.0 if t.alivio else rango[t.retardo] / n for t in self.taladros]

    def escala_tiempo_real(self) -> bool:
        cargados = [t for t in self.taladros if not t.alivio]
        return bool(cargados) and all(t.tiempo_ms is not None for t in cargados)


def _casco_convexo(pts):
    pts = sorted(set(pts))
    if len(pts) < 3:
        return pts

    def cruz(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    inf, sup = [], []
    for p in pts:
        while len(inf) >= 2 and cruz(inf[-2], inf[-1], p) <= 0:
            inf.pop()
        inf.append(p)
    for p in reversed(pts):
        while len(sup) >= 2 and cruz(sup[-2], sup[-1], p) <= 0:
            sup.pop()
        sup.append(p)
    return inf[:-1] + sup[:-1]


def casco_convexo(pts):
    return _casco_convexo([tuple(map(float, p)) for p in pts])


def frente_desde_proyecto(proyecto: Proyecto) -> FrenteSim:
    pozos = proyecto.perforaciones()
    if not pozos:
        raise ErrorSimulacion("El proyecto no tiene perforaciones. Crea una malla (automática o de la "
                              "biblioteca) antes de simular.")
    horizontales = [p for p in pozos if abs(p.inclinacion) < 30]
    if len(horizontales) < len(pozos) * 0.8:
        raise ErrorSimulacion("El simulador 3D de jumbo es para frentes subterráneos (taladros casi "
                              "horizontales). Para tajo abierto usa Análisis → Simular voladura.")
    # dirección de avance media (horizontal) y eje lateral
    d = np.mean([p.direccion() for p in horizontales], axis=0)
    d[2] = 0.0
    d /= np.linalg.norm(d) or 1.0
    u = np.array([d[1], -d[0], 0.0])  # a la derecha mirando en la dirección de avance
    z_piso = None
    contornos = [o for o in proyecto.objetos.values() if isinstance(o, Contorno) and len(o.vertices) >= 3]
    base = np.array(pozos[0].collar(), dtype=float)
    seccion = None
    if contornos:
        c = max(contornos, key=lambda c: c.area())
        v = np.asarray(c.vertices, dtype=float)
        s = (v - base) @ u
        seccion = list(zip(s, v[:, 2]))
        z_piso = float(v[:, 2].min())
    col = np.array([p.collar() for p in pozos], dtype=float)
    s_pozos = (col - base) @ u
    if seccion is None:
        z_piso = float(col[:, 2].min())
        margen = 0.15
        seccion = [(s_pozos.min() - margen, z_piso), (s_pozos.max() + margen, z_piso),
                   (s_pozos.max() + margen, col[:, 2].max() + margen), (s_pozos.min() - margen, col[:, 2].max() + margen)]
        avisos = ["El proyecto no tiene contorno de sección: se usó el rectángulo que envuelve los taladros."]
    else:
        avisos = []
    # centrar en X (eje de la labor) y llevar el piso a Z = 0
    xs = [p[0] for p in seccion]
    xc = (min(xs) + max(xs)) / 2
    seccion = [(round(x - xc, 4), round(z - z_piso, 4)) for x, z in seccion]
    # orientar antihorario
    area = sum(x1 * z2 - x2 * z1 for (x1, z1), (x2, z2) in zip(seccion, seccion[1:] + seccion[:1]))
    if area < 0:
        seccion.reverse()
    # posición de la cara del frente (Y = 0) = collar medio sobre el eje de avance
    y_cara = float(np.median((col - base) @ d))
    tal = []
    for p, s in zip(pozos, s_pozos):
        c = carga_de_pozo(proyecto, p)
        dir_g = np.array(p.direccion(), dtype=float)
        dir_l = np.array([dir_g @ u, dir_g @ d, dir_g[2]])
        n = np.linalg.norm(dir_l)
        dir_l = dir_l / n if n else np.array([0, 1.0, 0])
        exp = proyecto.explosivo(p.explosivo_id)
        tal.append(TaladroSim(
            id=p.id, x=float(s - xc), z=float(p.z - z_piso), direccion=dir_l, longitud=p.longitud,
            diametro_mm=p.diametro_mm, alivio=(p.explosivo_id is None or p.funcion == "Alivio"),
            funcion=p.funcion, retardo=int(p.retardo or 0), tiempo_ms=p.tiempo_ms,
            carga_kg=c.carga if c.cargado else 0.0, longitud_carga=c.longitud_carga if c.cargado else 0.0,
            taco=p.taco, explosivo=exp.nombre if exp else "", cartuchos=int(getattr(p, "cartuchos", 0) or 0),
            color_explosivo=COLORES_FUNCION.get(p.funcion, "#ff8c1a")))
        if abs(float(((col[pozos.index(p)] - base) @ d)) - y_cara) > 0.3:
            avisos.append(f"{p.id}: su boca no está en el plano del frente (se proyecta).")
    origen = "Referencia documental" if any(getattr(p, "origen", "") for p in pozos) else "Diseño del proyecto"
    return FrenteSim(nombre=proyecto.nombre, seccion=seccion, taladros=tal,
                     avance=float(proyecto.diseno.avance), densidad_roca=float(proyecto.diseno.densidad_roca),
                     origen=origen, avisos=avisos[:8])


def punto_en_poligono(x: float, z: float, poli) -> bool:
    dentro = False
    n = len(poli)
    for i in range(n):
        x1, z1 = poli[i]; x2, z2 = poli[(i + 1) % n]
        if (z1 > z) != (z2 > z):
            xi = x1 + (z - z1) * (x2 - x1) / (z2 - z1)
            if x < xi:
                dentro = not dentro
    return dentro


def distancia_a_poligono(x: float, z: float, poli) -> float:
    best = math.inf
    n = len(poli)
    for i in range(n):
        (x1, z1), (x2, z2) = poli[i], poli[(i + 1) % n]
        dx, dz = x2 - x1, z2 - z1
        L2 = dx * dx + dz * dz
        t = 0 if L2 == 0 else max(0, min(1, ((x - x1) * dx + (z - z1) * dz) / L2))
        best = min(best, math.hypot(x - x1 - t * dx, z - z1 - t * dz))
    return best
