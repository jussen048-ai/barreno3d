"""
Predicción de fragmentación por voladura.

Modelos:
- Kuz-Ram (Cunningham 1983, 1987; ver Cunningham 2005 «The Kuz-Ram fragmentation model –
  20 years on»):
    x50 [cm] = A · K^-0.8 · Q^(1/6) · (115 / RWS)^(19/20)
      A   = factor de roca (Cunningham 1987): A = 0.06·(RMD + JF + RDI + HF)
      K   = factor de carga [kg/m³];  Q = explosivo por taladro [kg]
      RWS = potencia relativa en peso respecto al ANFO (ANFO = 100)
    Índice de uniformidad (Cunningham 1987):
      n = (2.2 − 14·B/d) · √((1 + S/B)/2) · (1 − W/B) · (|BCL − CCL|/L + 0.1)^0.1 · L/H
      B, S [m]; d [mm]; W desviación estándar de perforación [m]; L longitud de carga [m];
      BCL, CCL longitudes de carga de fondo y de columna [m]; H altura de banco o longitud del taladro [m].
    Curva Rosin-Rammler: P(x) = 1 − exp(−ln2 · (x/x50)^n)
- Swebrec (Ouchterlony 2005): P(x) = 1 / (1 + [ln(xmax/x) / ln(xmax/x50)]^b),  x < xmax
    Modelo KCO: b = 2·ln2·ln(xmax/x50)·n   (enlaza la curvatura con la uniformidad de Kuz-Ram)
- Ajuste a datos medidos (tamizado o análisis de imágenes): mínimos cuadrados (Nelder–Mead).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

LN2 = math.log(2.0)


class ErrorFragmentacion(ValueError):
    pass


# ---------------------------------------------------------------- factor de roca (Cunningham 1987)
RMD = {"Pulverulenta / friable": 10.0, "Diaclasada verticalmente": None, "Masiva": 50.0}
JPS = {"< 0.1 m": 10.0, "0.1 m a tamaño de malla": 20.0, "> tamaño de malla": 50.0}
JPA = {"Buzamiento hacia fuera del frente": 20.0, "Rumbo perpendicular al frente": 30.0,
       "Buzamiento hacia dentro del frente": 40.0}


def factor_roca(rmd: str, jps: str, jpa: str, densidad_t_m3: float, ucs_mpa: float, e_gpa: float) -> dict:
    """Factor de roca A de Cunningham (1987). Devuelve los componentes y A."""
    jf = JPS[jps] + JPA[jpa]
    rmd_v = RMD[rmd] if RMD[rmd] is not None else jf
    rdi = 25.0 * densidad_t_m3 - 50.0
    hf = e_gpa / 3.0 if e_gpa < 50.0 else ucs_mpa / 5.0
    a = 0.06 * (rmd_v + jf + rdi + hf)
    return {"RMD": rmd_v, "JF": jf if RMD[rmd] is None else 0.0, "RDI": rdi, "HF": hf, "A": a}


# ---------------------------------------------------------------- Kuz-Ram
@dataclass
class EntradaKuzRam:
    a_roca: float = 7.0
    factor_carga: float = 0.6  # kg/m³
    carga_taladro: float = 100.0  # kg
    rws: float = 100.0  # ANFO = 100
    burden: float = 3.0  # m
    espaciamiento: float = 3.5  # m
    diametro_mm: float = 102.0
    desviacion: float = 0.2  # m (W)
    long_carga: float = 8.0  # m (L)
    carga_fondo: float = 0.0  # m (BCL)
    carga_columna: float = 8.0  # m (CCL)
    altura: float = 10.0  # m (H)
    xmax_mm: float | None = None  # si None: min(B, S) (tamaño de bloque in situ máximo, Ouchterlony)


@dataclass
class ResultadoFrag:
    x50_mm: float
    n: float
    xc_mm: float
    xmax_mm: float
    b: float
    x80_rr_mm: float
    x80_sw_mm: float
    pasos: list[tuple[str, str]] = field(default_factory=list)


def x50_kuznetsov(a: float, k: float, q: float, rws: float) -> float:
    """x50 en mm."""
    if a <= 0 or k <= 0 or q <= 0 or rws <= 0:
        raise ErrorFragmentacion("A, K, Q y RWS deben ser mayores que cero")
    return 10.0 * a * k ** -0.8 * q ** (1 / 6) * (115.0 / rws) ** (19 / 20)


def uniformidad_cunningham(e: EntradaKuzRam) -> float:
    if e.burden <= 0 or e.diametro_mm <= 0 or e.long_carga <= 0 or e.altura <= 0:
        raise ErrorFragmentacion("B, d, L y H deben ser mayores que cero")
    n = ((2.2 - 14.0 * e.burden / e.diametro_mm) * math.sqrt((1 + e.espaciamiento / e.burden) / 2)
         * (1 - e.desviacion / e.burden) * (abs(e.carga_fondo - e.carga_columna) / e.long_carga + 0.1) ** 0.1
         * e.long_carga / e.altura)
    return n


def pasante_rosin(x, x50: float, n: float):
    x = np.asarray(x, float)
    return 1.0 - np.exp(-LN2 * (x / x50) ** n)


def tamano_rosin(p: float, x50: float, n: float) -> float:
    """Tamaño para una fracción pasante p (0–1)."""
    return x50 * (math.log(1 / (1 - p)) / LN2) ** (1 / n)


def pasante_swebrec(x, x50: float, xmax: float, b: float):
    x = np.asarray(x, float)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.log(xmax / np.clip(x, 1e-9, None)) / math.log(xmax / x50)
        p = 1.0 / (1.0 + np.clip(r, 0, None) ** b)
    return np.where(x >= xmax, 1.0, p)


def tamano_swebrec(p: float, x50: float, xmax: float, b: float) -> float:
    return xmax * math.exp(-math.log(xmax / x50) * ((1 - p) / p) ** (1 / b))


def b_kco(x50: float, xmax: float, n: float) -> float:
    return 2 * LN2 * math.log(xmax / x50) * n


def kuz_ram(e: EntradaKuzRam) -> ResultadoFrag:
    x50 = x50_kuznetsov(e.a_roca, e.factor_carga, e.carga_taladro, e.rws)
    n = uniformidad_cunningham(e)
    if n <= 0:
        raise ErrorFragmentacion(f"El índice de uniformidad salió {n:.2f} (≤ 0): revisa B/d y la desviación W")
    xmax = e.xmax_mm or 1000.0 * min(e.burden, e.espaciamiento)
    if xmax <= x50:
        raise ErrorFragmentacion("xmax debe ser mayor que x50")
    b = b_kco(x50, xmax, n)
    xc = x50 / LN2 ** (1 / n)
    pasos = [
        ("x50 = A·K^-0.8·Q^(1/6)·(115/RWS)^(19/20)",
         f"{e.a_roca:.2f}·{e.factor_carga:.3f}^-0.8·{e.carga_taladro:.1f}^(1/6)·(115/{e.rws:.0f})^0.95 = {x50 / 10:.2f} cm"),
        ("n = (2.2−14B/d)·√((1+S/B)/2)·(1−W/B)·(|BCL−CCL|/L+0.1)^0.1·L/H", f"{n:.3f}"),
        ("xc = x50 / (ln2)^(1/n)", f"{xc:.0f} mm"),
        ("b (KCO) = 2·ln2·ln(xmax/x50)·n", f"{b:.3f}  (xmax = {xmax:.0f} mm)"),
    ]
    return ResultadoFrag(x50_mm=x50, n=n, xc_mm=xc, xmax_mm=xmax, b=b,
                         x80_rr_mm=tamano_rosin(0.8, x50, n), x80_sw_mm=tamano_swebrec(0.8, x50, xmax, b), pasos=pasos)


# ---------------------------------------------------------------- ajuste a datos medidos
def _nelder_mead(f, x0, paso, iters=600, tol=1e-10):
    n = len(x0)
    simplex = [np.array(x0, float)]
    for i in range(n):
        v = np.array(x0, float)
        v[i] += paso[i]
        simplex.append(v)
    valores = [f(v) for v in simplex]
    for _ in range(iters):
        orden = np.argsort(valores)
        simplex = [simplex[i] for i in orden]
        valores = [valores[i] for i in orden]
        if abs(valores[-1] - valores[0]) < tol:
            break
        centro = np.mean(simplex[:-1], axis=0)
        r = centro + (centro - simplex[-1])
        fr = f(r)
        if fr < valores[0]:
            e = centro + 2 * (centro - simplex[-1])
            fe = f(e)
            simplex[-1], valores[-1] = (e, fe) if fe < fr else (r, fr)
        elif fr < valores[-2]:
            simplex[-1], valores[-1] = r, fr
        else:
            c = centro + 0.5 * (simplex[-1] - centro)
            fc = f(c)
            if fc < valores[-1]:
                simplex[-1], valores[-1] = c, fc
            else:
                for i in range(1, n + 1):
                    simplex[i] = simplex[0] + 0.5 * (simplex[i] - simplex[0])
                    valores[i] = f(simplex[i])
    k = int(np.argmin(valores))
    return simplex[k], valores[k]


def ajustar_swebrec(x_mm, pasante_pct) -> tuple[float, float, float, float]:
    """Ajusta x50, xmax y b a datos medidos. Devuelve (x50, xmax, b, R²)."""
    x = np.asarray(x_mm, float)
    p = np.asarray(pasante_pct, float) / 100.0
    ok = (x > 0) & (p > 0) & (p < 1)
    x, p = x[ok], p[ok]
    if len(x) < 3:
        raise ErrorFragmentacion("Se necesitan al menos 3 puntos con pasante entre 0 % y 100 %")
    x50_0 = float(np.interp(0.5, np.sort(p), x[np.argsort(p)]))
    xmax_0 = float(x.max() * 1.3)

    def costo(v):
        lx50, lr, b = v
        x50 = math.exp(lx50)
        xmax = x50 * (1 + math.exp(lr))
        if b <= 0.05 or b > 20:
            return 1e9
        if np.any(x >= xmax):
            return 1e9 + float(np.sum(x >= xmax))
        return float(np.sum((pasante_swebrec(x, x50, xmax, b) - p) ** 2))

    v0 = [math.log(max(x50_0, 1e-3)), math.log(max(xmax_0 / max(x50_0, 1e-3) - 1, 0.05)), 2.0]
    mejor, _ = _nelder_mead(costo, v0, [0.3, 0.5, 0.5])
    x50 = math.exp(mejor[0]); xmax = x50 * (1 + math.exp(mejor[1])); b = float(mejor[2])
    pred = pasante_swebrec(x, x50, xmax, b)
    ss_res = float(np.sum((pred - p) ** 2)); ss_tot = float(np.sum((p - p.mean()) ** 2)) or 1e-12
    return x50, xmax, b, 1 - ss_res / ss_tot


def ajustar_rosin(x_mm, pasante_pct) -> tuple[float, float, float]:
    """Ajuste lineal de Rosin-Rammler: ln(−ln(1−P)) = n·ln x − n·ln xc. Devuelve (x50, n, R²)."""
    x = np.asarray(x_mm, float)
    p = np.asarray(pasante_pct, float) / 100.0
    ok = (x > 0) & (p > 0) & (p < 1)
    if ok.sum() < 2:
        raise ErrorFragmentacion("Se necesitan al menos 2 puntos con pasante entre 0 % y 100 %")
    X = np.log(x[ok]); Y = np.log(-np.log(1 - p[ok]))
    n, c = np.polyfit(X, Y, 1)
    xc = math.exp(-c / n)
    x50 = xc * LN2 ** (1 / n)
    pred = np.polyval([n, c], X)
    r2 = 1 - float(np.sum((pred - Y) ** 2)) / (float(np.sum((Y - Y.mean()) ** 2)) or 1e-12)
    return x50, float(n), r2


def tamices_log(xmin=1.0, xmax=2000.0, n=60):
    return np.geomspace(xmin, xmax, n)
