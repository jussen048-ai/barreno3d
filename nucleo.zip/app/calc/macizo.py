"""
Caracterización del macizo rocoso.

- RMR89 (Bieniawski 1989): suma de 5 parámetros + ajuste por orientación de discontinuidades.
- Q de Barton (1974): Q = (RQD/Jn)·(Jr/Ja)·(Jw/SRF);  correlación RMR ≈ 9·ln Q + 44 (Bieniawski 1976).
- GSI ≈ RMR89 − 5 (Hoek, para RMR89 > 23).
- Módulo de deformación del macizo Em:
    Bieniawski (1978):            Em = 2·RMR − 100              [GPa]  (RMR > 50)
    Serafim y Pereira (1983):     Em = 10^((RMR − 10)/40)       [GPa]
    Nicholson y Bieniawski (1990): Em = Ei·(0.0028·RMR² + 0.9·e^(RMR/22.82))/100
    Hoek y Diederichs (2006):     Em = 100 000·(1 − D/2)/(1 + e^((75 + 25D − GSI)/11))  [MPa]
    Junta equivalente (Galera et al.): 1/Em = 1/Er + 1/(kn·s)
- Hoek-Brown generalizado (2002): mb, s, a.
- Carga de roca (Unal 1983): hp = (100 − RMR)/100 · B.
- Longitud de perno (Barton): L = 2 + 0.15·B/ESR.
"""

from __future__ import annotations

import math

# --- valoraciones RMR89 (Bieniawski 1989), tablas por intervalos
def puntaje_ucs(ucs_mpa: float) -> int:
    for lim, p in ((250, 15), (100, 12), (50, 7), (25, 4), (5, 2), (1, 1)):
        if ucs_mpa > lim:
            return p
    return 0


def puntaje_rqd(rqd: float) -> int:
    for lim, p in ((90, 20), (75, 17), (50, 13), (25, 8)):
        if rqd >= lim:
            return p
    return 3


def puntaje_espaciado(esp_m: float) -> int:
    for lim, p in ((2.0, 20), (0.6, 15), (0.2, 10), (0.06, 8)):
        if esp_m > lim:
            return p
    return 5


CONDICION_JUNTAS = {
    "Muy rugosas, sin continuidad, cerradas, roca sana": 30,
    "Ligeramente rugosas, abertura < 1 mm, paredes ligeramente alteradas": 25,
    "Ligeramente rugosas, abertura < 1 mm, paredes muy alteradas": 20,
    "Espejos de falla o relleno < 5 mm o abertura 1–5 mm, continuas": 10,
    "Relleno blando > 5 mm o abertura > 5 mm, continuas": 0,
}
AGUA = {"Completamente seco": 15, "Húmedo": 10, "Mojado": 7, "Goteo": 4, "Flujo": 0}
ORIENTACION_TUNEL = {"Muy favorable": 0, "Favorable": -2, "Regular": -5, "Desfavorable": -10, "Muy desfavorable": -12}


def rmr89(ucs_mpa, rqd, esp_m, condicion, agua, orientacion="Muy favorable") -> dict:
    p = {"Resistencia (UCS)": puntaje_ucs(ucs_mpa), "RQD": puntaje_rqd(rqd), "Espaciado": puntaje_espaciado(esp_m),
         "Condición de juntas": CONDICION_JUNTAS[condicion], "Agua": AGUA[agua]}
    basico = sum(p.values())
    ajuste = ORIENTACION_TUNEL[orientacion]
    p["RMR básico"] = basico
    p["Ajuste por orientación"] = ajuste
    p["RMR89"] = max(0, basico + ajuste)
    return p


def clase(rmr: float) -> str:
    for lim, c in ((81, "I – Muy buena"), (61, "II – Buena"), (41, "III – Regular"), (21, "IV – Mala")):
        if rmr >= lim:
            return c
    return "V – Muy mala"


def q_barton(rqd, jn, jr, ja, jw, srf) -> float:
    if jn <= 0 or ja <= 0 or srf <= 0:
        raise ValueError("Jn, Ja y SRF deben ser mayores que cero")
    return max(rqd, 10) / jn * jr / ja * jw / srf


def rmr_desde_q(q: float) -> float:
    return 9 * math.log(q) + 44


def q_desde_rmr(rmr: float) -> float:
    return math.exp((rmr - 44) / 9)


def gsi_desde_rmr(rmr89: float) -> float:
    return rmr89 - 5


def em_bieniawski(rmr: float) -> float | None:
    return 2 * rmr - 100 if rmr > 50 else None


def em_serafim(rmr: float) -> float:
    return 10 ** ((rmr - 10) / 40)


def em_nicholson(rmr: float, ei_gpa: float) -> float:
    return ei_gpa * (0.0028 * rmr ** 2 + 0.9 * math.exp(rmr / 22.82)) / 100


def em_hoek_diederichs(gsi: float, d: float = 0.0) -> float:
    return 100000 * (1 - d / 2) / (1 + math.exp((75 + 25 * d - gsi) / 11)) / 1000  # GPa


def em_junta_equivalente(er_gpa: float, kn_gpa_m: float, s_m: float) -> float:
    return 1 / (1 / er_gpa + 1 / (kn_gpa_m * s_m))


def hoek_brown(gsi: float, mi: float, d: float = 0.0) -> dict:
    mb = mi * math.exp((gsi - 100) / (28 - 14 * d))
    s = math.exp((gsi - 100) / (9 - 3 * d))
    a = 0.5 + (math.exp(-gsi / 15) - math.exp(-20 / 3)) / 6
    return {"mb": mb, "s": s, "a": a}


def carga_unal(rmr: float, ancho: float) -> float:
    return (100 - rmr) / 100 * ancho


ESR = {"Labores temporales": 3.0, "Labores permanentes": 1.6, "Rampas y accesos principales": 1.3,
       "Cámaras y obras de larga vida": 1.0}


def longitud_perno(ancho: float, esr: float) -> float:
    return 2 + 0.15 * ancho / esr
