"""
Cálculos de carga explosiva (versión 1).

FICHA TÉCNICA
=============
Requisitos
    Calcular para tajo abierto y minería subterránea:
    carga lineal, carga por pozo, volumen y tonelaje arrancado,
    factor de carga (kg/m³) y factor de potencia (kg/t).

Fuentes técnicas (relaciones geométricas y definiciones estándar)
    - López Jimeno, C., López Jimeno, E., García Bermúdez, P. "Manual de
      Perforación y Voladura de Rocas". Instituto Geológico y Minero de España.
    - Konya, C. J., Walter, E. J. "Rock Blasting and Overbreak Control".
      U.S. Federal Highway Administration (FHWA-HI-92-001).

Unidades
    Diámetros en mm, longitudes en m, densidad del explosivo en g/cm³,
    densidad de la roca en t/m³, cargas en kg, volúmenes en m³, masas en t.

Fórmulas
    Carga lineal       q  = (π/4) · (d/1000)² · (ρe · 1000)          [kg/m]
                          (equivale a 0.000785 · ρe · d², d en mm)
    Carga por pozo     Q  = q · Lc ,  Lc = L − taco                   [kg]
    Volumen (tajo)     V  = B · S · H   por pozo                      [m³]
    Volumen (subt.)    V  = A · avance  por disparo                   [m³]
    Tonelaje           T  = V · ρr                                    [t]
    Factor de carga    FC = Q / V                                     [kg/m³]
    Factor de potencia FP = Q / T                                     [kg/t]

Supuestos
    - Explosivo a granel: llena todo el diámetro del pozo (acoplado).
    - Explosivo encartuchado: columna continua de cartuchos, sin espacios;
      se usa el diámetro del cartucho, no el del pozo.
    - Una sola columna de carga por pozo (sin cargas espaciadas ni de fondo
      distinto). Los cebos/iniciadores no se suman.
    - Tajo: cada pozo arranca el prisma B × S × H (malla regular).
    - Subterráneo: el disparo arranca la sección A por el avance indicado.

Límites
    - No calcula energía, vibraciones, fragmentación ni dilución.
    - No reemplaza las normas de la mina.

Validación
    - Pruebas automáticas en tests/test_carga.py con ejemplos resueltos a mano.
    - Antes de uso en campo, compara los resultados con
      un disparo real documentado de su operación.
"""

import math


class ErrorDeDatos(ValueError):
    """Dato de entrada fuera de rango."""


def _positivo(nombre: str, valor: float) -> None:
    if valor is None or valor <= 0:
        raise ErrorDeDatos(f"{nombre} debe ser mayor que cero (valor recibido: {valor})")


def carga_lineal(diametro_carga_mm: float, densidad_explosivo_gcc: float) -> float:
    """Carga lineal en kg/m."""
    _positivo("El diámetro de carga", diametro_carga_mm)
    _positivo("La densidad del explosivo", densidad_explosivo_gcc)
    area_m2 = math.pi * (diametro_carga_mm / 1000.0) ** 2 / 4.0
    return area_m2 * densidad_explosivo_gcc * 1000.0


def longitud_de_carga(longitud_pozo_m: float, taco_m: float) -> float:
    """Longitud cargada en m (nunca negativa)."""
    if taco_m < 0:
        raise ErrorDeDatos("El taco no puede ser negativo")
    return max(longitud_pozo_m - taco_m, 0.0)


def carga_por_pozo(carga_lineal_kg_m: float, longitud_carga_m: float) -> float:
    """Carga del pozo en kg."""
    return carga_lineal_kg_m * longitud_carga_m


def volumen_tajo(burden_m: float, espaciamiento_m: float, altura_banco_m: float) -> float:
    """Volumen arrancado por un pozo en tajo abierto, en m³."""
    _positivo("El burden", burden_m)
    _positivo("El espaciamiento", espaciamiento_m)
    _positivo("La altura de banco", altura_banco_m)
    return burden_m * espaciamiento_m * altura_banco_m


def volumen_subterraneo(area_seccion_m2: float, avance_m: float) -> float:
    """Volumen arrancado por un disparo subterráneo, en m³."""
    _positivo("El área de la sección", area_seccion_m2)
    _positivo("El avance", avance_m)
    return area_seccion_m2 * avance_m


def tonelaje(volumen_m3: float, densidad_roca_t_m3: float) -> float:
    _positivo("La densidad de la roca", densidad_roca_t_m3)
    return volumen_m3 * densidad_roca_t_m3


def factor_de_carga(carga_kg: float, volumen_m3: float) -> float:
    """kg de explosivo por m³ de roca."""
    _positivo("El volumen", volumen_m3)
    return carga_kg / volumen_m3


def factor_de_potencia(carga_kg: float, tonelaje_t: float) -> float:
    """kg de explosivo por tonelada de roca."""
    _positivo("El tonelaje", tonelaje_t)
    return carga_kg / tonelaje_t
