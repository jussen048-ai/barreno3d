"""
Mapa de vibración de campo cercano (versión 1).

FICHA TÉCNICA
=============
Requisito
    Estimar la velocidad pico de partícula (PPV) en un plano que corta la
    voladura, para mostrar zonas de daño con colores.

Modelo
    Holmberg, R. & Persson, P.-A. (1979). "Design of tunnel perimeter blasthole
    patterns to prevent rock damage". Proc. Tunnelling '79, IMM, Londres.
    La columna de carga se divide en elementos de longitud Δz con carga lineal q:

        PPV = K · [ Σ  q · Δz / R_i^(β/α) ] ^ α                     [mm/s]

    R_i = distancia (m) del punto al centro de cada elemento.

Constantes por defecto (SIN CALIBRAR)
    K = 700, α = 0.7, β = 1.5 — Lundborg et al. (1978), usadas por Holmberg y
    Persson para roca dura. Deben reemplazarse por constantes del sitio,
    obtenidas de mediciones con sismógrafo (ver NIOSH: "Application of
    NIOSH-Modified Holmberg-Persson Approach…", donde también se discuten
    limitaciones de esta forma de la ecuación).

Criterio de colores por defecto (editable)
    Bauer, A. & Calder, P. N. (1970), PPV en mm/s:
        < 254  sin fracturamiento de roca intacta
        254–635  agrietamiento menor por tracción
        635–2540  agrietamiento fuerte y algo de fracturas radiales
        > 2540  fragmentación del macizo

Combinación de varios pozos
    "maximo" (por defecto): cada pozo por separado y se toma el mayor
              (cada pozo detona en su propio retardo).
    "suma":   todos los pozos suman dentro del corchete (detonación simultánea;
              envolvente muy conservadora).

Supuestos y límites
    - Medio homogéneo e isótropo; no considera caras libres, estructuras ni agua.
    - Es una estimación para comparar diseños, no una medición.
    - Cerca del pozo la ecuación crece sin límite; se impone una distancia
      mínima igual al radio del pozo.
Validación
    - tests/test_energia.py comprueba el caso de un solo elemento a mano.
    - Calibra K, α, β con monitoreo antes de decidir con el mapa.
"""

from dataclasses import dataclass

import numpy as np

UMBRALES_BAUER_CALDER = (254.0, 635.0, 2540.0)  # mm/s
ETIQUETAS_ZONAS = (
    "Sin daño",
    "Agrietamiento menor",
    "Agrietamiento fuerte",
    "Fragmentación",
)


@dataclass
class ColumnaCarga:
    """Tramo cargado de un pozo (del final del taco al fondo)."""

    inicio: tuple[float, float, float]  # m
    fin: tuple[float, float, float]  # m
    carga_lineal: float  # kg/m
    radio: float  # m, distancia mínima de cálculo


def ppv_holmberg_persson(
    puntos: np.ndarray,
    columnas: list[ColumnaCarga],
    k: float = 700.0,
    alfa: float = 0.7,
    beta: float = 1.5,
    modo: str = "maximo",
    elementos_por_metro: float = 4.0,
) -> np.ndarray:
    """PPV (mm/s) en cada punto (array N×3, en m)."""
    if k <= 0 or alfa <= 0 or beta <= 0:
        raise ValueError("K, α y β deben ser mayores que cero")
    puntos = np.asarray(puntos, dtype=float).reshape(-1, 3)
    exponente = beta / alfa
    acumulado = np.zeros(len(puntos))
    maximo = np.zeros(len(puntos))
    for col in columnas:
        a = np.asarray(col.inicio, dtype=float)
        b = np.asarray(col.fin, dtype=float)
        largo = float(np.linalg.norm(b - a))
        if largo <= 0 or col.carga_lineal <= 0:
            continue
        n = max(4, int(np.ceil(largo * elementos_por_metro)))
        dz = largo / n
        centros = a + (b - a) * ((np.arange(n) + 0.5) / n)[:, None]  # n×3
        suma_pozo = np.zeros(len(puntos))
        for c in centros:  # bucle por elemento: memoria acotada con mallas grandes
            r = np.linalg.norm(puntos - c, axis=1)
            r = np.maximum(r, max(col.radio, 1e-3))
            suma_pozo += col.carga_lineal * dz / r**exponente
        if modo == "maximo":
            maximo = np.maximum(maximo, k * suma_pozo**alfa)
        else:
            acumulado += suma_pozo
    return maximo if modo == "maximo" else k * acumulado**alfa


def zonas(ppv: np.ndarray, umbrales=UMBRALES_BAUER_CALDER) -> np.ndarray:
    """Índice de zona 0..len(umbrales) para cada valor de PPV."""
    return np.digitize(ppv, np.asarray(sorted(umbrales), dtype=float))
