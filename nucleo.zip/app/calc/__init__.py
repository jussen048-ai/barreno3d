"""
Motor de cálculo de Barreno 3D (vacío en esta versión).

Reglas para este paquete:
- No importa nada de la interfaz (PySide6) ni del visor (PyVista).
- Antes de agregar un cálculo se documenta: requisitos, fuentes técnicas,
  unidades, supuestos, límites y procedimiento de validación profesional.
- No se copian fórmulas, resultados ni algoritmos de software comercial.
- Toda función no validada se marca como PENDIENTE DE VALIDAR.
"""
