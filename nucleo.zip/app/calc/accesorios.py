"""
Accesorios de iniciación para una malla (cantidades geométricas, no reglas fijas).

Sistemas (los dos que aparecen en la documentación usada):
- «carmex»: un Carmex por taladro cargado + mecha rápida que une los conectores en el orden de salida
  (iniciación convencional; FAMESA, presentación CARMEX; Retamas E-MIN-8).
- «no_electrico»: un detonador no eléctrico (tipo Fanel) por taladro cargado + cordón detonante como
  línea troncal + 2 Carmex de inicio y un tramo de mecha rápida (como en las fichas de malla de Volcan).

Longitudes de línea: recorrido que une los taladros cargados en orden de salida (vecino más cercano
dentro del mismo retardo) + un porcentaje de holgura para amarres. Es una estimación geométrica:
ajústala con la práctica de la mina.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from app.biblioteca.productos import LARGOS_CARMEX_PIES

PIE = 0.3048
SISTEMAS = {"carmex": "Carmex + mecha rápida (convencional)",
            "no_electrico": "Detonadores no eléctricos + cordón detonante"}


@dataclass
class LineaAccesorio:
    item: str
    cantidad: float
    unidad: str
    nota: str = ""


def recorrido(puntos: list[tuple[float, float, float]]) -> float:
    """Largo de una línea que pasa por los taladros en orden de salida (x, y, retardo)."""
    if len(puntos) < 2:
        return 0.0
    grupos: dict[float, list[tuple[float, float]]] = {}
    for x, y, r in puntos:
        grupos.setdefault(r, []).append((x, y))
    actual = None
    total = 0.0
    for r in sorted(grupos):
        pend = list(grupos[r])
        while pend:
            if actual is None:
                actual = pend.pop(0)
                continue
            i = min(range(len(pend)), key=lambda k: math.dist(actual, pend[k]))
            total += math.dist(actual, pend[i])
            actual = pend.pop(i)
    return total


def largo_carmex(longitud_taladro: float, exceso: float = 0.30) -> tuple[int, float]:
    """Largo comercial de Carmex (pies) que supera la longitud del taladro + exceso (E-MIN-8: 0.30 m)."""
    req = longitud_taladro + exceso
    for p in LARGOS_CARMEX_PIES:
        if p * PIE >= req - 1e-9:
            return p, req
    return LARGOS_CARMEX_PIES[-1], req


def calcular(cargados: list[tuple[float, float, float]], longitud: float, sistema: str = "carmex",
             holgura: float = 0.15, s_por_m_mecha: float = 170.0, s_por_m_rapida: float = 35.0) -> list[LineaAccesorio]:
    n = len(cargados)
    if n == 0:
        return []
    L = recorrido(cargados) * (1 + holgura)
    pies, req = largo_carmex(longitud)
    if sistema == "no_electrico":
        return [
            LineaAccesorio("Detonador no eléctrico (tipo Fanel)", n, "pzas",
                           "uno por taladro cargado; el largo del tubo debe superar el taladro"),
            LineaAccesorio("Cordón detonante (línea troncal)", round(L + 2.0, 1), "m",
                           f"recorrido entre taladros + {holgura:.0%} de amarres + 2 m de enlace"),
            LineaAccesorio(f"Carmex {pies}'", 2, "pzas", "para iniciar la línea troncal"),
            LineaAccesorio("Mecha rápida", 0.2, "m", "tramo de encendido de los Carmex"),
        ]
    t_carmex = pies * PIE * s_por_m_mecha
    return [
        LineaAccesorio(f"Carmex {pies}'", n, "pzas",
                       f"uno por taladro; ≥ perforación + 0.30 m = {req:.2f} m"),
        LineaAccesorio("Mecha rápida (línea troncal)", round(L + 1.0, 1), "m",
                       f"une los conectores en el orden de salida (+{holgura:.0%})"),
        LineaAccesorio("Tiempo de combustión de cada Carmex", round(t_carmex), "s",
                       f"a {s_por_m_mecha:.0f} s/m (fábrica 150–200 s/m; medir en mina)"),
        LineaAccesorio("Distancia de puente en la mecha rápida", round(t_carmex / s_por_m_rapida, 1), "m",
                       f"d = t Carmex / t mecha rápida ({s_por_m_rapida:.0f} s/m, Z-18)"),
    ]
