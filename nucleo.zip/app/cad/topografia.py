"""
Topografía: TIN, cotas, perfiles y pendientes (sin interfaz).

- TIN: triangulación de Delaunay en planta (X, Y) de los vértices de curvas de nivel,
  puntos y polilíneas 3D. Se usa scipy si está instalado; si no, VTK (PyVista).
  Los triángulos con algún lado mayor que «lado_max» se descartan (evita cubrir
  zonas sin datos en bordes cóncavos).
- Cota en un punto: interpolación lineal en el triángulo que lo contiene (baricéntrica).
- Perfil: muestreo de cotas a lo largo de una polilínea en planta.
- Pendiente de cada triángulo: ángulo de su normal con la vertical (°).
- Clasificación por pendiente (umbrales elegidos por el usuario): «plataforma/berma»
  (≤ umbral bajo), «talud / cara de banco» (≥ umbral alto) e «intermedia».
  Es una clasificación geométrica para visualizar; no identifica bancos de diseño.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np


def _cruz2(a, b):
    return a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]


class ErrorTopografia(Exception):
    pass


@dataclass
class TIN:
    puntos: np.ndarray  # (n, 3)
    triangulos: np.ndarray  # (m, 3) índices

    @property
    def n_triangulos(self) -> int:
        return len(self.triangulos)

    def pendientes(self) -> np.ndarray:
        """Pendiente de cada triángulo en grados (0 = horizontal, 90 = vertical)."""
        p = self.puntos[self.triangulos]
        n = np.cross(p[:, 1] - p[:, 0], p[:, 2] - p[:, 0])
        norma = np.linalg.norm(n, axis=1)
        norma[norma == 0] = 1
        cosz = np.abs(n[:, 2]) / norma
        return np.degrees(np.arccos(np.clip(cosz, 0, 1)))

    def area_planta(self) -> float:
        p = self.puntos[self.triangulos][:, :, :2]
        return float(np.sum(np.abs(_cruz2(p[:, 1] - p[:, 0], p[:, 2] - p[:, 0]))) / 2)

    def cota(self, x: float, y: float) -> float | None:
        p = self.puntos[self.triangulos]
        a, b, c = p[:, 0, :2], p[:, 1, :2], p[:, 2, :2]
        v0, v1 = b - a, c - a
        v2 = np.array([x, y]) - a
        den = v0[:, 0] * v1[:, 1] - v1[:, 0] * v0[:, 1]
        ok = np.abs(den) > 1e-12
        u = np.where(ok, (v2[:, 0] * v1[:, 1] - v1[:, 0] * v2[:, 1]) / np.where(ok, den, 1), -1)
        v = np.where(ok, (v0[:, 0] * v2[:, 1] - v2[:, 0] * v0[:, 1]) / np.where(ok, den, 1), -1)
        dentro = (u >= -1e-9) & (v >= -1e-9) & (u + v <= 1 + 1e-9)
        idx = np.nonzero(dentro)[0]
        if len(idx) == 0:
            return None
        k = idx[0]
        za, zb, zc = p[k, 0, 2], p[k, 1, 2], p[k, 2, 2]
        return float(za + u[k] * (zb - za) + v[k] * (zc - za))


def _delaunay(xy: np.ndarray) -> np.ndarray:
    try:
        from scipy.spatial import Delaunay
        return Delaunay(xy).simplices.astype(int)
    except ImportError:
        pass
    try:
        import pyvista as pv
        nube = pv.PolyData(np.c_[xy, np.zeros(len(xy))])
        malla = nube.delaunay_2d()
        caras = malla.faces.reshape(-1, 4)
        return caras[caras[:, 0] == 3][:, 1:].astype(int)
    except Exception as error:  # noqa: BLE001
        raise ErrorTopografia(f"No hay triangulador disponible (scipy o VTK): {error}") from error


def crear_tin(puntos, lado_max: float | None = None, tolerancia: float = 1e-3) -> TIN:
    p = np.asarray(puntos, dtype=float)
    if p.ndim != 2 or p.shape[1] != 3 or len(p) < 3:
        raise ErrorTopografia("Se necesitan al menos 3 puntos con X, Y, Z")
    # puntos duplicados en planta: conservar uno (el primero)
    clave = np.round(p[:, :2] / tolerancia).astype(np.int64)
    _, unicos = np.unique(clave, axis=0, return_index=True)
    p = p[np.sort(unicos)]
    if len(p) < 3:
        raise ErrorTopografia("Los puntos coinciden en planta")
    if np.ptp(p[:, 0]) < tolerancia or np.ptp(p[:, 1]) < tolerancia:
        raise ErrorTopografia("Los puntos están alineados: no forman una superficie")
    tri = _delaunay(p[:, :2])
    if lado_max:
        q = p[tri][:, :, :2]
        lados = np.stack([np.linalg.norm(q[:, 0] - q[:, 1], axis=1), np.linalg.norm(q[:, 1] - q[:, 2], axis=1),
                          np.linalg.norm(q[:, 2] - q[:, 0], axis=1)], axis=1)
        tri = tri[lados.max(axis=1) <= lado_max]
    if len(tri) == 0:
        raise ErrorTopografia("No quedaron triángulos (aumenta el lado máximo)")
    return TIN(p, tri)


def densificar(polilinea, paso: float):
    """Agrega vértices cada «paso» m a lo largo de una polilínea (mejora el TIN entre curvas)."""
    pts = [tuple(polilinea[0])]
    for a, b in zip(polilinea, polilinea[1:]):
        a, b = np.asarray(a, float), np.asarray(b, float)
        d = float(np.linalg.norm(b[:2] - a[:2]))
        n = max(1, int(math.ceil(d / paso))) if paso > 0 else 1
        for k in range(1, n + 1):
            pts.append(tuple(a + (b - a) * k / n))
    return pts


@dataclass
class Perfil:
    distancia: np.ndarray
    x: np.ndarray
    y: np.ndarray
    z: np.ndarray  # NaN fuera del TIN

    def pendientes_tramo(self) -> np.ndarray:
        """Pendiente (%) entre muestras consecutivas."""
        dz = np.diff(self.z)
        dd = np.diff(self.distancia)
        with np.errstate(invalid="ignore", divide="ignore"):
            return 100 * dz / dd

    def resumen(self) -> dict:
        z = self.z[~np.isnan(self.z)]
        if len(z) == 0:
            return {"longitud": float(self.distancia[-1]), "con_datos": 0.0}
        pend = self.pendientes_tramo()
        pend = pend[~np.isnan(pend)]
        return {
            "longitud": float(self.distancia[-1]),
            "con_datos": float(np.mean(~np.isnan(self.z)) * 100),
            "cota_min": float(z.min()), "cota_max": float(z.max()), "desnivel": float(z.max() - z.min()),
            "pend_max_pct": float(np.max(np.abs(pend))) if len(pend) else 0.0,
            "pend_max_grados": float(np.degrees(np.arctan(np.max(np.abs(pend)) / 100))) if len(pend) else 0.0,
        }


def perfil(tin: TIN, vertices_xy, paso: float = 1.0) -> Perfil:
    vs = [np.asarray(v[:2], float) for v in vertices_xy]
    if len(vs) < 2:
        raise ErrorTopografia("El perfil necesita al menos dos puntos")
    xs, ys, ds = [], [], []
    acum = 0.0
    for a, b in zip(vs, vs[1:]):
        L = float(np.linalg.norm(b - a))
        n = max(1, int(math.ceil(L / paso)))
        for k in range(0 if not xs else 1, n + 1):
            t = k / n
            q = a + (b - a) * t
            xs.append(q[0]); ys.append(q[1]); ds.append(acum + L * t)
        acum += L
    zs = [tin.cota(x, y) for x, y in zip(xs, ys)]
    return Perfil(np.array(ds), np.array(xs), np.array(ys),
                  np.array([np.nan if z is None else z for z in zs], dtype=float))


def clasificar_pendientes(pend: np.ndarray, umbral_bajo: float = 15.0, umbral_alto: float = 45.0) -> np.ndarray:
    """0 = plataforma/berma, 1 = intermedia, 2 = talud/cara de banco."""
    c = np.ones(len(pend), dtype=int)
    c[pend <= umbral_bajo] = 0
    c[pend >= umbral_alto] = 2
    return c


def medir(p1, p2) -> dict:
    a, b = np.asarray(p1, float), np.asarray(p2, float)
    d = b - a
    h = float(np.hypot(d[0], d[1]))
    return {"distancia_3d": float(np.linalg.norm(d)), "horizontal": h, "desnivel": float(d[2]),
            "pendiente_grados": float(np.degrees(np.arctan2(abs(d[2]), h))) if (h or d[2]) else 0.0,
            "azimut": float((np.degrees(np.arctan2(d[0], d[1])) + 360) % 360)}
