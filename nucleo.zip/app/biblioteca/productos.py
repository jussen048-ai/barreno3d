"""
Catálogo de productos de voladura con datos de fichas técnicas de fabricante.

- Explosivos: EMULNOR 500/1000/3000/5000 (FAMESA, ficha FT-040-PE/ES Rev. 12). Masa por cartucho =
  peso neto de la caja / piezas por caja (dato de la ficha, no calculado).
- Accesorios de iniciación (FAMESA, presentación «CARMEX: sistema de iniciación convencional» y
  clase S-2 de Perforación y Voladura): fulminante N.° 8, mecha de seguridad, conector, mecha rápida,
  Carmex, detonador no eléctrico y cordón detonante. Los tiempos de combustión son rangos de fábrica:
  deben medirse en la mina (la propia fuente lo indica).
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

from app.core.modelo import TIPO_ENCARTUCHADO, Explosivo

ARCHIVO = Path(__file__).resolve().parent.parent / "datos" / "productos_famesa.json"
PULG = 25.4

# Texto ASCII de fracciones para que el nombre lleve el largo (Explosivo.largo_cartucho_m lo lee).
_FR = {0.125: "1/8", 0.25: "1/4", 0.375: "3/8", 0.5: "1/2", 0.75: "3/4", 0.875: "7/8"}


def pulgadas_texto(x: float) -> str:
    ent = int(x + 1e-9)
    fr = round(x - ent, 3)
    if fr < 1e-6:
        return f"{ent}"
    t = _FR.get(fr, f"{fr:g}")
    return f"{ent} {t}" if ent else t


@lru_cache(maxsize=1)
def datos() -> dict:
    return json.loads(ARCHIVO.read_text(encoding="utf-8"))


def productos() -> dict[str, dict]:
    return datos()["productos"]


def presentaciones(producto: str | None = None, tubular: bool = False) -> list[dict]:
    tipo = producto.split()[-1] if producto else None
    return [p for p in datos()["presentaciones"]
            if (tipo is None or p["tipo"] == tipo) and (tubular or not p["tubular"])]


def explosivo_de(producto: str, diametro_pulg: float, largo_pulg: float, id_: str = "") -> Explosivo:
    """Explosivo del catálogo (encartuchado) listo para el proyecto."""
    tipo = producto.split()[-1]
    prop = productos()[producto]
    pres = next((p for p in presentaciones(producto, tubular=True)
                 if abs(p["diametro_pulg"] - diametro_pulg) < 1e-6 and abs(p["largo_pulg"] - largo_pulg) < 1e-6),
                None)
    if pres is None:
        raise KeyError(f"{producto} {diametro_pulg}\" x {largo_pulg}\" no figura en la ficha técnica")
    # VOD: la ficha da la confinada (tubo de 1½") y la no confinada (cartucho de 1"). Para cartuchos
    # de hasta 1¼" se usa la no confinada (más cercana al carguío en taladros de 38–45 mm).
    vod = prop["vod_libre"] if diametro_pulg <= 1.25 + 1e-9 else prop["vod_conf"]
    nombre = f'Emulnor {tipo} {pulgadas_texto(diametro_pulg)}"x{largo_pulg:g}"'
    return Explosivo(id=id_ or f"FAM-{tipo}-{diametro_pulg:g}x{largo_pulg:g}", nombre=nombre,
                     tipo=TIPO_ENCARTUCHADO, densidad_gcc=prop["densidad"], diametro_cartucho_mm=round(diametro_pulg * PULG, 1),
                     prp=prop["rws"] / 100, vod_ms=vod, referencial=False, kg_cartucho=pres["kg_cartucho"],
                     fuente="Ficha técnica FAMESA FT-040-PE/ES Rev. 12")


def catalogo_explosivos() -> list[Explosivo]:
    """Un explosivo por presentación (sin las tubulares duplicadas)."""
    vistos, lista = set(), []
    for p in presentaciones():
        k = (p["tipo"], p["diametro_pulg"], p["largo_pulg"])
        if k in vistos:
            continue
        vistos.add(k)
        lista.append(explosivo_de(f"EMULNOR {p['tipo']}", p["diametro_pulg"], p["largo_pulg"]))
    return lista


# --------------------------------------------------------------------------- accesorios
ACCESORIOS = {
    "Fulminante simple N.° 8": {
        "descripcion": "Cápsula de aluminio con carga primaria (mixto ≈ 120 mg) y carga base (PETN ≈ 550 mg); "
                       "detona con la llama de la mecha de seguridad.",
        "fuente": "FAMESA, presentación CARMEX"},
    "Mecha de seguridad": {
        "descripcion": "Núcleo de pólvora negra (5–6 g/m) con forro de PVC. Tiempo de combustión de fábrica "
                       "150–200 s/m; varía con la altitud, se mide en mina.",
        "s_por_m": (150.0, 200.0), "fuente": "FAMESA, presentación CARMEX"},
    "Conector de ignición": {
        "descripcion": "Casquillo de aluminio con masa pirotécnica que pasa la llama de la mecha rápida a la "
                       "mecha de seguridad; con block de sujeción.", "fuente": "FAMESA, presentación CARMEX"},
    "Mecha rápida Z-19": {"descripcion": "Cordón con masa pirotécnica y alambres de soporte.", "s_por_m": (26.0, 26.0),
                          "fuente": "FAMESA, presentación CARMEX"},
    "Mecha rápida Z-18": {"descripcion": "Cordón con masa pirotécnica y alambres de soporte.", "s_por_m": (35.0, 35.0),
                          "fuente": "FAMESA, presentación CARMEX"},
    "Mecha rápida Z-20": {"descripcion": "Cordón con masa pirotécnica y alambres de soporte.", "s_por_m": (59.0, 59.0),
                          "fuente": "FAMESA, presentación CARMEX"},
    "Carmex": {"descripcion": "Fulminante N.° 8 + mecha de seguridad + conector + block de sujeción, "
                              "ensamblados en fábrica. Su largo debe superar la longitud del taladro.",
               "fuente": "FAMESA, presentación CARMEX; Retamas E-MIN-8 (≥ perforación + 0.30 m)"},
    "Detonador no eléctrico (tipo Fanel)": {
        "descripcion": "Detonador con tubo de choque y retardo numerado (periodo largo, LP, o corto, MS). "
                       "Uno por taladro cargado.", "fuente": "Clase S-2 PyV; diseños de malla Volcan SC-CR"},
    "Cordón detonante": {"descripcion": "Línea troncal de PETN (p. ej. 3P, 5P g/pie) que inicia los "
                                       "detonadores no eléctricos.", "fuente": "Clase S-2 PyV"},
}

# Largos comerciales usuales del Carmex (pies). Editable: el largo debe superar al taladro.
LARGOS_CARMEX_PIES = [5, 6, 7, 8, 9, 10, 12]
