"""
Opciones de malla para un frente: con la sección, la roca y las medidas de los taladros se
generan VARIAS mallas completas, cada una con un tipo de arranque, para elegir.

Arranques disponibles
  Del estándar de 6 pies (mallas reales adaptadas, ver app/biblioteca/generador.py):
    · Cruz de 5 alivios · Triángulo de 3 alivios · Rectángulo de 6 alivios
  Teóricos (malla completa con el método de Holmberg / Yilmaz 2023 para ayudas y contorno):
    · Corte cilíndrico de 4 secciones (Holmberg): alivios de Ø mayor, cuadros 1–4.
    · Corte de 4 cuadrantes — criterio de Ash:
        X = 4.45·(Dth² + D²)/(Dth + D)  [pulgadas]
        B1 = 0.55·(X + Dth + D)/2,  W1 = B1·√2
        Bk = 0.7·W(k−1),            Wk = (Bk + 0.5·W(k−1))·√2     (k = 2, 3, 4)
      Los cuadrados se alternan: ejes (1, 3) y diagonales (2, 4).
    · Corte quemado: alivios del MISMO diámetro que los cargados (diámetro equivalente D·√n).
    · Corte en V (cuña): pares de taladros inclinados que convergen; el avance queda limitado
      por el ancho (≈ 0.45–0.5·ancho) y el ángulo con el frente debe ser ≥ 60°.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace

from app.biblioteca import estandar as est
from app.biblioteca import generador as gen
from app.calc.carga import ErrorDeDatos
from app.core.malla_auto import EntradaFrente, Roca, disenar_frente

PULG = 25.4


@dataclass
class DatosFrente:
    ancho: float = 3.0
    alto: float = 3.0
    flecha: float = 0.9  # m (altura del arco o radio de esquinas)
    forma: str = "Baúl (arco)"
    roca: str = "Regular"  # Buena / Regular / Mala
    rmr: float | None = None
    gsi: float | None = None
    rqd: float | None = None
    densidad_roca: float = 2.7
    diametro_mm: float = 38.0
    diametro_alivio_mm: float = 64.0
    n_alivios: int = 1
    longitud: float = 1.83  # m (6 pies)
    explosivo: object = None  # Explosivo principal (del proyecto)
    explosivo_contorno: object = None
    largo_cartucho_m: float = 0.2032  # 8"
    angulo_v: float = 65.0  # ° entre el taladro del corte en V y el frente
    cuneta: bool = False
    cuneta_lado: str = "izquierda"
    cuneta_ancho: float = 0.35
    cuneta_profundidad: float = 0.30
    labor: str = "frente"  # frente / chimenea / tajeo (app/core/equipos.LABORES)
    burden_tajeo: float = 0.40  # m (tajeo: distancia entre filas)
    espaciamiento_tajeo: float = 0.30  # m (tajeo: distancia entre taladros de una fila)
    equipo: str | None = None  # clave del equipo elegido por el usuario (None = automático)


@dataclass
class OpcionMalla:
    clave: str
    nombre: str
    familia: str
    descripcion: str
    plano: est.PlanoRef | None = None
    avance: float = 0.0
    avisos: list[str] = field(default_factory=list)
    error: str | None = None
    equipo: object = None  # app.core.equipos.Seleccion
    comparacion: list[str] = field(default_factory=list)  # frente a referencias de minas
    labor: str = "frente"

    def resumen(self) -> dict:
        p = self.plano
        if p is None:
            return {}
        car = p.cargados()
        kg = sum(t.kg if t.kg is not None else 0 for t in car)
        if not any(t.kg is not None for t in car):
            kg = next((f["valores"].get("Expl_Kg", 0) for f in p.explosivos_tabla
                       if f["nombre"].startswith("Total")), 0) or 0
        area = (p.parametros.get("area_m2") or {}).get("sin_sobrerotura") or p.area_contorno()
        vol = area * self.avance if self.avance else 0
        L = p.longitud_perforacion()
        metros = sum(t.longitud or L for t in p.taladros)
        return {"taladros": len(p.taladros), "cargados": len(car), "alivios": len(p.alivios()), "kg": kg,
                "factor_carga": kg / vol if vol else None, "metros": metros, "avance": self.avance,
                "kg_por_m": kg / self.avance if self.avance else None, "area": area}

    def accesorios(self, sistema: str = "carmex"):
        """Accesorios de iniciación (cantidades geométricas; ver app/calc/accesorios.py)."""
        from app.calc.accesorios import calcular
        if self.plano is None:
            return []
        car = [(t.x, t.y, float(t.detonador or 0)) for t in self.plano.cargados()]
        return calcular(car, self.plano.longitud_perforacion(), sistema)


# ---------------------------------------------------------------- utilidades
RMR_POR_CLASE = {"Buena": 70.0, "Regular": 50.0, "Mala": 30.0}  # centro de los rangos del estándar


def _roca_obj(d: DatosFrente) -> Roca:
    rmr = d.rmr if d.rmr is not None else RMR_POR_CLASE.get(d.roca, 50.0)
    rqd = d.rqd if d.rqd is not None else max(10.0, min(100.0, 1.2 * rmr))
    return Roca(rmr=rmr, rqd=rqd, gsi=d.gsi or 0.0, densidad=d.densidad_roca)


def _entrada(d: DatosFrente, **cambios) -> EntradaFrente:
    e = EntradaFrente(ancho=d.ancho, alto=d.alto, flecha=d.flecha, forma=d.forma, diametro_mm=d.diametro_mm,
                      diametro_alivio_mm=d.diametro_alivio_mm, n_alivios=d.n_alivios, longitud=d.longitud,
                      roca=_roca_obj(d))
    return replace(e, **cambios)


def _kg_por_cartucho(exp, largo_m: float) -> float | None:
    if exp is None or not getattr(exp, "diametro_cartucho_mm", 0):
        return None
    if getattr(exp, "kg_cartucho", 0) > 0 and exp.largo_cartucho_m() and abs(exp.largo_cartucho_m() - largo_m) < 0.01:
        return exp.kg_cartucho  # dato del fabricante (cartuchos por caja)
    return exp.densidad_gcc * 1000 * math.pi / 4 * (exp.diametro_cartucho_mm / 1000) ** 2 * largo_m


def _cargas(resultado, e: EntradaFrente, d: DatosFrente) -> list[float]:
    """kg de cada taladro del diseño teórico (mismo cálculo que el resto del programa)."""
    from app.core.ejemplos import crear_proyecto_vacio
    from app.core.malla_auto import frente_a_pozos
    from app.core.modelo import DisenoVoladura
    from app.core.resultados import carga_de_pozo
    pr = crear_proyecto_vacio("tmp", DisenoVoladura(escenario="subterraneo"))
    principal = replace(d.explosivo, id="__P")
    contorno = replace(d.explosivo_contorno or d.explosivo, id="__C")
    pr.explosivos = [principal, contorno]
    pozos, _ = frente_a_pozos(resultado, e, set(), 0, 0, 0, 0, "__P", "__C")
    kgs = []
    for p in pozos:
        c = carga_de_pozo(pr, p)
        kgs.append(c.carga if c.cargado else 0.0)
    return kgs


def asignar_retardos(taladros: list[est.TaladroRef]) -> None:
    """Numeración de salida: arranque por distancia al alivio, ayudas por anillos, luego hastiales,
    corona y arrastres (los arrastres al final, como es habitual)."""
    al = [t for t in taladros if t.tipo == "alivio"]
    cx = sum(t.x for t in al) / len(al) if al else 0.0
    cy = sum(t.y for t in al) / len(al) if al else 1.0
    for t in al:
        t.detonador = None
    orden_grupo = {"Arranque": 0, "Ayuda": 1, "Hastial": 2, "Contorno": 2, "Corona": 3, "Arrastre": 4}
    cargados = [t for t in taladros if t.tipo == "cargado"]
    cargados.sort(key=lambda t: (orden_grupo.get(t.funcion, 1), round(math.hypot(t.x - cx, t.y - cy) / 0.12)))
    numero, previo = 0, None
    for t in cargados:
        clave = (orden_grupo.get(t.funcion, 1), round(math.hypot(t.x - cx, t.y - cy) / 0.12)
                 if t.funcion in ("Arranque", "Ayuda") else 0)
        if clave != previo:
            numero += 1
            previo = clave
        t.detonador = numero


def _a_plano(nombre: str, contorno, taladros: list[est.TaladroRef], d: DatosFrente, avance: float,
             longitud: float) -> est.PlanoRef:
    filas = []
    por_exp: dict[str, list[est.TaladroRef]] = {}
    for t in taladros:
        if t.tipo == "cargado":
            por_exp.setdefault(t.explosivo, []).append(t)
    for nom, ts in por_exp.items():
        v = {"Cart": float(sum(t.cartuchos for t in ts)), "Perf": float(len(ts)),
             "Expl_Kg": round(sum(t.kg or 0 for t in ts), 2)}
        filas.append({"nombre": nom, "valores": v})
    filas.append({"nombre": "Sin explosivo", "valores": {"Perf": float(sum(1 for t in taladros if t.tipo == "alivio"))}})
    filas.append({"nombre": "Total general", "valores": {
        "Cart": sum(f["valores"].get("Cart", 0) for f in filas), "Perf": float(len(taladros)),
        "Expl_Kg": round(sum(f["valores"].get("Expl_Kg", 0) for f in filas), 2)}})
    cuenta: dict[int, int] = {}
    for t in taladros:
        if t.tipo == "cargado" and t.detonador is not None:
            cuenta[int(t.detonador)] = cuenta.get(int(t.detonador), 0) + 1
    area = gen._area(gen.recortar_sobre_piso(contorno))
    par = {"long_perforacion_pies": longitud / est.PIE, "avance_m": round(avance, 2),
           "area_m2": {"sin_sobrerotura": round(area, 2), "con_sobrerotura": round(area * 1.1, 2)},
           "peso_especifico_t_m3": d.densidad_roca}
    return est.PlanoRef(pagina=0, seccion=f"{d.ancho:.2f} x {d.alto:.2f}", ancho=d.ancho, alto=d.alto,
                        variante=nombre, roca=d.roca, rotulo="n.º de retardo, cartuchos", iniciacion="no eléctrica",
                        cuenta_detonadores=cuenta, total_cargados=sum(cuenta.values()), explosivos_tabla=filas,
                        parametros=par, contorno=[tuple(map(float, v)) for v in contorno], taladros=taladros,
                        estado="Generado", titulo=f"{nombre} · {d.ancho:.2f} × {d.alto:.2f} m · roca {d.roca}")


def _teorico(d: DatosFrente, nombre: str, entrada: EntradaFrente):
    r = disenar_frente(entrada, d.explosivo, d.explosivo_contorno)
    kgs = _cargas(r, entrada, d)
    kgc_p = _kg_por_cartucho(d.explosivo, d.largo_cartucho_m)
    kgc_c = _kg_por_cartucho(d.explosivo_contorno or d.explosivo, d.largo_cartucho_m)
    tal = []
    for p, kg in zip(r.pozos, kgs):
        exp = None if p.alivio else ((d.explosivo_contorno or d.explosivo) if p.explosivo == "contorno"
                                     else d.explosivo)
        kgc = kgc_c if p.explosivo == "contorno" else kgc_p
        cart = int(round(kg / kgc)) if (kgc and kg) else 0
        tal.append(est.TaladroRef(x=round(p.s, 3), y=round(p.h, 3), tipo="alivio" if p.alivio else "cargado",
                                  cartuchos=cart, explosivo=exp.nombre if exp else None, kg=None if p.alivio else kg,
                                  lectura="calculado", funcion=p.funcion))
    return r, tal


def _cuneta(d: DatosFrente, contorno, taladros):
    if not d.cuneta:
        return contorno
    lado = -1 if d.cuneta_lado.startswith("izq") else 1
    c2 = gen._contorno_con_cuneta(gen._orientar_antihorario(contorno), d.ancho, lado, d.cuneta_ancho,
                                  d.cuneta_profundidad)
    arr = [t for t in taladros if t.funcion == "Arrastre"] or [t for t in taladros if t.tipo == "cargado"]
    borde = lado * d.ancho / 2
    fuente = min(arr, key=lambda t: abs(t.x - borde))
    x = borde - lado * d.cuneta_ancho / 2
    n = est.TaladroRef(x=round(x, 3), y=round(-d.cuneta_profundidad / 2, 3), tipo="cargado",
                       cartuchos=fuente.cartuchos, explosivo=fuente.explosivo, kg=fuente.kg, lectura="cuneta",
                       funcion="Arrastre")
    taladros.append(n)
    return c2


def _reemplazar_arranque(taladros, nuevos, centro, radio):
    """Quita alivios, arranque y ayudas dentro del radio del arranque nuevo, y pone el nuevo."""
    cx, cy = centro
    quedan = [t for t in taladros if t.funcion not in ("Alivio", "Arranque")
              and not (t.funcion == "Ayuda" and math.hypot(t.x - cx, t.y - cy) < radio + 0.12)]
    return nuevos + quedan


def _completar(contorno, taladros, plantilla_kg, cobertura_obj, exp_nombre, cart, kg):
    poli = gen.recortar_sobre_piso(contorno)
    for _ in range(30):
        cob, punto = gen.cobertura(poli, [(t.x, t.y) for t in taladros if t.tipo == "cargado"])
        if punto is None or cob <= cobertura_obj * 1.05:
            break
        taladros.append(est.TaladroRef(x=round(punto[0], 3), y=round(punto[1], 3), tipo="cargado", cartuchos=cart,
                                       explosivo=exp_nombre, kg=kg, lectura="ayuda agregada (cobertura)",
                                       funcion="Ayuda"))


# ---------------------------------------------------------------- cortes
def corte_ash(d_mm: float, dth_mm: float, n_cuadros: int = 4):
    """Lista de cuadros [(B, W, orientación)] del criterio de Ash (en metros)."""
    D, Dth = d_mm / PULG, dth_mm / PULG
    x = 4.45 * (Dth ** 2 + D ** 2) / (Dth + D)
    b1 = 0.55 * (x + Dth + D) / 2
    cuadros = [(b1 * 0.0254, b1 * math.sqrt(2) * 0.0254, "ejes")]
    w_prev = b1 * math.sqrt(2)
    for k in range(2, n_cuadros + 1):
        bk = 0.7 * w_prev
        wk = (bk + 0.5 * w_prev) * math.sqrt(2)
        cuadros.append((bk * 0.0254, wk * 0.0254, "diagonales" if k % 2 == 0 else "ejes"))
        w_prev = wk
    return cuadros, x * 0.0254


def _holes_ash(cuadros, centro):
    cx, cy = centro
    res = []
    for k, (b, w, ori) in enumerate(cuadros, 1):
        r = w / math.sqrt(2)  # distancia del centro al vértice del cuadrado de lado w
        angs = (0, 90, 180, 270) if ori == "ejes" else (45, 135, 225, 315)
        for a in angs:
            res.append((cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a)), k))
    return res


def generar_opciones(d: DatosFrente, planos: list[est.PlanoRef] | None = None) -> list[OpcionMalla]:
    if d.explosivo is None:
        raise ErrorDeDatos("Elige el explosivo")
    planos = planos if planos is not None else est.cargar_biblioteca()
    opciones: list[OpcionMalla] = []
    L = d.longitud
    if d.labor not in ("frente", "chimenea", "tajeo"):
        raise ErrorDeDatos(f"Labor desconocida: {d.labor}")
    if d.labor != "frente" and d.cuneta:
        d = replace(d, cuneta=False)
    if d.labor == "chimenea" and not d.forma.lower().startswith("rect"):
        d = replace(d, forma=next((f for f in _formas() if f.lower().startswith("rect")), d.forma))
    if d.labor == "tajeo":
        opciones = _opciones_tajeo(d)
        return _completar_opciones(opciones, d)

    # ---------------------------------------- estándar (mallas reales adaptadas)
    for clave, (nombre, desc) in (gen.NOMBRES_ARRANQUE.items() if planos and d.labor == "frente" else ()):
        op = OpcionMalla(clave=f"std_{clave}", nombre=nombre, familia="Estándar de 6 pies (mallas reales)",
                         descripcion=desc)
        try:
            r = gen.generar(gen.EntradaMallaReal(ancho=d.ancho, alto=d.alto, roca=d.roca, diametro_mm=d.diametro_mm,
                                                 diametro_alivio_mm=d.diametro_alivio_mm,
                                                 longitud_pies=L / est.PIE, arranque=clave, cuneta=d.cuneta,
                                                 cuneta_lado=d.cuneta_lado, cuneta_ancho=d.cuneta_ancho,
                                                 cuneta_profundidad=d.cuneta_profundidad), planos)
            op.plano = r.plano
            op.plano.titulo = f"{nombre} (estándar) · {d.ancho:.2f} × {d.alto:.2f} m · roca {d.roca}"
            # avance del plano de referencia en proporción a la longitud pedida
            pt = r.plantilla.parametros
            ratio = (pt.get("avance_m") or 1.5) / ((pt.get("long_perforacion_pies") or 6) * est.PIE)
            op.avance = round(ratio * L, 2)
            op.plano.parametros["avance_m"] = op.avance
            op.avisos = list(r.avisos)
        except ValueError as error:
            op.error = str(error)
        opciones.append(op)

    # ---------------------------------------- teóricos
    def teorica(clave, nombre, desc, entrada, post=None):
        op = OpcionMalla(clave=clave, nombre=nombre, familia="Cálculo teórico", descripcion=desc)
        try:
            r, tal = _teorico(d, nombre, entrada)
            contorno = list(r.seccion)
            avance = 0.95 * entrada.longitud
            if post is not None:
                contorno, tal, avance, avisos = post(r, tal, contorno, entrada)
                op.avisos += avisos
            for t in tal:
                if t.tipo == "alivio":
                    t.funcion = "Alivio"
            contorno = _cuneta(d, contorno, tal)
            asignar_retardos(tal)
            op.plano = _a_plano(nombre, contorno, tal, d, avance, entrada.longitud)
            op.avance = avance
            op.avisos += list(r.avisos)
        except (ErrorDeDatos, ValueError, ZeroDivisionError) as error:
            op.error = str(error)
        opciones.append(op)

    teorica("holmberg", "Corte cilíndrico de 4 secciones (Holmberg)",
            f"{d.n_alivios} alivio(s) de {d.diametro_alivio_mm:.0f} mm al centro y cuatro cuadros de taladros "
            "cargados; ayudas, hastiales, corona y arrastres por el método de Holmberg (Yilmaz 2023).",
            _entrada(d))

    def post_ash(r, tal, contorno, entrada):
        al = [t for t in tal if t.funcion == "Alivio"]
        cx = sum(t.x for t in al) / len(al); cy = sum(t.y for t in al) / len(al)
        # cuantos cuadros caben: el último cuadrado no debe pasar ~40 % del lado menor de la labor
        n_c = 4
        while n_c > 2 and corte_ash(d.diametro_mm, d.diametro_alivio_mm, n_c)[0][-1][1] > 0.4 * min(d.ancho, d.alto):
            n_c -= 1
        cuadros, x = corte_ash(d.diametro_mm, d.diametro_alivio_mm, n_c)
        principal = [t for t in tal if t.funcion == "Arranque"]
        cart = principal[0].cartuchos if principal else 0
        kg = principal[0].kg if principal else None
        nuevos = [est.TaladroRef(x=round(cx, 3), y=round(cy, 3), tipo="alivio", funcion="Alivio",
                                 lectura="alivio (Ash)")]
        # los cuadros más cercanos al alivio tienen burden muy pequeño: con la columna llena se sobrecarga el
        # centro (riesgo de «congelar» el arranque); se cargan menos y la carga crece hacia afuera.
        FRAC = [0.6, 0.75, 0.9, 1.0]
        for (hx, hy, k) in _holes_ash(cuadros, (cx, cy)):
            f = FRAC[min(k - 1, 3)] if len(cuadros) > 1 else 1.0
            ck = max(1, round(cart * f)) if cart else cart
            nuevos.append(est.TaladroRef(x=round(hx, 3), y=round(hy, 3), tipo="cargado", cartuchos=ck,
                                         explosivo=d.explosivo.nombre, kg=round(kg * ck / cart, 3) if kg and cart else kg,
                                         funcion="Arranque", lectura=f"cuadrante {k} (Ash)"))
        radio = cuadros[-1][1] / math.sqrt(2)
        cob0, _ = gen.cobertura(gen.recortar_sobre_piso(contorno), [(t.x, t.y) for t in tal if t.tipo == "cargado"])
        tal2 = _reemplazar_arranque(tal, nuevos, (cx, cy), radio)
        ayuda = next((t for t in tal if t.funcion == "Ayuda"), principal[0] if principal else None)
        if ayuda is not None:
            _completar(contorno, tal2, None, cob0, ayuda.explosivo, ayuda.cartuchos, ayuda.kg)
        txt = " · ".join(f"B{k}={b:.2f} m, W{k}={w:.2f} m" for k, (b, w, _) in enumerate(cuadros, 1))
        extra = [f"Sección pequeña: {n_c} cuadros de arranque (no 4) para no sobrecargar el centro."] if n_c < 4 else []
        return contorno, tal2, 0.95 * entrada.longitud, [f"Criterio de Ash: {txt}", *extra]

    teorica("ash", "Corte de 4 cuadrantes — criterio de Ash",
            "Alivio central de Ø mayor y cuatro cuadrados alternados (ejes / diagonales) calculados con el "
            "criterio de Ash; el resto del frente por Holmberg.", _entrada(d, n_alivios=1), post_ash)

    teorica("quemado", "Corte quemado (alivios del mismo diámetro)",
            f"{max(d.n_alivios, 4)} alivios de {d.diametro_mm:.0f} mm (igual que los cargados), agrupados al centro; "
            "útil cuando no hay broca rimadora.",
            _entrada(d, diametro_alivio_mm=d.diametro_mm, n_alivios=max(d.n_alivios, 4)))

    def post_v(r, tal, contorno, entrada):
        avisos = []
        theta = math.radians(max(50.0, min(d.angulo_v, 80.0)))
        al = [t for t in tal if t.funcion == "Alivio"]
        cy = sum(t.y for t in al) / len(al) if al else d.alto * 0.4
        margen_lado = 0.45
        avance = min(0.95 * entrada.longitud, 0.5 * d.ancho)
        c = 0.15 + avance / math.tan(theta)
        if c > d.ancho / 2 - margen_lado:
            c = d.ancho / 2 - margen_lado
            avance = max(0.3, (c - 0.15) * math.tan(theta))
            avisos.append("El ancho no permite un corte en V más profundo: el avance se redujo a "
                          f"{avance:.2f} m (≈ 0.45–0.5 del ancho es lo habitual).")
        if avance < 0.6 * entrada.longitud:
            raise ValueError(f"El corte en V no es práctico en {d.ancho:.2f} m de ancho: solo avanzaría ≈ {avance:.2f} m "
                             f"de {entrada.longitud:.2f} m perforados (necesita un ancho de ≈ "
                             f"{2 * (0.45 + 0.15 + 0.6 * entrada.longitud / math.tan(theta)):.1f} m). Usa un corte paralelo.")
        if avance < 0.95 * entrada.longitud - 1e-6:
            avisos.append(f"Corte en V: avance por disparo ≈ {avance:.2f} m (limitado por el ancho de la labor).")
        filas = [cy - 0.5, cy, cy + 0.5]
        largo_v = avance / math.sin(theta) + 0.1
        principal = [t for t in tal if t.funcion == "Arranque"]
        cart = principal[0].cartuchos if principal else 0
        kg = principal[0].kg if principal else None
        nuevos = []
        for fy in filas:
            for lado in (-1, 1):
                nuevos.append(est.TaladroRef(
                    x=round(lado * c, 3), y=round(fy, 3), tipo="cargado", cartuchos=cart, explosivo=d.explosivo.nombre,
                    kg=kg, funcion="Arranque", lectura=f"corte en V ({math.degrees(theta):.0f}° con el frente)",
                    azimut_rel=round(-lado * (90 - math.degrees(theta)), 1), longitud=round(largo_v, 2)))
        cob0, _ = gen.cobertura(gen.recortar_sobre_piso(contorno), [(t.x, t.y) for t in tal if t.tipo == "cargado"])
        quedan = [t for t in tal if t.funcion not in ("Alivio", "Arranque")
                  and not (t.funcion == "Ayuda" and abs(t.x) < c + 0.15 and abs(t.y - cy) < 0.8)]
        for t in quedan:
            t.longitud = round(avance / 0.95, 2) if avance < 0.95 * entrada.longitud else None
        tal2 = nuevos + quedan
        ayuda = next((t for t in tal if t.funcion == "Ayuda"), principal[0] if principal else None)
        if ayuda is not None:
            _completar(contorno, tal2, None, cob0, ayuda.explosivo, ayuda.cartuchos, ayuda.kg)
        return contorno, tal2, avance, avisos

    if d.labor == "frente":
        teorica("v", "Corte en V (cuña)",
                f"Pares de taladros inclinados ~{d.angulo_v:.0f}° con el frente que convergen en el fondo; sin alivios. "
                "Avance limitado por el ancho de la labor.", _entrada(d), post_v)
        opciones.append(_opcion_volcan(d))
    return _completar_opciones(opciones, d)


# ---------------------------------------------------------------- labores, equipos y referencias
def _formas():
    from app.core.malla_auto import FORMAS_SECCION
    return FORMAS_SECCION


def _rmr_de(d: DatosFrente) -> float:
    return d.rmr if d.rmr is not None else RMR_POR_CLASE.get(d.roca, 50.0)


def _chimenea_contorno(op: OpcionMalla) -> None:
    """En una chimenea no hay piso, techo ni hastiales como en un frente: los taladros del perímetro son todos
    «Contorno» (cuadradores), con la carga del contorno y saliendo al final, juntos. La gravedad ayuda a que el
    material caiga, así que el contorno no lleva la sobrecarga de los arrastres de un frente."""
    tal = op.plano.taladros
    per = [t for t in tal if t.tipo == "cargado" and t.funcion in ("Arrastre", "Corona", "Hastial", "Cuneta", "Contorno")]
    if not per:
        return
    modelo = next((t for t in per if t.funcion == "Corona"), None) or min(per, key=lambda t: t.kg or 0)
    ultimo = max((t.detonador or 0) for t in tal if t.tipo == "cargado")
    for t in per:
        t.funcion = "Contorno"
        t.cartuchos, t.kg, t.explosivo = modelo.cartuchos, modelo.kg, modelo.explosivo
        t.detonador = ultimo
    op.avisos.append("Chimenea: los taladros del perímetro son contorno (cuadradores), salen juntos al final y llevan "
                     "la carga del contorno; no hay arrastres porque no hay piso que levantar.")


def _completar_opciones(opciones: list[OpcionMalla], d: DatosFrente) -> list[OpcionMalla]:
    """Equipo de perforación y comparación con referencias de minas para cada opción."""
    from app.biblioteca import referencias as ref
    from app.core.equipos import seleccionar
    sel = seleccionar(d.ancho, d.alto, d.labor, longitud=d.longitud, diametro=d.diametro_mm, forzar=d.equipo)
    rmr = _rmr_de(d)
    for op in opciones:
        op.labor = d.labor
        op.equipo = sel
        if op.plano is None or op.error:
            continue
        if d.labor == "chimenea":
            _chimenea_contorno(op)
        r = op.resumen()
        if d.labor == "chimenea":
            c = ref.chimenea_cercana(d.ancho, d.alto, rmr, d.longitud)
            op.comparacion.append(
                f"Retamas E-MIN-8, chimenea {c.seccion} RMR {c.rmr[0]}–{c.rmr[1]}, barra {c.longitud:.1f} m: "
                f"{c.cargados} cargados + {c.rimados} rimados + {c.alivios} alivios"
                + (f", {c.kg:.1f} kg" if c.kg else "") + (f", FC {c.factor_carga:.1f} kg/m³" if c.factor_carga else "")
                + f" · esta malla: {r['cargados']} cargados, {r['kg']:.1f} kg"
                + (f", FC {r['factor_carga']:.2f}" if r.get("factor_carga") else ""))
        elif d.labor == "tajeo":
            t = ref.tajeo_cercano(rmr)
            filas = ", ".join(f"{k.lower()} {n}×{c} cart." for k, (n, c) in t.filas.items())
            op.comparacion.append(
                f"Tesis de tajeos (Retamas) RMR {t.rmr[0]}–{t.rmr[1]}: corte {t.ancho}×{t.alto} m, {t.pies}', {filas}, "
                f"{t.kg:.2f} kg, FC {t.factor_carga:.2f} kg/m³ · esta malla: {r['cargados']} taladros, {r['kg']:.2f} kg"
                + (f", FC {r['factor_carga']:.2f}" if r.get("factor_carga") else ""))
        else:
            for v in ref.comparables_volcan(rmr, 2, d.ancho, d.alto):
                tb = v["tabla"]
                op.comparacion.append(
                    f"Volcan SC-CR {v['codigo'] or ''} {v['ancho']}×{v['alto']} m RMR {v['rmr'][0]}–{v['rmr'][1]}: "
                    f"{tb['cargados']} cargados, FC {tb['fc']:.2f} kg/m³, {tb['fa']:.1f} kg/m de avance")
    return opciones


def _opcion_volcan(d: DatosFrente) -> OpcionMalla:
    """Malla de la mina Volcan SC-CR con RMR parecido, escalada a la sección pedida (referencia, no regla)."""
    from app.biblioteca import referencias as ref
    rmr = _rmr_de(d)
    v, dif = ref.volcan_mas_cercano(d.ancho, d.alto, rmr)
    nombre = f"Referencia de mina: Volcan SC-CR {v['codigo'] or ''} (roca {v['clase']})".replace("  ", " ")
    op = OpcionMalla(clave="ref_volcan", nombre=nombre, familia="Referencia de una mina específica",
                     descripcion=f"Diseño real {v['ancho']}×{v['alto']} m para RMR {v['rmr'][0]}–{v['rmr'][1]} de la mina "
                                 "SC-CR (Volcan, 2022), escalado a tu sección. Es el ejemplo de UNA mina: úsalo como "
                                 "referencia y verifica con tu roca y tus explosivos.")
    ra = (d.ancho * d.alto) / (v["ancho"] * v["alto"])
    if dif > 0.35 or not 0.7 <= ra <= 1.45:
        op.error = (f"Tu sección ({d.ancho:.2f} × {d.alto:.2f} m, {d.ancho * d.alto:.1f} m²) es muy distinta de los diseños "
                    f"Volcan disponibles (el más cercano: {v['ancho']} × {v['alto']} m). Escalarlo dejaría demasiados o muy "
                    "pocos taladros: no se adapta.")
        return op
    if ref.distancia_rmr(rmr, v["rmr"]) > 0:
        op.avisos.append(f"No hay diseño Volcan para RMR {rmr:.0f}: se usa el de RMR {v['rmr'][0]}–{v['rmr'][1]}.")
    base = ref.plano_volcan(v)
    sx, sy = d.ancho / v["ancho"], d.alto / v["alto"]
    Lr = (v["tabla"].get("L") or 3.9)
    kL = d.longitud / Lr
    tal = []
    for t in base.taladros:
        n = est.TaladroRef(**{**t.__dict__})
        n.x, n.y = round(t.x * sx, 3), round(t.y * sy, 3)
        if t.tipo == "cargado":
            n.kg = round((t.kg or 0) * kL, 3)
            n.cartuchos = max(1, round(t.cartuchos * kL))
            n.explosivo = d.explosivo.nombre if "3000" in (t.explosivo or "") or not d.explosivo_contorno \
                else d.explosivo_contorno.nombre
        tal.append(n)
    funciones = est.clasificar(est.PlanoRef(pagina=0, seccion="", ancho=d.ancho, alto=d.alto, variante="",
                                            roca="", contorno=[(x * sx, y * sy) for x, y in base.contorno],
                                            taladros=tal))
    for t, f in zip(tal, funciones):
        t.funcion = t.funcion or f
    contorno = [(round(x * sx, 3), round(y * sy, 3)) for x, y in base.contorno]
    avance = d.longitud * (v["tabla"].get("avance") or 0.97 * Lr) / Lr
    op.plano = _a_plano(nombre, contorno, tal, d, avance, d.longitud)
    op.avance = round(avance, 2)
    if abs(sx - 1) > 0.02 or abs(sy - 1) > 0.02:
        op.avisos.append(f"Escalada de {v['ancho']}×{v['alto']} m a {d.ancho:.2f}×{d.alto:.2f} m "
                         f"(×{sx:.2f} en ancho, ×{sy:.2f} en alto); la forma de la sección es la de la referencia.")
    if abs(kL - 1) > 0.02:
        op.avisos.append(f"Carga por taladro escalada a tu barra ({d.longitud:.2f} m vs {Lr:.2f} m de la referencia).")
    op.avisos.append("Carga por taladro: total de cada producto de la ficha Volcan repartido entre sus taladros.")
    return op


def _opciones_tajeo(d: DatosFrente) -> list[OpcionMalla]:
    """Tajeo de corte y relleno con perforación horizontal (breasting): filas paralelas a la cara libre inferior."""
    B, S = d.burden_tajeo, d.espaciamiento_tajeo
    if B <= 0 or S <= 0:
        raise ErrorDeDatos("Burden y espaciamiento del tajeo deben ser mayores que cero")
    op = OpcionMalla(clave="tajeo_breasting", nombre="Tajeo — perforación horizontal (breasting)",
                     familia="Tajeo de corte y relleno",
                     descripcion=f"Filas horizontales a {B:.2f} m (burden) con taladros cada {S:.2f} m; la fila de "
                                 "corona con menos carga (voladura controlada). Sale primero la fila más cercana a la "
                                 "cara libre inferior y al final la corona.")
    margen_l = min(S / 2, d.ancho / 4)
    xs = []
    x = -d.ancho / 2 + margen_l
    while x <= d.ancho / 2 - margen_l + 1e-9:
        xs.append(round(x, 3)); x += S
    if len(xs) >= 2:  # centra la fila
        dx = ((d.ancho / 2 - margen_l) - xs[-1]) / 2
        xs = [round(v + dx, 3) for v in xs]
    filas = []
    y = d.alto - min(0.10, d.alto / 5)
    while y >= min(B / 2, d.alto / 2) - 1e-9:
        filas.append(round(y, 3)); y -= B
    if not filas:
        filas = [round(d.alto / 2, 3)]
    kgc = _kg_por_cartucho(d.explosivo, d.largo_cartucho_m) or 0.08
    col = max(d.longitud - 0.30, 0.3)  # taco de arcilla de 0.30 m (E-MIN-8)
    cart_prod = max(1, int(col / d.largo_cartucho_m))
    cart_cor = max(1, int(round(cart_prod * 0.7)))
    tal = []
    for k, y in enumerate(filas):
        corona = k == 0
        for x in xs:
            c = cart_cor if corona else cart_prod
            tal.append(est.TaladroRef(x=x, y=y, tipo="cargado", cartuchos=c, explosivo=(d.explosivo_contorno or
                       d.explosivo).nombre if corona else d.explosivo.nombre, kg=round(c * kgc, 3),
                       funcion="Corona" if corona else "Producción", lectura="tajeo (breasting)"))
    # salida: de abajo (cara libre) hacia la corona; dentro de la fila, del centro a los extremos
    orden = sorted(tal, key=lambda t: (t.y, abs(t.x)))
    num, prev = 0, None
    for t in orden:
        clave = (t.y, round(abs(t.x), 2))
        if clave != prev:
            num += 1
            prev = clave
        t.detonador = num
    contorno = [(-d.ancho / 2, 0.0), (d.ancho / 2, 0.0), (d.ancho / 2, d.alto), (-d.ancho / 2, d.alto)]
    avance = 0.95 * d.longitud
    op.plano = _a_plano(op.nombre, contorno, tal, d, avance, d.longitud)
    op.avance = round(avance, 2)
    op.avisos.append("Supone cara libre inferior (el corte anterior ya rellenado y el hueco bajo la veta). "
                     "Ajusta burden y espaciamiento a tu veta.")
    # comparación didáctica con la referencia de Retamas (no es una regla: depende de la roca y del cartucho)
    from app.biblioteca.referencias import tajeo_cercano
    rf = tajeo_cercano(d.rmr if d.rmr is not None else 45)
    kg = sum(t.kg or 0 for t in tal)
    vol = d.ancho * d.alto * avance
    fc = kg / vol if vol else 0
    if rf.factor_carga and fc > 1.5 * rf.factor_carga:
        op.avisos.append(f"Factor de carga {fc:.2f} kg/m³ con cartuchos de {kgc:.3f} kg; la referencia de Retamas "
                         f"(RMR {rf.rmr[0]}–{rf.rmr[1]}) llega a {rf.factor_carga} kg/m³ con cartuchos de 0.076 kg. "
                         "En tajeos se usan cartuchos de menor diámetro (p. ej. Emulnor 7/8\"×7\" de la ficha FAMESA).")
    return [op]
