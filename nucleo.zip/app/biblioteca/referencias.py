"""
Referencias de MINAS ESPECÍFICAS (no son reglas generales):

- Volcan, mina SC-CR (2022): 13 mallas de avance (3.8×4.0, 4.0×4.0 y 4.5×4.5 m) por tipo de roca (RMR),
  digitalizadas del PDF vectorial (posición exacta de taladros, retardo, rimados) + tabla de resultados.
- Retamas (MARSA), estándar E-MIN-8 v11: chimeneas de 5'×5' y 8'×5' por RMR (resumen de las tablas;
  varias figuras del documento disponible están ocultas, por eso no se digitalizaron las mallas).
- Retamas, tesis de tajeos (UNCP 2021): tajeos de corte y relleno ascendente con perforación horizontal
  de 6' en vetas angostas, por RMR.

Se usan para: (1) ofrecer una malla «adaptada de la referencia» con el aviso correspondiente,
(2) comparar la malla diseñada con lo que usa esa mina en roca parecida.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from app.biblioteca import estandar as est

ARCHIVO_VOLCAN = Path(__file__).resolve().parent.parent / "datos" / "referencias_volcan_sccr2022.json"
ESTADO_REF = "Referencia de mina (Volcan SC-CR 2022)"


@lru_cache(maxsize=1)
def volcan() -> dict:
    return json.loads(ARCHIVO_VOLCAN.read_text(encoding="utf-8"))


def _rimado_d(t: dict, tabla: dict) -> float | None:
    return tabla.get("rimadora") if t["tipo"] == "rimado" else None


def plano_volcan(d: dict) -> est.PlanoRef:
    """PlanoRef de un diseño Volcan (taladros en m, origen en el eje y el piso)."""
    tb = d.get("tabla", {})
    car = [t for t in d["taladros"] if t["tipo"] == "cargado"]
    # kg por taladro: total del producto (tabla) repartido entre los taladros de ese producto (la ficha
    # detalla la carga por tipo de taladro como imagen; los totales coinciden con la tabla)
    kg_prod: dict[str, float] = {}
    cart_prod: dict[str, int] = {}
    for nombre, n in (tb.get("cart") or {}).items():
        prod = " ".join(nombre.split()[:2])  # «Emulnor 3000»
        cart_prod[prod] = cart_prod.get(prod, 0) + n
    tot_cart = sum(cart_prod.values()) or 1
    for prod, n in cart_prod.items():
        kg_prod[prod] = tb.get("kg", 0) * n / tot_cart
    n_prod = {p: sum(1 for t in car if t["explosivo"] == p) for p in cart_prod}
    # retardo faltante (número no legible junto al círculo): el del taladro simétrico
    simetrico = {(round(-t["x"], 1), round(t["y"], 1)): t["retardo"] for t in car if t["retardo"] is not None}
    for t in car:
        if t["retardo"] is None:
            t["retardo"] = simetrico.get((round(t["x"], 1), round(t["y"], 1)))
    for t in car:  # si aún falta: el del taladro cargado más cercano con el mismo producto
        if t["retardo"] is None:
            otros = [o for o in car if o is not t and o["retardo"] is not None and o["explosivo"] == t["explosivo"]]
            if otros:
                t["retardo"] = min(otros, key=lambda o: math.hypot(o["x"] - t["x"], o["y"] - t["y"]))["retardo"]
    taladros = []
    for t in d["taladros"]:
        if t["tipo"] == "cargado":
            p = t["explosivo"]
            n = max(n_prod.get(p, 0), 1)
            principal = next((k for k in (tb.get("cart") or {}) if k.startswith(p)), p)
            taladros.append(est.TaladroRef(x=t["x"], y=t["y"], tipo="cargado", detonador=t["retardo"],
                                           cartuchos=round(cart_prod.get(p, 0) / n), explosivo=principal,
                                           kg=round(kg_prod.get(p, 0) / n, 3),
                                           lectura="Volcan SC-CR (vector)"))
        else:
            taladros.append(est.TaladroRef(x=t["x"], y=t["y"], tipo="alivio", funcion="Alivio",
                                           lectura="rimado Ø102 mm" if t["tipo"] == "rimado" else "alivio"))
    L = tb.get("L") or 3.9
    sec = f"{d['ancho']:.1f}x{d['alto']:.1f}"
    pl = est.PlanoRef(pagina=1000 + d["pagina"], seccion=sec, ancho=d["ancho"], alto=d["alto"],
                      variante=d["codigo"] or "Volcan", roca=d["clase"], contorno=[tuple(p) for p in d["contorno"]],
                      taladros=taladros, estado=ESTADO_REF,
                      titulo=f"Volcan SC-CR · {d['codigo'] or 'malla'} · {d['ancho']:.1f}×{d['alto']:.1f} m · roca "
                             f"{d['clase']} (RMR {d['rmr'][0]}–{d['rmr'][1]})",
                      parametros={"long_perforacion_pies": L / est.PIE, "avance_m": tb.get("avance"),
                                  "diametro_broca_mm": tb.get("broca"), "diametro_rimado_mm": tb.get("rimadora"),
                                  "rmr": d["rmr"], "fuente": volcan()["fuente"]},
                      notas=volcan()["aviso"])
    return pl


def planos_volcan() -> list[est.PlanoRef]:
    return [plano_volcan(d) for d in volcan()["disenos"]]


def distancia_rmr(rmr: float, rango: list[int]) -> float:
    a, b = rango
    return 0.0 if a <= rmr <= b else min(abs(rmr - a), abs(rmr - b))


def volcan_mas_cercano(ancho: float, alto: float, rmr: float) -> tuple[dict, float]:
    """Diseño Volcan más parecido (RMR primero, luego sección). Devuelve (diseño, diferencia de sección)."""
    mejor = min(volcan()["disenos"], key=lambda d: (distancia_rmr(rmr, d["rmr"]),
                                                     abs(d["ancho"] - ancho) + abs(d["alto"] - alto),
                                                     d["codigo"].startswith("BR")))
    dif = max(abs(mejor["ancho"] - ancho) / mejor["ancho"], abs(mejor["alto"] - alto) / mejor["alto"])
    return mejor, dif


def comparables_volcan(rmr: float, n: int = 3, ancho: float = 4.0, alto: float = 4.0) -> list[dict]:
    lista = sorted(volcan()["disenos"], key=lambda d: (distancia_rmr(rmr, d["rmr"]),
                                                       abs(d["ancho"] - ancho) + abs(d["alto"] - alto),
                                                       d["codigo"].startswith("BR")))
    return lista[:n]


# ---------------------------------------------------------------- chimeneas (Retamas E-MIN-8 v11)
@dataclass
class RefChimenea:
    seccion: str  # 5'x5' / 8'x5'
    ancho: float
    alto: float
    rmr: tuple[int, int]
    longitud: float  # m
    avance: float  # m
    cargados: int
    rimados: int
    alivios: int
    kg: float | None
    factor_carga: float | None  # kg/m³


FUENTE_CHIMENEAS = ("Retamas (MARSA), estándar E-MIN-8 v11 «Malla de perforación y carguío para chimeneas»: broca "
                    "38 mm, rimado 64 mm, barras cónicas de 4' y 6', Emulnor 500/1000/3000/5000 1⅛\", tacos de arcilla "
                    "de 0.30 m, corona con Emulnor 500 espaciado y cordón detonante")
CHIMENEAS = [
    RefChimenea("5'x5'", 1.52, 1.52, (21, 30), 1.5, 1.5, 15, 3, 2, 9.6, 3.1),
    RefChimenea("5'x5'", 1.52, 1.52, (31, 40), 1.5, 1.5, 15, 3, 2, 10.1, 3.3),
    RefChimenea("5'x5'", 1.52, 1.52, (41, 50), 1.5, 1.5, 17, 3, 2, 12.7, 4.2),
    RefChimenea("5'x5'", 1.52, 1.52, (51, 60), 1.5, 1.5, 19, 3, 2, 15.4, 5.1),
    RefChimenea("8'x5'", 2.44, 1.52, (21, 30), 1.7, 1.7, 17, 3, 3, None, 2.4),
    RefChimenea("8'x5'", 2.44, 1.52, (31, 40), 1.7, 1.7, 19, 3, 3, None, 2.7),
    RefChimenea("8'x5'", 2.44, 1.52, (41, 50), 1.7, 1.7, 23, 3, 3, None, 3.3),
    RefChimenea("8'x5'", 2.44, 1.52, (51, 60), 1.7, 1.7, 25, 3, 3, None, 3.7),
    RefChimenea("8'x5'", 2.44, 1.52, (21, 30), 2.3, 2.3, 17, 3, 3, 17.6, 2.4),
    RefChimenea("8'x5'", 2.44, 1.52, (31, 40), 2.3, 2.3, 19, 3, 3, 19.9, 2.7),
    RefChimenea("8'x5'", 2.44, 1.52, (41, 50), 2.3, 2.3, 23, 3, 3, 24.5, None),
    RefChimenea("8'x5'", 2.44, 1.52, (51, 60), 2.3, 2.3, 25, 3, 3, 27.0, 3.6),
]


def chimenea_cercana(ancho: float, alto: float, rmr: float, longitud: float) -> RefChimenea:
    return min(CHIMENEAS, key=lambda c: (abs(c.ancho - ancho) + abs(c.alto - alto) > 0.5,
                                         distancia_rmr(rmr, list(c.rmr)), abs(c.longitud - longitud)))


# ---------------------------------------------------------------- tajeos (tesis Retamas, UNCP 2021)
@dataclass
class RefTajeo:
    rmr: tuple[int, int]
    ancho: float  # m (sección del corte)
    alto: float
    pies: int
    long_corte: float  # m
    filas: dict  # {fila: (taladros, cartuchos por taladro)}
    kg: float
    factor_carga: float  # kg/m³
    mecha_rapida_m: float
    carmex: int


FUENTE_TAJEOS = ("Tesis «Diseño de malla de perforación y voladura en tajeos…», U. M. San Andrés — Minera Aurífera "
                 "Retamas (UNCP, 2021): corte y relleno ascendente, perforación horizontal con jackleg, malla de "
                 "0.30 × 0.40 m, EXSADIT 45 % (0.076 kg/cartucho), voladura controlada en la corona")
TAJEOS = [
    RefTajeo((60, 100), 1.2, 0.5, 6, 1.70, {"Corona": (6, 5), "Producción": (6, 7)}, 5.472, 5.36, 5, 12),
    RefTajeo((35, 59), 1.8, 1.0, 6, 1.71, {"Corona": (6, 5), "Producción": (6, 5)}, 4.56, 1.48, 6, 12),
    RefTajeo((10, 34), 1.1, 1.2, 6, 1.65, {"Corona": (2, 3), "Producción": (3, 4)}, 1.368, 0.628, 5, 5),
]


def tajeo_cercano(rmr: float) -> RefTajeo:
    return min(TAJEOS, key=lambda t: distancia_rmr(rmr, list(t.rmr)))
