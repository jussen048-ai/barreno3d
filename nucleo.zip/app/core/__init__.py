"""Datos del proyecto: capas, objetos geométricos y selección. Sin interfaz."""
