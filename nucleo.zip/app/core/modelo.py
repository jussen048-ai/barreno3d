"""
Modelo de datos de Barreno 3D.

Este archivo NO depende de la interfaz (PySide6) ni del visor (PyVista).

Convenciones de coordenadas (metros):
- X = Este, Y = Norte, Z = Cota (elevación).
- Azimut: grados desde el Norte, en sentido horario (0° = Norte, 90° = Este).
- Inclinación: grados por debajo de la horizontal (90° = vertical hacia abajo,
  0° = horizontal, valores negativos = hacia arriba).
"""

import math
from dataclasses import dataclass, field

ESCENARIO_TAJO = "tajo"
ESCENARIO_SUBTERRANEO = "subterraneo"
NOMBRES_ESCENARIO = {
    ESCENARIO_TAJO: "Tajo abierto",
    ESCENARIO_SUBTERRANEO: "Minería subterránea",
}

TIPO_GRANEL = "granel"
TIPO_ENCARTUCHADO = "encartuchado"
NOMBRES_TIPO_EXPLOSIVO = {
    TIPO_GRANEL: "A granel (llena el taladro)",
    TIPO_ENCARTUCHADO: "Encartuchado",
}

FUNCIONES_POZO = [
    "Producción", "Amortiguado", "Precorte",          # tajo abierto
    "Arranque", "Alivio", "Ayuda", "Contorno", "Corona", "Arrastre",  # subterráneo
]


def num(valor: float | None, decimales: int = 2) -> str:
    """Formatea un número para mostrarlo en pantalla."""
    if valor is None:
        return "—"
    texto = f"{valor:.{decimales}f}"
    if texto.startswith("-") and float(texto) == 0:
        texto = texto[1:]
    return texto


@dataclass(frozen=True)
class Propiedad:
    """Una fila del panel de propiedades."""

    grupo: str
    nombre: str
    valor: str
    unidad: str = ""


@dataclass
class Capa:
    id: str
    nombre: str
    color: str
    visible: bool = True


@dataclass
class Explosivo:
    id: str
    nombre: str
    tipo: str = TIPO_GRANEL
    densidad_gcc: float = 0.8  # g/cm³
    diametro_cartucho_mm: float = 0.0  # solo encartuchados
    prp: float = 1.0  # potencia relativa en peso respecto al ANFO (ANFO = 1)
    aws: float = 1.0  # potencia absoluta en peso (Dynamex M = 1), Ec. 8 de Yilmaz (2023)
    vod_ms: float = 0.0  # velocidad de detonación (m/s); la usan Ash modificado y Pearse
    referencial: bool = False  # True = valor genérico, reemplazar con ficha técnica
    kg_cartucho: float = 0.0  # masa del cartucho según el fabricante (0 = se calcula con ρ·volumen)
    fuente: str = ""  # de dónde salen los datos (p. ej. ficha técnica del fabricante)

    def largo_cartucho_m(self) -> float:
        """Largo nominal del cartucho si el nombre lo indica como 1"x8" (pulgadas)."""
        import re
        m = re.search(r'(\d+(?:\.\d+)?)\s*"\s*[xX]\s*(\d+(?:\.\d+)?)\s*"', self.nombre)
        return float(m.group(2).replace(",", ".")) * 0.0254 if m else 0.0

    def diametro_de_carga(self, diametro_pozo_mm: float) -> float:
        if self.tipo == TIPO_ENCARTUCHADO and self.diametro_cartucho_mm > 0:
            return self.diametro_cartucho_mm
        return diametro_pozo_mm


@dataclass
class DisenoVoladura:
    """Parámetros de diseño de la voladura del proyecto."""

    escenario: str = ESCENARIO_TAJO
    densidad_roca: float = 2.6  # t/m³
    # Tajo abierto
    burden: float = 3.0  # m
    espaciamiento: float = 3.5  # m
    altura_banco: float = 10.0  # m
    # Subterráneo
    area_seccion: float = 16.0  # m²
    avance: float = 3.2  # m


@dataclass
class ConfigMapa:
    """Parámetros del mapa de vibración (ver app/calc/energia.py)."""

    activo: bool = False
    k: float = 700.0
    alfa: float = 0.7
    beta: float = 1.5
    umbrales: list[float] = field(default_factory=lambda: [254.0, 635.0, 2540.0])  # mm/s
    modo: str = "maximo"  # "maximo" (un pozo por retardo) o "suma" (todos a la vez)
    profundidad: float | None = None  # m desde el collar; None = mitad de la columna de carga
    resolucion: int = 160  # celdas en el lado más largo
    constantes_calibradas: bool = False


@dataclass(kw_only=True)
class ObjetoMinero:
    """Clase base de todos los objetos geométricos del proyecto."""

    TIPO = "Objeto"

    id: str
    nombre: str
    capa_id: str
    es_demo: bool = False  # True = dato de demostración

    def propiedades(self) -> list[Propiedad]:
        return []


@dataclass(kw_only=True)
class Perforacion(ObjetoMinero):
    TIPO = "Perforación"

    x: float
    y: float
    z: float
    azimut: float = 0.0  # °
    inclinacion: float = 90.0  # °
    longitud: float = 10.0  # m
    diametro_mm: float = 165.0  # mm
    explosivo_id: str | None = None  # None = pozo sin carga (p. ej. alivio)
    taco: float = 0.0  # m
    funcion: str = "Producción"
    # Carga de fondo + columna (Tabla 2 de Yilmaz, 2023). Por defecto: columna continua.
    carga_fondo: float = 0.0  # m de carga de fondo (concentración completa)
    factor_columna: float = 1.0  # concentración de la columna / concentración de fondo
    # Secuencia de salida (0 / None = sin asignar)
    retardo: int = 0  # número de retardo (como se rotula en el plano)
    tiempo_ms: float | None = None  # tiempo nominal de detonación (ms)
    # Datos de un plano de referencia documental (biblioteca de mallas)
    cartuchos: int = 0  # cartuchos según el rótulo del plano
    kg_documento: float | None = None  # kg de explosivo derivados de la tabla del plano
    origen: str = ""  # p. ej. "MIN-SOS-ESO-001 pág. 4 (digitalizado)"

    def collar(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.z)

    def direccion(self) -> tuple[float, float, float]:
        az = math.radians(self.azimut)
        inc = math.radians(self.inclinacion)
        return (math.cos(inc) * math.sin(az), math.cos(inc) * math.cos(az), -math.sin(inc))

    def fondo(self) -> tuple[float, float, float]:
        dx, dy, dz = self.direccion()
        return (self.x + dx * self.longitud, self.y + dy * self.longitud, self.z + dz * self.longitud)

    def propiedades(self) -> list[Propiedad]:
        fx, fy, fz = self.fondo()
        return [
            Propiedad("Collar (boca)", "Este X", num(self.x), "m"),
            Propiedad("Collar (boca)", "Norte Y", num(self.y), "m"),
            Propiedad("Collar (boca)", "Cota Z", num(self.z), "m"),
            Propiedad("Orientación y tamaño", "Azimut", num(self.azimut, 1), "°"),
            Propiedad("Orientación y tamaño", "Inclinación", num(self.inclinacion, 1), "°"),
            Propiedad("Orientación y tamaño", "Longitud", num(self.longitud), "m"),
            Propiedad("Orientación y tamaño", "Diámetro", num(self.diametro_mm, 0), "mm"),
            Propiedad("Fondo (geométrico)", "Este X", num(fx), "m"),
            Propiedad("Fondo (geométrico)", "Norte Y", num(fy), "m"),
            Propiedad("Fondo (geométrico)", "Cota Z", num(fz), "m"),
        ] + ([Propiedad("Referencia documental", "Origen", self.origen, ""),
              Propiedad("Referencia documental", "Cartuchos (rótulo)", f"{self.cartuchos}", "u"),
              Propiedad("Referencia documental", "Retardo / orden", f"{self.retardo}", "")]
             if self.origen else [])


@dataclass(kw_only=True)
class Superficie(ObjetoMinero):
    """Superficie en malla regular: una cota por nodo (filas = Y, columnas = X)."""

    TIPO = "Superficie"

    x0: float
    y0: float
    paso_x: float
    paso_y: float
    nx: int
    ny: int
    cotas: list[float] = field(default_factory=list)

    def propiedades(self) -> list[Propiedad]:
        x_fin = self.x0 + (self.nx - 1) * self.paso_x
        y_fin = self.y0 + (self.ny - 1) * self.paso_y
        return [
            Propiedad("Malla", "Nodos", f"{self.nx * self.ny}", "pts"),
            Propiedad("Malla", "Columnas × filas", f"{self.nx} × {self.ny}", ""),
            Propiedad("Malla", "Paso en X", num(self.paso_x), "m"),
            Propiedad("Malla", "Paso en Y", num(self.paso_y), "m"),
            Propiedad("Extensión", "Este X mín.", num(self.x0), "m"),
            Propiedad("Extensión", "Este X máx.", num(x_fin), "m"),
            Propiedad("Extensión", "Norte Y mín.", num(self.y0), "m"),
            Propiedad("Extensión", "Norte Y máx.", num(y_fin), "m"),
            Propiedad("Cotas", "Cota mínima", num(min(self.cotas)), "m"),
            Propiedad("Cotas", "Cota máxima", num(max(self.cotas)), "m"),
        ]


@dataclass(kw_only=True)
class Banco(ObjetoMinero):
    """Banco por línea de pie y de cresta (cara recta paralela al eje X, mira al sur)."""

    TIPO = "Banco"

    x_inicio: float
    x_fin: float
    y_pie: float
    cota_pie: float
    cota_cresta: float
    angulo_cara: float

    @property
    def altura(self) -> float:
        return self.cota_cresta - self.cota_pie

    @property
    def retiro_horizontal(self) -> float:
        return self.altura / math.tan(math.radians(self.angulo_cara))

    @property
    def y_cresta(self) -> float:
        return self.y_pie + self.retiro_horizontal

    def linea_pie(self):
        return ((self.x_inicio, self.y_pie, self.cota_pie), (self.x_fin, self.y_pie, self.cota_pie))

    def linea_cresta(self):
        return (
            (self.x_inicio, self.y_cresta, self.cota_cresta),
            (self.x_fin, self.y_cresta, self.cota_cresta),
        )

    def propiedades(self) -> list[Propiedad]:
        return [
            Propiedad("Cotas", "Cota de cresta", num(self.cota_cresta), "m"),
            Propiedad("Cotas", "Cota de pie", num(self.cota_pie), "m"),
            Propiedad("Geometría", "Altura de banco", num(self.altura), "m"),
            Propiedad("Geometría", "Ángulo de cara", num(self.angulo_cara, 1), "°"),
            Propiedad("Geometría", "Retiro horizontal", num(self.retiro_horizontal), "m"),
            Propiedad("Geometría", "Longitud", num(self.x_fin - self.x_inicio), "m"),
        ]


@dataclass(kw_only=True)
class Contorno(ObjetoMinero):
    """Polilínea cerrada en 3D: polígono de voladura (tajo) o sección del frente (subterráneo)."""

    TIPO = "Contorno"

    vertices: list[tuple[float, float, float]] = field(default_factory=list)

    def area(self) -> float:
        """Área de un polígono plano en 3D (método de Newell)."""
        sx = sy = sz = 0.0
        n = len(self.vertices)
        for k in range(n):
            x1, y1, z1 = self.vertices[k]
            x2, y2, z2 = self.vertices[(k + 1) % n]
            sx += y1 * z2 - z1 * y2
            sy += z1 * x2 - x1 * z2
            sz += x1 * y2 - y1 * x2
        return 0.5 * math.sqrt(sx * sx + sy * sy + sz * sz)

    def perimetro(self) -> float:
        n = len(self.vertices)
        return sum(math.dist(self.vertices[k], self.vertices[(k + 1) % n]) for k in range(n))

    def propiedades(self) -> list[Propiedad]:
        return [
            Propiedad("Geometría", "Vértices", f"{len(self.vertices)}", ""),
            Propiedad("Geometría", "Área", num(self.area(), 2), "m²"),
            Propiedad("Geometría", "Perímetro", num(self.perimetro(), 2), "m"),
        ]


@dataclass(kw_only=True)
class PolilineaCAD(ObjetoMinero):
    """Polilínea importada de CAD (curva de nivel, cresta, pie, eje...). Coordenadas en m."""

    TIPO = "Polilínea CAD"

    vertices: list[tuple[float, float, float]] = field(default_factory=list)
    cerrada: bool = False
    capa_cad: str = ""
    archivo: str = ""

    def longitud(self) -> float:
        n = len(self.vertices)
        tramos = range(n if self.cerrada else n - 1)
        return sum(math.dist(self.vertices[k], self.vertices[(k + 1) % n]) for k in tramos)

    def propiedades(self) -> list[Propiedad]:
        zs = [v[2] for v in self.vertices] or [0.0]
        return [
            Propiedad("CAD", "Capa de origen", self.capa_cad, ""),
            Propiedad("CAD", "Archivo", self.archivo.split("/")[-1].split("\\")[-1], ""),
            Propiedad("Geometría", "Vértices", f"{len(self.vertices)}", ""),
            Propiedad("Geometría", "Longitud 3D", num(self.longitud()), "m"),
            Propiedad("Geometría", "Cerrada", "Sí" if self.cerrada else "No", ""),
            Propiedad("Cotas", "Cota mínima", num(min(zs)), "m"),
            Propiedad("Cotas", "Cota máxima", num(max(zs)), "m"),
        ]


@dataclass(kw_only=True)
class PuntosCAD(ObjetoMinero):
    """Puntos topográficos o textos de cota importados de CAD."""

    TIPO = "Puntos CAD"

    puntos: list[tuple[float, float, float]] = field(default_factory=list)
    textos: list[str] = field(default_factory=list)
    capa_cad: str = ""
    archivo: str = ""

    def propiedades(self) -> list[Propiedad]:
        zs = [p[2] for p in self.puntos] or [0.0]
        return [
            Propiedad("CAD", "Capa de origen", self.capa_cad, ""),
            Propiedad("Geometría", "Puntos", f"{len(self.puntos)}", ""),
            Propiedad("Cotas", "Cota mínima", num(min(zs)), "m"),
            Propiedad("Cotas", "Cota máxima", num(max(zs)), "m"),
        ]


@dataclass(kw_only=True)
class SuperficieTIN(ObjetoMinero):
    """Superficie triangulada (TIN): vértices X, Y, Z (m) y triángulos (índices)."""

    TIPO = "Superficie TIN"

    vertices: list[tuple[float, float, float]] = field(default_factory=list)
    triangulos: list[tuple[int, int, int]] = field(default_factory=list)
    fuente: str = ""
    colorear: str = "cota"  # "cota" o "pendiente"
    umbral_bajo: float = 15.0  # ° (plataforma/berma)
    umbral_alto: float = 45.0  # ° (talud / cara de banco)

    def propiedades(self) -> list[Propiedad]:
        zs = [v[2] for v in self.vertices] or [0.0]
        return [
            Propiedad("TIN", "Fuente", self.fuente, ""),
            Propiedad("TIN", "Vértices", f"{len(self.vertices)}", ""),
            Propiedad("TIN", "Triángulos", f"{len(self.triangulos)}", ""),
            Propiedad("Cotas", "Cota mínima", num(min(zs)), "m"),
            Propiedad("Cotas", "Cota máxima", num(max(zs)), "m"),
            Propiedad("Pendientes", "Plataforma ≤", num(self.umbral_bajo, 0), "°"),
            Propiedad("Pendientes", "Talud ≥", num(self.umbral_alto, 0), "°"),
        ]


CLASES_OBJETO = {cls.__name__: cls for cls in (Perforacion, Superficie, Banco, Contorno, PolilineaCAD,
                                               PuntosCAD, SuperficieTIN)}

CAPAS_BASE = [
    ("topografia", "Topografía", "#8c7a64"),
    ("bancos", "Bancos", "#d5d9de"),
    ("contornos", "Contornos y secciones", "#3a8dde"),
    ("perforaciones", "Perforaciones", "#2bb3a8"),
]


@dataclass
class Proyecto:
    nombre: str
    escenario_demo: bool = False
    capas: list[Capa] = field(default_factory=list)
    objetos: dict[str, ObjetoMinero] = field(default_factory=dict)
    explosivos: list[Explosivo] = field(default_factory=list)
    diseno: DisenoVoladura = field(default_factory=DisenoVoladura)
    mapa: ConfigMapa = field(default_factory=ConfigMapa)

    # --- capas
    def agregar_capa(self, capa: Capa) -> None:
        if self.capa(capa.id) is not None:
            raise ValueError(f"Ya existe una capa con id '{capa.id}'")
        self.capas.append(capa)

    def asegurar_capas_base(self) -> None:
        for capa_id, nombre, color in CAPAS_BASE:
            if self.capa(capa_id) is None:
                self.capas.append(Capa(id=capa_id, nombre=nombre, color=color))

    def capa(self, capa_id: str) -> Capa | None:
        return next((c for c in self.capas if c.id == capa_id), None)

    # --- objetos
    def agregar_objeto(self, objeto: ObjetoMinero) -> None:
        if self.capa(objeto.capa_id) is None:
            raise ValueError(f"La capa '{objeto.capa_id}' no existe")
        if objeto.id in self.objetos:
            raise ValueError(f"Ya existe un objeto con id '{objeto.id}'")
        self.objetos[objeto.id] = objeto

    def eliminar_objeto(self, objeto_id: str) -> None:
        self.objetos.pop(objeto_id, None)

    def objeto(self, objeto_id: str | None) -> ObjetoMinero | None:
        if objeto_id is None:
            return None
        return self.objetos.get(objeto_id)

    def objetos_de_capa(self, capa_id: str) -> list[ObjetoMinero]:
        return [o for o in self.objetos.values() if o.capa_id == capa_id]

    def perforaciones(self) -> list[Perforacion]:
        return [o for o in self.objetos.values() if isinstance(o, Perforacion)]

    def nuevo_id_pozo(self) -> str:
        n = 1
        while f"P-{n:02d}" in self.objetos:
            n += 1
        return f"P-{n:02d}"

    # --- explosivos
    def explosivo(self, explosivo_id: str | None) -> Explosivo | None:
        if explosivo_id is None:
            return None
        return next((e for e in self.explosivos if e.id == explosivo_id), None)

    def explosivo_por_nombre(self, nombre: str) -> Explosivo | None:
        nombre = nombre.strip().lower()
        return next((e for e in self.explosivos if e.nombre.strip().lower() == nombre), None)

    def nuevo_id_explosivo(self) -> str:
        n = 1
        while self.explosivo(f"EXP-{n:02d}") is not None:
            n += 1
        return f"EXP-{n:02d}"
