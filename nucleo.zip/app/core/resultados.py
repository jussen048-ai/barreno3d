"""
Resultados de carga calculados a partir del proyecto.

Une los datos (modelo) con el motor de cálculo (app.calc.carga).
Las fórmulas, supuestos y fuentes están documentados en app/calc/carga.py.
"""

from dataclasses import dataclass

from app.calc import carga as calc
from app.core.modelo import (
    ESCENARIO_SUBTERRANEO,
    ESCENARIO_TAJO,
    NOMBRES_ESCENARIO,
    NOMBRES_TIPO_EXPLOSIVO,
    Contorno,
    ObjetoMinero,
    Perforacion,
    Propiedad,
    Proyecto,
    num,
)


@dataclass
class CargaPozo:
    cargado: bool
    explosivo_nombre: str = "Sin carga"
    densidad_gcc: float | None = None
    diametro_carga_mm: float | None = None
    longitud_carga: float = 0.0
    carga_lineal: float | None = None  # kg/m
    carga: float = 0.0  # kg
    volumen: float | None = None  # m³ (solo tajo)
    factor_carga: float | None = None  # kg/m³ (solo tajo)
    error: str = ""


@dataclass
class ResumenVoladura:
    escenario: str
    pozos_total: int = 0
    pozos_cargados: int = 0
    carga_total: float = 0.0  # kg
    metros_perforados: float = 0.0  # m
    volumen: float | None = None  # m³
    tonelaje: float | None = None  # t
    factor_carga: float | None = None  # kg/m³
    factor_potencia: float | None = None  # kg/t
    error: str = ""


def _carga_fondo_columna(q: float, lc: float, fondo: float, factor_columna: float) -> float:
    """Carga de fondo (q completa) + columna (q × factor). Sin fondo = columna continua."""
    if fondo <= 0 and factor_columna == 1.0:
        return calc.carga_por_pozo(q, lc)
    hb = min(max(fondo, 0.0), lc)
    return q * hb + q * max(factor_columna, 0.0) * (lc - hb)


def carga_de_pozo(proyecto: Proyecto, pozo: Perforacion) -> CargaPozo:
    explosivo = proyecto.explosivo(pozo.explosivo_id)
    if explosivo is None:
        return CargaPozo(cargado=False)
    if pozo.kg_documento is not None:
        # Plano de referencia: la carga viene de la tabla del documento (kg/cartucho × cartuchos)
        lc = min(pozo.cartuchos * explosivo.largo_cartucho_m(), pozo.longitud) if explosivo.largo_cartucho_m() \
            else 0.0
        return CargaPozo(cargado=pozo.kg_documento > 0, explosivo_nombre=explosivo.nombre,
                         densidad_gcc=explosivo.densidad_gcc, diametro_carga_mm=explosivo.diametro_cartucho_mm or None,
                         longitud_carga=lc, carga_lineal=(pozo.kg_documento / lc) if lc > 0 else None,
                         carga=pozo.kg_documento)
    try:
        d_carga = explosivo.diametro_de_carga(pozo.diametro_mm)
        q = calc.carga_lineal(d_carga, explosivo.densidad_gcc)
        if explosivo.kg_cartucho > 0 and explosivo.largo_cartucho_m() > 0 and explosivo.diametro_cartucho_mm > 0:
            q = explosivo.kg_cartucho / explosivo.largo_cartucho_m()  # masa real del cartucho (ficha del fabricante)
        lc = calc.longitud_de_carga(pozo.longitud, pozo.taco)
        resultado = CargaPozo(
            cargado=lc > 0,
            explosivo_nombre=explosivo.nombre,
            densidad_gcc=explosivo.densidad_gcc,
            diametro_carga_mm=d_carga,
            longitud_carga=lc,
            carga_lineal=q,
            carga=_carga_fondo_columna(q, lc, pozo.carga_fondo, pozo.factor_columna),
        )
        d = proyecto.diseno
        if d.escenario == ESCENARIO_TAJO:
            resultado.volumen = calc.volumen_tajo(d.burden, d.espaciamiento, d.altura_banco)
            resultado.factor_carga = calc.factor_de_carga(resultado.carga, resultado.volumen)
        return resultado
    except calc.ErrorDeDatos as error:
        return CargaPozo(cargado=False, explosivo_nombre=explosivo.nombre, error=str(error))


def resumen_voladura(proyecto: Proyecto) -> ResumenVoladura:
    d = proyecto.diseno
    resumen = ResumenVoladura(escenario=d.escenario)
    pozos = proyecto.perforaciones()
    resumen.pozos_total = len(pozos)
    for pozo in pozos:
        resumen.metros_perforados += pozo.longitud
        cp = carga_de_pozo(proyecto, pozo)
        if cp.cargado:
            resumen.pozos_cargados += 1
            resumen.carga_total += cp.carga
    try:
        if d.escenario == ESCENARIO_TAJO:
            if resumen.pozos_cargados == 0:
                return resumen
            resumen.volumen = resumen.pozos_cargados * calc.volumen_tajo(
                d.burden, d.espaciamiento, d.altura_banco
            )
        else:
            resumen.volumen = calc.volumen_subterraneo(d.area_seccion, d.avance)
        resumen.tonelaje = calc.tonelaje(resumen.volumen, d.densidad_roca)
        resumen.factor_carga = calc.factor_de_carga(resumen.carga_total, resumen.volumen)
        resumen.factor_potencia = calc.factor_de_potencia(resumen.carga_total, resumen.tonelaje)
    except calc.ErrorDeDatos as error:
        resumen.error = str(error)
    return resumen


def propiedades_resumen(proyecto: Proyecto) -> list[Propiedad]:
    """Filas con los parámetros de diseño y el resumen de la voladura."""
    d = proyecto.diseno
    r = resumen_voladura(proyecto)
    filas = [Propiedad("Diseño de voladura", "Escenario", NOMBRES_ESCENARIO.get(d.escenario, d.escenario))]
    if d.escenario == ESCENARIO_TAJO:
        filas += [
            Propiedad("Diseño de voladura", "Burden", num(d.burden), "m"),
            Propiedad("Diseño de voladura", "Espaciamiento", num(d.espaciamiento), "m"),
            Propiedad("Diseño de voladura", "Altura de banco", num(d.altura_banco), "m"),
        ]
    else:
        filas += [
            Propiedad("Diseño de voladura", "Área de la sección", num(d.area_seccion), "m²"),
            Propiedad("Diseño de voladura", "Avance por disparo", num(d.avance), "m"),
        ]
    filas += [
        Propiedad("Diseño de voladura", "Densidad de la roca", num(d.densidad_roca), "t/m³"),
        Propiedad("Resultados del disparo", "Taladros (cargados / total)",
                  f"{r.pozos_cargados} / {r.pozos_total}", ""),
        Propiedad("Resultados del disparo", "Metros perforados", num(r.metros_perforados, 1), "m"),
        Propiedad("Resultados del disparo", "Explosivo total", num(r.carga_total, 1), "kg"),
        Propiedad("Resultados del disparo", "Volumen arrancado", num(r.volumen, 1), "m³"),
        Propiedad("Resultados del disparo", "Tonelaje", num(r.tonelaje, 1), "t"),
        Propiedad("Resultados del disparo", "Factor de carga", num(r.factor_carga, 3), "kg/m³"),
        Propiedad("Resultados del disparo", "Factor de potencia", num(r.factor_potencia, 3), "kg/t"),
    ]
    if r.error:
        filas.append(Propiedad("Resultados del disparo", "⚠ Revisar", r.error, ""))
    return filas


def propiedades_completas(proyecto: Proyecto, objeto: ObjetoMinero) -> list[Propiedad]:
    filas = list(objeto.propiedades())
    if isinstance(objeto, Perforacion):
        cp = carga_de_pozo(proyecto, objeto)
        explosivo = proyecto.explosivo(objeto.explosivo_id)
        filas.insert(0, Propiedad("Carga", "Función", objeto.funcion, ""))
        grupo = "Carga"
        filas[1:1] = [
            Propiedad(grupo, "Explosivo", cp.explosivo_nombre, ""),
            Propiedad(grupo, "Tipo", NOMBRES_TIPO_EXPLOSIVO.get(explosivo.tipo, "") if explosivo else "—", ""),
            Propiedad(grupo, "Densidad explosivo", num(cp.densidad_gcc), "g/cm³"),
            Propiedad(grupo, "Diámetro de carga", num(cp.diametro_carga_mm, 0), "mm"),
            Propiedad(grupo, "Taco", num(objeto.taco), "m"),
            Propiedad(grupo, "Longitud de carga", num(cp.longitud_carga), "m"),
            Propiedad(grupo, "Carga lineal", num(cp.carga_lineal, 3), "kg/m"),
            Propiedad(grupo, "Carga del taladro", num(cp.carga, 2), "kg"),
        ]
        if proyecto.diseno.escenario == ESCENARIO_TAJO and cp.volumen is not None:
            filas[9:9] = [
                Propiedad(grupo, "Volumen (B × S × H)", num(cp.volumen, 1), "m³"),
                Propiedad(grupo, "Factor de carga del taladro", num(cp.factor_carga, 3), "kg/m³"),
            ]
        if cp.error:
            filas.insert(1, Propiedad(grupo, "⚠ Revisar", cp.error, ""))
    elif isinstance(objeto, Contorno):
        filas += propiedades_resumen(proyecto)
    return filas


ESCENARIOS = (ESCENARIO_TAJO, ESCENARIO_SUBTERRANEO)
