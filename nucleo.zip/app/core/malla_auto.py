"""
Malla automática: con pocos datos genera todos los pozos y una ficha de resultados.

Subterráneo: arranque de taladros paralelos con alivio central y resto del frente por
zonas, según Yilmaz (2023), Scientific Reports 13:2449 (Holmberg, Olofsson, Persson).
Tajo abierto: método de Konya.
Fórmulas, fuentes y estado de verificación en app/calc/diseno_automatico.py.
"""

import math
from dataclasses import dataclass, field, replace

from app.calc import carga as calc
from app.calc import diseno_automatico as da
from app.calc import roca as rc
from app.core.generador import ParamMallaTajo, posiciones_tajo, seccion_baul
from app.core.modelo import Contorno, Explosivo, Perforacion


@dataclass
class FilaFicha:
    zona: str
    concepto: str
    valor: float | str
    unidad: str = ""
    formula: str = ""


@dataclass
class PozoAuto:
    s: float  # horizontal en la cara (subterráneo) o Este (tajo)
    h: float  # altura sobre el piso (subterráneo) o Norte (tajo)
    funcion: str
    taco: float
    alivio: bool = False
    explosivo: str = "principal"  # "principal" | "contorno" | ""
    carga_fondo: float | None = 0.0  # m (None = se asigna después)
    factor_columna: float = 1.0


@dataclass
class ResultadoMalla:
    pozos: list[PozoAuto] = field(default_factory=list)
    ficha: list[FilaFicha] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)
    seccion: list[tuple[float, float]] = field(default_factory=list)
    cuadros: list[list[tuple[float, float]]] = field(default_factory=list)


# ======================================================================= frente
@dataclass
class Roca:
    """Calidad del macizo rocoso (para diseñar según el tipo de roca)."""

    rmr: float = 50.0
    rqd: float = 60.0  # %
    gsi: float = 0.0  # 0 = estimarlo como RMR − 5
    densidad: float = 2.6  # t/m³
    dureza: str = "Auto"  # Auto (según la clase) / Dura / Semidura / Blanda (para la tabla EXSA)


@dataclass
class EvaluacionRoca:
    clase: str
    descripcion: str
    gsi: float
    jv: float
    consumo_especifico: float
    c: float
    factor_burden: float
    dureza: str


def evaluar_roca(roca: Roca) -> EvaluacionRoca:
    clase, descripcion = rc.clase_rmr(roca.rmr)
    gsi = roca.gsi if roca.gsi > 0 else rc.gsi_desde_rmr(roca.rmr)
    ce = rc.consumo_especifico_ashby(roca.densidad, gsi, roca.rqd)
    c = rc.constante_roca(ce)
    dureza = rc.DUREZA_POR_CLASE[clase] if roca.dureza == "Auto" else roca.dureza
    return EvaluacionRoca(clase, descripcion, gsi, rc.juntas_por_m3(roca.rqd), ce, c,
                          rc.factor_burden_roca(c), dureza)


def _ficha_roca(ficha, roca: Roca, ev: EvaluacionRoca) -> None:
    ficha(FilaFicha("Roca", "Clase RMR", f"{ev.clase} · {ev.descripcion} (RMR {roca.rmr:g})", "",
                    "Bieniawski (1989)"))
    ficha(FilaFicha("Roca", "GSI", ev.gsi, "", "dato" if roca.gsi > 0 else "RMR − 5 (Hoek et al., 1995)"))
    ficha(FilaFicha("Roca", "Juntas por m³ (Jv)", ev.jv, "", "(115 − RQD)/3.3"))
    ficha(FilaFicha("Roca", "Consumo específico (Ashby)", ev.consumo_especifico, "kg/m³",
                    "0.56·ρ·tan((GSI+15)/2)/∛Jv"))
    ficha(FilaFicha("Roca", "Constante de roca c", ev.c, "kg/m³", "0.8784·CE + 0.052"))


@dataclass
class EntradaFrente:
    ancho: float = 4.0  # m
    alto: float = 4.0  # m, altura total en el eje
    flecha: float = 1.0  # m: altura del arco (baúl) o radio de las esquinas (0 = rectangular)
    forma: str = "Baúl (arco)"  # o "Esquinas redondeadas"
    diametro_mm: float = 45.0  # perforación
    diametro_alivio_mm: float = 102.0
    n_alivios: int = 1
    longitud: float = 3.5  # m, perforación
    # Constantes del método (editables en "Opciones avanzadas")
    c_roca: float = da.C_ROCA
    alfa: float = 0.01  # m/m, desviación angular
    emboquille: float = 0.02  # m, error de emboquille β
    # True: el explosivo llena el taladro (granel o cartuchos atacados, como en el artículo).
    # False: cartuchos sin atacar → la carga de fondo se calcula con el diámetro del cartucho.
    atacado: bool = False
    roca: Roca | None = None  # si se indica, c y el burden se ajustan a la roca


def _q(explosivo: Explosivo | None, diametro_mm: float) -> tuple[float, float]:
    if explosivo is None:
        raise calc.ErrorDeDatos("Elige un explosivo (Editar → Explosivos para registrarlo)")
    q = calc.carga_lineal(explosivo.diametro_de_carga(diametro_mm), explosivo.densidad_gcc)
    return q, max(explosivo.prp, 1e-6)


def _repartir(polilinea, separacion: float, cerrada: bool, incluir_extremos: bool = True):
    """Puntos equiespaciados sobre una polilínea (s, h)."""
    pts = list(polilinea) + ([polilinea[0]] if cerrada else [])
    tramos = list(zip(pts, pts[1:]))
    largos = [math.dist(a, b) for a, b in tramos]
    total = sum(largos)
    if total <= 0:
        return []
    if cerrada:
        n = max(4, round(total / separacion))
        n += n % 2  # número par: simetría respecto al eje vertical
        objetivos = [total * i / n for i in range(n)]
    else:
        n = max(1, math.ceil(total / separacion - 1e-9))
        objetivos = [total * i / n for i in range(n + 1)]
        if not incluir_extremos:
            objetivos = objetivos[1:-1]
    salida = []
    for objetivo in objetivos:
        acumulado = 0.0
        for (a, b), largo in zip(tramos, largos):
            if acumulado + largo >= objetivo - 1e-9 and largo > 0:
                t = min(max((objetivo - acumulado) / largo, 0.0), 1.0)
                salida.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
                break
            acumulado += largo
    return salida


def _dentro(punto, poligono) -> bool:
    """Prueba de punto en polígono (rayo horizontal)."""
    x, y = punto
    dentro = False
    n = len(poligono)
    for i in range(n):
        x1, y1 = poligono[i]
        x2, y2 = poligono[(i + 1) % n]
        if (y1 > y) != (y2 > y) and x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
            dentro = not dentro
    return dentro


FORMAS_SECCION = ["Baúl (arco)", "Esquinas redondeadas"]


def seccion_frente(e: "EntradaFrente", n_arco: int = 16):
    """Contorno (s, h) en sentido antihorario: piso izq. → piso der. → pared der. →
    techo → pared izq. La parte superior empieza en (semi, hastial) y termina en (−semi, hastial)."""
    semi = e.ancho / 2
    if e.forma == "Esquinas redondeadas":
        radio = max(0.0, min(e.flecha, semi, e.alto))
        if radio <= 0:
            return [(-semi, 0.0), (semi, 0.0), (semi, e.alto), (-semi, e.alto)]
        hc = e.alto - radio
        derecha = [(semi - radio + radio * math.cos(math.radians(90 * k / 8)),
                    hc + radio * math.sin(math.radians(90 * k / 8))) for k in range(9)]
        izquierda = [(-semi + radio + radio * math.cos(math.radians(90 + 90 * k / 8)),
                      hc + radio * math.sin(math.radians(90 + 90 * k / 8))) for k in range(9)]
        return [(-semi, 0.0), (semi, 0.0), *derecha, *izquierda]
    return seccion_baul(e.ancho, e.alto - e.flecha, e.flecha, n_arco)


def _recortar(poligono, punto, normal):
    """Sutherland–Hodgman: conserva la parte con (p − punto)·normal ≥ 0."""
    salida = []
    n = len(poligono)
    for i in range(n):
        a, b = poligono[i], poligono[(i + 1) % n]
        da_ = (a[0] - punto[0]) * normal[0] + (a[1] - punto[1]) * normal[1]
        db_ = (b[0] - punto[0]) * normal[0] + (b[1] - punto[1]) * normal[1]
        if da_ >= 0:
            salida.append(a)
        if (da_ >= 0) != (db_ >= 0):
            t = da_ / (da_ - db_)
            salida.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    return salida


def _anillo(e: EntradaFrente, d_techo: float, d_piso: float):
    """Contorno interior: a d_techo de paredes y techo y a d_piso del piso (sección convexa)."""
    seccion = seccion_frente(e)
    poligono = [(-1e3, -1e3), (1e3, -1e3), (1e3, 1e3), (-1e3, 1e3)]
    n = len(seccion)
    for i in range(n):
        (x1, y1), (x2, y2) = seccion[i], seccion[(i + 1) % n]
        largo = math.hypot(x2 - x1, y2 - y1)
        if largo < 1e-9:
            continue
        normal = (-(y2 - y1) / largo, (x2 - x1) / largo)  # hacia adentro (antihorario)
        d = d_piso if abs(y1) < 1e-9 and abs(y2) < 1e-9 else d_techo
        poligono = _recortar(poligono, (x1 + normal[0] * d, y1 + normal[1] * d), normal)
        if len(poligono) < 3:
            return None
    xs = [p[0] for p in poligono]
    hs = [p[1] for p in poligono]
    if max(xs) - min(xs) < 0.1 or max(hs) - min(hs) < 0.1:
        return None
    # Ordenar empezando en el centro del piso (reparto simétrico de puntos)
    piso = min(hs)
    resto = [p for p in poligono if p[1] > piso + 1e-9]
    resto.sort(key=lambda p: math.atan2(p[1] - (piso + max(hs)) / 2, p[0]))
    abajo = sorted([p for p in poligono if p[1] <= piso + 1e-9])
    derecha_abajo, izquierda_abajo = abajo[-1], abajo[0]
    arriba = [p for p in resto]
    arriba.sort(key=lambda p: (math.atan2(p[1] - piso, p[0] - 0.0)))
    return [(0.0, piso), derecha_abajo, *arriba, izquierda_abajo]


def _cubrir_huecos(r: "ResultadoMalla", zona, burden: float, b_teorico: float,
                   h_c: float, radio_arranque: float, paso: float = 0.04, caja=None) -> int:
    """Agrega ayudas (en pares simétricos) donde algún punto de 'zona' queda a más de
    'burden' del taladro cargado más cercano."""
    import numpy as np

    xs = [p[0] for p in zona]
    hs = [p[1] for p in zona]
    puntos = np.array([(x, h)
                       for x in _rango(min(xs), max(xs), paso)
                       for h in _rango(min(hs), max(hs), paso)
                       if _dentro((x, h), zona)
                       and not (caja is not None and _dentro((x, h), caja))
                       and (caja is not None or math.hypot(x, h - h_c) > radio_arranque)])
    if len(puntos) == 0:
        return 0
    cargados = np.array([(p.s, p.h) for p in r.pozos if not p.alivio])
    dist = np.full(len(puntos), np.inf)
    if len(cargados):
        dist = np.min(np.hypot(puntos[:, None, 0] - cargados[None, :, 0],
                               puntos[:, None, 1] - cargados[None, :, 1]), axis=1)
    agregadas = 0
    for _ in range(200):
        i = int(np.argmax(dist))
        if dist[i] <= burden + 1e-9:
            break
        x, h = float(puntos[i, 0]), float(puntos[i, 1])
        nuevos = [(x, h), (-x, h)] if abs(x) > paso else [(0.0, h)]
        for s_n, h_n in nuevos:
            r.pozos.append(PozoAuto(s_n, h_n, "Ayuda", 0.5 * b_teorico))
            agregadas += 1
            dist = np.minimum(dist, np.hypot(puntos[:, 0] - s_n, puntos[:, 1] - h_n))
    return agregadas


def _rango(inicio: float, fin: float, paso: float):
    n = int((fin - inicio) / paso) + 1
    return [inicio + k * paso for k in range(n + 1)]


def _alivios_agrupados(n: int, diametro: float, separacion_borde: float):
    """Alivios: 1 al centro; varios, juntos en un polígono regular centrado
    (simétrico respecto al eje vertical), nunca en fila horizontal."""
    if n <= 1:
        return [(0.0, 0.0)]
    paso = diametro + separacion_borde  # entre centros vecinos
    radio = paso / (2 * math.sin(math.pi / n))
    return [(radio * math.cos(math.radians(90 + 360 * k / n)),
             radio * math.sin(math.radians(90 + 360 * k / n))) for k in range(n)]


def _ancho_en(anillo, h: float) -> float | None:
    """Semiancho del polígono 'anillo' a la altura h (None si h queda fuera)."""
    cortes = []
    n = len(anillo)
    for i in range(n):
        (x1, y1), (x2, y2) = anillo[i], anillo[(i + 1) % n]
        if (y1 - h) * (y2 - h) <= 0 and y1 != y2:
            cortes.append(x1 + (h - y1) * (x2 - x1) / (y2 - y1))
    if len(cortes) < 2:
        return None
    return (max(cortes) - min(cortes)) / 2


def _uniformes(inicio: float, fin: float, separacion_max: float) -> list[float]:
    """Valores equiespaciados entre inicio y fin (incluidos) sin pasar la separación."""
    largo = fin - inicio
    if largo <= 1e-9:
        return [inicio]
    n = max(1, math.ceil(largo / separacion_max - 1e-9))
    return [inicio + largo * k / n for k in range(n + 1)]


def disenar_frente(e: EntradaFrente, principal: Explosivo | None,
                   contorno_exp: Explosivo | None = None) -> ResultadoMalla:
    """Arranque de taladros paralelos con alivio central y resto del frente por zonas,
    según Yilmaz (2023), Sci. Rep. 13:2449 (Ec. 1–8 y Tabla 2)."""
    if e.alto <= e.flecha:
        raise calc.ErrorDeDatos("La altura total debe ser mayor que la altura del arco / radio")
    if e.forma == "Esquinas redondeadas" and e.flecha > e.ancho / 2 + 1e-9:
        raise calc.ErrorDeDatos("El radio de las esquinas no puede pasar de la mitad del ancho")
    for nombre, v in (("El ancho", e.ancho), ("La altura", e.alto),
                      ("La longitud de perforación", e.longitud)):
        if v <= 0:
            raise calc.ErrorDeDatos(f"{nombre} debe ser mayor que cero")
    if principal is None:
        raise calc.ErrorDeDatos("Elige un explosivo (Editar → Explosivos para registrarlo)")
    contorno_exp = contorno_exp or principal
    r = ResultadoMalla()
    ficha = r.ficha.append
    ev_roca = None
    if e.roca is not None:
        ev_roca = evaluar_roca(e.roca)
        e = replace(e, c_roca=ev_roca.c)
        _ficha_roca(ficha, e.roca, ev_roca)
        if not 0.2 <= ev_roca.c <= 0.6:
            r.avisos.append(
                f"La constante de roca calculada (c = {ev_roca.c:.2f}) está fuera del rango habitual "
                "(≈ 0.3–0.4 en la mayoría de rocas, Langefors): el número de taladros puede quedar "
                "alto (roca muy buena) o bajo (roca muy mala). Contrasta con la comparación EXSA.")
    dh = e.diametro_mm / 1000
    hastial = e.alto - e.flecha
    semi = e.ancho / 2
    r.seccion = seccion_frente(e)
    area = Contorno(id="_", nombre="_", capa_id="_",
                    vertices=[(s, 0.0, h) for s, h in r.seccion]).area()

    # ---------------- avance (Ec. 1, 2)
    d0 = e.diametro_alivio_mm / 1000
    d0_eq = da.diametro_equivalente(d0, e.n_alivios)
    h_max = da.perforacion_maxima(d0_eq)
    f_err = da.error_perforacion(e.longitud, e.alfa, e.emboquille)
    avance = 0.95 * e.longitud
    ficha(FilaFicha("Sección", "Área de la sección", area, "m²"))
    ficha(FilaFicha("Avance", "Diámetro del alivio (equivalente)", d0_eq * 1000, "mm",
                    "D0" if e.n_alivios == 1 else "φ·√N"))
    ficha(FilaFicha("Avance", "Perforación máxima que permite el alivio", h_max, "m",
                    "0.15 + 34.1·D0 − 39.4·D0²  (Ec. 2)"))
    ficha(FilaFicha("Avance", "Perforación usada H", e.longitud, "m"))
    ficha(FilaFicha("Avance", "Avance esperado I", avance, "m", "0.95·H  (Ec. 1)"))
    ficha(FilaFicha("Avance", "Desviación de perforación", f_err, "m", "α·H + β"))
    if e.longitud > h_max + 1e-9:
        d_necesario = da.alivio_necesario(e.longitud)
        n_necesarios = math.ceil((d_necesario / d0) ** 2 - 1e-9)
        r.avisos.append(
            f"La perforación ({e.longitud:.2f} m) supera la que permite el alivio "
            f"({h_max:.2f} m, Ec. 2). Para {e.longitud:.2f} m se necesita un alivio de "
            f"{d_necesario * 1000:.0f} mm (rimado) o {n_necesarios} alivios de "
            f"{e.diametro_alivio_mm:g} mm; o perfora como máximo {h_max:.2f} m.")
    if not da.D0_MIN <= d0_eq <= da.D0_MAX:
        r.avisos.append(f"El alivio equivalente ({d0_eq * 1000:.0f} mm) está fuera del rango de la "
                        "Ec. 2 (50–250 mm): el avance estimado es solo orientativo.")

    # ---------------- explosivo y burden general (Ec. 7, 8)
    d_carga = principal.diametro_de_carga(e.diametro_mm)
    q_real = calc.carga_lineal(d_carga, principal.densidad_gcc)
    # Ec. 8: qb con el diámetro del taladro si el explosivo lo llena (granel o atacado, como en
    # el artículo); con cartuchos sin atacar, con el diámetro real del cartucho.
    d_qb = e.diametro_mm if e.atacado else d_carga
    qb = da.carga_fondo(d_qb, principal.densidad_gcc, max(principal.aws, 1e-6))
    b = da.burden_frente(qb, e.diametro_mm)
    if ev_roca is not None:
        b_ref = b
        b = b * ev_roca.factor_burden
        ficha(FilaFicha("Roca", "Corrección del burden por la roca", ev_roca.factor_burden, "",
                        f"√(0.45/c̄): {b_ref:.2f} → {b:.2f} m"))
    ficha(FilaFicha("Explosivo", "Carga lineal del explosivo", q_real, "kg/m", "π/4·d²·ρ"))
    ficha(FilaFicha("Explosivo", "Carga de fondo equivalente qb", qb, "kg/m",
                    ("π/4·dh²·ρ·AWS  (Ec. 8, taladro lleno)" if e.atacado or d_carga == e.diametro_mm
                     else f"π/4·d²·ρ·AWS  (Ec. 8, cartucho de {d_carga:g} mm)")))
    ficha(FilaFicha("Frente", "Burden B", b, "m", "30·qb/dh  (Ec. 7)"))

    zonas = {k: (b * fb, b * fe, e.longitud * fh, fc, b * ft)
             for k, (fb, fe, fh, fc, ft) in da.TABLA_2.items()}
    b_corona, s_corona = zonas["Corona"][0], zonas["Corona"][1]
    b_hastial, s_hastial = zonas["Hastial"][0], zonas["Hastial"][1]
    b_arr, s_arr = zonas["Arrastre"][0], zonas["Arrastre"][1]
    b_arriba, s_arriba = zonas["Ayuda (hacia arriba y horizontal)"][0:2]
    b_abajo, s_abajo = zonas["Ayuda (hacia abajo)"][0:2]

    # Zona útil para arranque y ayudas: sección menos la franja de contorno y de arrastres.
    # Si la sección es pequeña, la franja se reduce (los burdens son máximos) y se avisa.
    factor = 1.0
    anillo0 = None
    while factor >= 0.3 - 1e-9:
        anillo0 = _anillo(e, max(b_corona, b_hastial) * factor, b_arr * factor)
        if anillo0 is not None:
            break
        factor -= 0.05
    if anillo0 is None:
        raise calc.ErrorDeDatos(f"La sección {e.ancho:g} × {e.alto:g} m es demasiado pequeña "
                                f"para perforación de {e.diametro_mm:g} mm")
    if factor < 1.0 - 1e-9:
        r.avisos.append(f"Sección pequeña: las franjas de contorno y arrastre se redujeron al "
                        f"{factor * 100:.0f} % para que entre el arranque.")
    piso_util = b_arr * factor

    # ---------------- arranque (Ec. 3–6)
    rws = max(principal.prp, 1e-6)
    b1_ec3 = da.burden_primer_cuadro_practico(d0_eq, e.longitud, e.alfa, e.emboquille)
    b1_carga = da.burden_para_carga(q_real, dh, d0_eq, e.c_roca, rws) - f_err
    b1 = max(b1_ec3, b1_carga)
    origen_b1 = "1.7·D0 − (αH + β)  (Ec. 3)" if b1 == b1_ec3 else \
        "ajustado a la carga del explosivo (Ec. 4)"
    alivios_local = _alivios_agrupados(e.n_alivios, d0, f_err)
    # Regla física: los taladros no pueden solaparse (la desviación ya está en la Ec. 3)
    min_al = dh / 2 + d0 / 2 + 0.005
    min_cc = dh + 0.005

    def dmin(p, otros):
        return min((math.dist(p, o) for o in otros), default=float("inf"))

    b1_fisico = b1
    while not all(dmin((b1_fisico * math.cos(math.radians(a)), b1_fisico * math.sin(math.radians(a))),
                       alivios_local) >= min_al - 1e-9 for a in (45, 135, 225, 315)) \
            or math.sqrt(2) * b1_fisico < min_cc - 1e-9:
        b1_fisico += 0.002
    if b1_fisico > b1 + 1e-9:
        r.avisos.append(f"El burden del 1.er cuadro ({b1 * 1000:.0f} mm) dejaría taladros tocándose "
                        f"con el alivio; se usó {b1_fisico * 1000:.0f} mm.")
        b1, origen_b1 = b1_fisico, "separación física mínima"
    if b1_ec3 <= 0:
        r.avisos.append(f"Con la desviación indicada, la Ec. 3 da un burden negativo "
                        f"({b1_ec3 * 1000:.0f} mm): el alivio es pequeño para esta perforación.")
    q_nec = da.carga_necesaria_arranque(dh, b1 + f_err, d0_eq, e.c_roca, rws)
    ficha(FilaFicha("Arranque", "Burden 1.er cuadro B1", b1, "m", origen_b1))
    ficha(FilaFicha("Arranque", "Carga necesaria en el 1.er cuadro", q_nec, "kg/m",
                    "55·dh·(B/D0)^1.5·(B − D0/2)·(c/0.4)/RWS  (Ec. 4)"))

    limite = math.sqrt(avance)
    motivo_fin = ""
    cuadros = da.cuadros_arranque(b1, 6)
    # Como en las Fig. 10 y 11 del artículo, el arranque puede acercarse hasta ~0.5·B
    # de los arrastres y del contorno.
    anillo_corte = _anillo(e, 0.5 * max(b_corona, b_hastial) * factor, 0.5 * b_arr * factor) or anillo0
    piso_corte = 0.5 * b_arr * factor
    elegidos = 0
    h_c = None
    for n in range(1, 7):
        w_n = cuadros[n - 1][1]
        diagonal = n % 2 == 1  # cuadros impares: taladros en las esquinas (diagonales)
        semialto = w_n / 2 if diagonal else w_n / math.sqrt(2)
        # Como en las mallas estándar: el arranque a media altura de la zona útil;
        # si no cabe ahí, se baja hasta que quepa (como mínimo a 0.5·B de los arrastres).
        h_min = piso_corte + semialto
        h_medio = max(h_min, (piso_util + max(h for _s, h in anillo0)) / 2)
        hc_prueba = None
        h = h_medio
        while h >= h_min - 1e-9:
            puntos = _puntos_cuadro(n, cuadros, h)
            if all(_dentro(p, anillo_corte) or _en_borde(p, anillo_corte) for p in puntos):
                hc_prueba = h
                break
            h -= 0.02
        if hc_prueba is None:
            break
        elegidos, h_c = n, hc_prueba
        if w_n >= limite:
            break
        if n < 6 and cuadros[n][0] >= b_arriba:
            # El siguiente cuadro tendría un burden igual o mayor que el de las ayudas:
            # a partir de aquí la abertura ya es suficiente y el trabajo lo hacen las ayudas.
            motivo_fin = "burden_ayudas"
            break
    if elegidos == 0:
        raise calc.ErrorDeDatos("El arranque no cabe en la sección con estos diámetros")
    w_ultimo = cuadros[elegidos - 1][1]
    if motivo_fin == "burden_ayudas":
        ficha(FilaFicha("Arranque", "Fin del arranque", "B(n+1) ≥ B de ayudas", "",
                        "la abertura ya permite romper con ayudas"))
    elif w_ultimo < limite:
        r.avisos.append(f"El último cuadro del arranque mide {w_ultimo:.2f} m, menos que √I = "
                        f"{limite:.2f} m (regla del artículo): la sección no deja espacio para más.")
    for s_al, h_al in alivios_local:
        r.pozos.append(PozoAuto(s_al, h_c + h_al, "Alivio", 0.0, alivio=True, explosivo=""))
    taco_arr = 10 * dh
    for n in range(1, elegidos + 1):
        bn, wn = cuadros[n - 1]
        ficha(FilaFicha("Arranque", f"Cuadro {n}: burden / ancho", f"{bn:.3f} / {wn:.3f}", "m",
                        "B1, W1 = B1·√2" if n == 1 else "Bn = 0.7·W(n−1) ; Wn = 1.7·W(n−1)"))
        puntos = _puntos_cuadro(n, cuadros, h_c)
        r.cuadros.append(puntos)
        # Carga que necesita este cuadro (burden teórico = práctico + F):
        #   1.er cuadro: Ec. 4 ; siguientes: inversa de B = 0.088·√(A·q·PRP/(d·c)), A = W(n−1)
        b_teo = bn + f_err
        if n == 1:
            q_nec_n = da.carga_necesaria_arranque(dh, b_teo, d0_eq, e.c_roca, rws)
        else:
            q_nec_n = (b_teo / 0.088) ** 2 * dh * e.c_roca / (cuadros[n - 2][1] * rws)
        factor_n = min(1.0, q_nec_n / q_real) if q_real > 0 else 1.0
        ficha(FilaFicha("Arranque", f"Cuadro {n}: carga necesaria", q_nec_n, "kg/m",
                        f"{factor_n * 100:.0f} % de la columna" + (" (espaciar cartuchos)"
                                                                     if factor_n < 0.99 else "")))
        for s, h in puntos:
            r.pozos.append(PozoAuto(s, h, "Arranque", taco_arr, carga_fondo=0.0,
                                    factor_columna=round(factor_n, 3)))
    ficha(FilaFicha("Arranque", "Número de cuadros", elegidos, "", "hasta que W ≥ √I"))
    diagonal = elegidos % 2 == 1
    semi_corte = w_ultimo / 2 if diagonal else w_ultimo / math.sqrt(2)

    # ---------------- arrastres (piso)
    for s in _uniformes(-semi, semi, s_arr):
        r.pozos.append(PozoAuto(s, 0.0, "Arrastre", zonas["Arrastre"][4],
                                carga_fondo=zonas["Arrastre"][2], factor_columna=zonas["Arrastre"][3]))
    # ---------------- hastiales (paredes): entre el arrastre de la esquina (h = 0) y el
    # inicio del arco; esos dos extremos ya los ocupan el arrastre y la corona.
    alturas = _uniformes(0.0, hastial, s_hastial)[1:-1] if hastial > 0 else []
    for h in alturas:
        for s in (-semi, semi):
            r.pozos.append(PozoAuto(s, h, "Hastial", zonas["Hastial"][4], explosivo="contorno",
                                    carga_fondo=zonas["Hastial"][2], factor_columna=zonas["Hastial"][3]))
    # ---------------- corona (bóveda o techo plano), incluidos los extremos
    techo = [p for p in r.seccion[2:]] if e.flecha > 0 else [(semi, hastial), (-semi, hastial)]
    for s, h in _repartir(techo, s_corona, cerrada=False):
        r.pozos.append(PozoAuto(s, h, "Corona", zonas["Corona"][4], explosivo="contorno",
                                carga_fondo=zonas["Corona"][2], factor_columna=zonas["Corona"][3]))

    # ---------------- ayudas en filas y columnas alrededor del arranque
    cargados = lambda: [(p.s, p.h) for p in r.pozos if not p.alivio]  # noqa: E731
    sep_min = 0.5 * b

    caja_corte = r.cuadros[-1]  # último cuadro del arranque (zona que ya rompe el arranque)

    def poner(s, h, zona):
        if _dentro((s, h), caja_corte):
            return False
        if (_dentro((s, h), anillo_corte) or _en_borde((s, h), anillo_corte)) \
                and dmin((s, h), cargados()) >= max(sep_min, min_cc):
            z = zonas[zona]
            r.pozos.append(PozoAuto(s, h, "Ayuda", z[4], carga_fondo=z[2], factor_columna=z[3]))
            return True
        return False

    ayudas_antes = sum(1 for p in r.pozos if p.funcion == "Ayuda")
    # Ayudas en CUADRÍCULA alineada con el arranque (como en las mallas estándar de mina):
    #  - columnas a los lados del arranque, repartidas hasta la franja de los hastiales;
    #  - filas encima del arranque hasta la franja de la corona y debajo hasta la de arrastres;
    # separación ≤ B en ambos sentidos (Tabla 2: burden B; espaciamiento 1.1–1.2·B).
    def repartir_hasta(desde: float, hasta: float, paso: float) -> list[float]:
        hueco = hasta - desde
        if hueco <= 0.25 * paso:
            return []
        n = max(1, math.ceil(hueco / paso - 1e-9))
        return [desde + hueco * k / n for k in range(1, n + 1)]

    y_bajo, y_alto = h_c - semi_corte, h_c + semi_corte
    x_limite = _ancho_en(anillo0, h_c) or semi_corte
    columnas_fuera = repartir_hasta(semi_corte, x_limite, b_arriba)
    columnas_dentro = _uniformes(-semi_corte, semi_corte, s_abajo)
    columnas = sorted({round(x, 4) for x in columnas_dentro}
                      | {round(x, 4) for x in columnas_fuera}
                      | {round(-x, 4) for x in columnas_fuera})
    techo_util = max(h for _s, h in anillo0)
    filas_arriba = repartir_hasta(y_alto, techo_util, b_abajo)
    filas_abajo = [y_bajo - d for d in repartir_hasta(0.0, y_bajo - piso_util, b_arr)]
    filas_lado = _uniformes(y_bajo, y_alto, s_arriba)

    for h in sorted(set(filas_abajo) | set(filas_lado) | set(filas_arriba)):
        encima = h > y_alto + 1e-6
        zona_nombre = "Ayuda (hacia abajo)" if encima else "Ayuda (hacia arriba y horizontal)"
        zona_ok = anillo0 if encima else anillo_corte
        for x in [c for c in columnas if c >= -1e-9]:  # cada ayuda junto con su simétrica
            if abs(x) <= semi_corte + 1e-6 and y_bajo - 1e-6 <= h <= y_alto + 1e-6:
                continue  # dentro del arranque
            if not (_dentro((x, h), zona_ok) or _en_borde((x, h), zona_ok)):
                continue
            pareja = [(x, h)] if abs(x) < 1e-6 else [(x, h), (-x, h)]
            existentes = cargados()
            if all(dmin(p_, existentes) >= max(sep_min, min_cc) for p_ in pareja):
                z = zonas[zona_nombre]
                for s_p, h_p in pareja:
                    r.pozos.append(PozoAuto(s_p, h_p, "Ayuda", z[4], carga_fondo=z[2],
                                            factor_columna=z[3]))
    # Cobertura: en una malla B × S el punto más alejado queda a ~0.75·B del taladro más
    # cercano; ningún punto de la zona útil puede quedar más lejos que eso.
    _cubrir_huecos(r, anillo_corte, 0.75 * b, b, h_c, semi_corte, caja=caja_corte)
    for p in r.pozos:
        if p.funcion == "Ayuda" and p.carga_fondo is None:
            z = zonas["Ayuda (hacia arriba y horizontal)"]
            p.taco, p.carga_fondo, p.factor_columna = z[4], z[2], z[3]
    n_ayudas = sum(1 for p in r.pozos if p.funcion == "Ayuda") - ayudas_antes

    # ---------------- ficha por zonas (Tabla 2)
    for zona, (bz, sz, hb, fc, taco) in zonas.items():
        ficha(FilaFicha(zona, "Burden / espaciamiento", f"{bz:.2f} / {sz:.2f}", "m", "Tabla 2"))
        ficha(FilaFicha(zona, "Carga de fondo / columna",
                        f"{hb:.2f} m × {q_real:.2f} + {fc:.1f}·q", "", "Tabla 2"))
        ficha(FilaFicha(zona, "Retacado", taco, "m", "Tabla 2"))
    conteo = {}
    for p in r.pozos:
        conteo[p.funcion] = conteo.get(p.funcion, 0) + 1
    for funcion, cantidad in conteo.items():
        ficha(FilaFicha("Número de taladros", funcion, cantidad, ""))
    ficha(FilaFicha("Contorno", "Realce (look-out) máximo", da.realce_maximo(e.longitud), "m",
                    "0.10 + 0.03·H"))
    ficha(FilaFicha("Ayuda", "Número de taladros de ayuda", n_ayudas, ""))
    if ev_roca is not None:
        perimetro, dt, n_exsa = rc.taladros_exsa(area, ev_roca.dureza)
        diferencia = (len(r.pozos) - n_exsa) / n_exsa * 100
        ficha(FilaFicha("Comparación EXSA", f"Taladros según EXSA (roca {ev_roca.dureza.lower()})",
                        n_exsa, "", f"P/dt + k·S ; P = 4√S = {perimetro:.2f} m, dt = {dt} m"))
        ficha(FilaFicha("Comparación EXSA", "Taladros de este diseño", len(r.pozos), "",
                        f"{diferencia:+.0f} % respecto de EXSA"))
        if abs(diferencia) > 35:
            r.avisos.append(f"El diseño tiene {len(r.pozos)} taladros y la fórmula de EXSA da {n_exsa} "
                            f"({diferencia:+.0f} %): revisa explosivo, diámetro y datos de roca.")
    return r


def _puntos_cuadro(n: int, cuadros, h_c: float):
    """Taladros del cuadro n (1 = primero): impares en diagonales, pares sobre los ejes."""
    if n == 1:
        r_n = cuadros[0][0]  # B1, centro a centro desde el alivio
    else:
        w_prev = cuadros[n - 2][1]
        r_n = w_prev / 2 + cuadros[n - 1][0]  # W(n−1)/2 + Bn
    angulos = (45, 135, 225, 315) if n % 2 == 1 else (0, 90, 180, 270)
    return [(r_n * math.cos(math.radians(a)), h_c + r_n * math.sin(math.radians(a))) for a in angulos]


def _en_borde(punto, poligono, tolerancia: float = 1e-6) -> bool:
    x, y = punto
    n = len(poligono)
    for i in range(n):
        (x1, y1), (x2, y2) = poligono[i], poligono[(i + 1) % n]
        dx, dy = x2 - x1, y2 - y1
        largo2 = dx * dx + dy * dy
        if largo2 == 0:
            continue
        t = max(0.0, min(1.0, ((x - x1) * dx + (y - y1) * dy) / largo2))
        if math.hypot(x - (x1 + t * dx), y - (y1 + t * dy)) <= tolerancia:
            return True
    return False


def frente_a_pozos(r: ResultadoMalla, e: EntradaFrente, ids, x0: float, y0: float, z0: float,
                   azimut: float, explosivo_id: str | None, explosivo_contorno_id: str | None):
    from app.core.generador import _generador_ids

    nuevo_id = _generador_ids(ids)
    a = math.radians(azimut)

    def mundo(s, h):
        return (round(x0 + s * math.cos(a), 3), round(y0 - s * math.sin(a), 3), round(z0 + h, 3))

    pozos = []
    for p in r.pozos:
        x, y, z = mundo(p.s, p.h)
        ident = nuevo_id()
        exp_id = None if p.alivio else (explosivo_contorno_id if p.explosivo == "contorno"
                                         else explosivo_id)
        pozos.append(Perforacion(
            id=ident, nombre=ident, capa_id="perforaciones", x=x, y=y, z=z,
            azimut=azimut, inclinacion=0.0, longitud=e.longitud,
            diametro_mm=e.diametro_alivio_mm if p.alivio else e.diametro_mm,
            explosivo_id=exp_id, taco=round(min(p.taco, e.longitud), 3), funcion=p.funcion,
            carga_fondo=round(p.carga_fondo or 0.0, 3), factor_columna=p.factor_columna,
        ))
    return pozos, [mundo(s, h) for s, h in r.seccion]


# ======================================================================= banco
MODELOS_BANCO = ["Konya", "Ash", "Ash modificado", "Pearse", "Langefors"]


@dataclass
class EntradaBanco:
    largo: float = 30.0  # m, a lo largo de la cresta
    ancho: float = 12.0  # m, hacia dentro del banco
    altura_banco: float = 10.0  # m
    diametro_mm: float = 165.0
    densidad_roca: float = 2.6  # t/m³
    con_retardos: bool = True
    tresbolillo: bool = True
    modelo: str = "Konya"
    # Relaciones con el burden (Ash, diapositiva 26; se usan en Ash, Pearse y Langefors)
    kj: float = 0.3  # sobreperforación J = KJ·B (0.2–0.4)
    kt: float = 0.7  # taco T = KT·B (0.7–1.0)
    ks: float = 1.5  # espaciamiento S = KS·B (2 simultánea; 1 mucho retardo; 1.2–1.8 poco retardo)
    # Ash
    tipo_roca: str = "Media"  # Blanda / Media / Dura
    kb_manual: float = 0.0  # 0 = tomarlo de la Tabla I
    # Ash modificado (valores de referencia de la diapositiva 28)
    kb_estandar: float = 30.0
    densidad_roca_ref: float = 2.7
    densidad_exp_ref: float = 1.3
    vod_ref: float = 3657.0
    # Pearse
    rqd: float = 75.0  # %
    calidad_roca: str = "Media"  # Competente / Media / Suave / Muy suave → JSF
    std_mpa: float = 10.0  # resistencia a la tracción dinámica
    pd_mpa: float = 0.0  # 0 = estimar con ρ·VOD²/4
    # Langefors
    c_roca: float = 0.4
    inclinacion: str = "Vertical"  # Vertical / Inclinado 3:1 / Inclinado 2:1
    emboquille: float = 0.05  # m
    desviacion: float = 0.03  # m/m
    roca: Roca | None = None


def _burden_banco(e: EntradaBanco, exp: Explosivo, ficha) -> float:
    """Burden (m) según el modelo elegido; escribe en la ficha cómo se obtuvo."""
    if e.modelo == "Ash":
        clase = da.clase_explosivo_ash(exp.densidad_gcc)
        kb = e.kb_manual or da.KB_ASH[clase][e.tipo_roca]
        ficha(FilaFicha("Modelo de Ash", "Kb", kb, "",
                        "manual" if e.kb_manual else f"Tabla I: explosivo {clase}, roca {e.tipo_roca.lower()}"))
        b = da.burden_ash(kb, e.diametro_mm)
        ficha(FilaFicha("Modelo de Ash", "Burden", b, "m", "B = Kb·D/12 (pies, pulgadas)"))
        return b
    if e.modelo == "Ash modificado":
        if exp.vod_ms <= 0:
            raise calc.ErrorDeDatos("Indica la VOD del explosivo en Editar → Explosivos")
        kb1 = da.kb_ash_corregido(e.kb_estandar, e.densidad_roca_ref, e.densidad_roca,
                                  e.densidad_exp_ref, exp.densidad_gcc, e.vod_ref, exp.vod_ms)
        ficha(FilaFicha("Ash modificado", "Kb corregido", kb1, "",
                        "Kb·(dr1/dr2)^⅓·(SG2·V2²/SG1·V1²)^⅓"))
        b = da.burden_ash(kb1, e.diametro_mm)
        ficha(FilaFicha("Ash modificado", "Burden", b, "m", "B = Kb1·D/12"))
        return b
    if e.modelo == "Pearse":
        jsf = da.JSF_PEARSE[e.calidad_roca]
        k = da.factor_volabilidad_pearse(e.rqd, jsf)
        if e.pd_mpa > 0:
            pd, origen = e.pd_mpa, "dato"
        else:
            if exp.vod_ms <= 0:
                raise calc.ErrorDeDatos("Indica la VOD del explosivo o la presión de detonación")
            pd, origen = da.presion_detonacion_mpa(exp.densidad_gcc, exp.vod_ms), "ρ·VOD²/4"
        ficha(FilaFicha("Modelo de Pearse", "ERQD = RQD × JSF", e.rqd * jsf, "%", f"JSF = {jsf}"))
        ficha(FilaFicha("Modelo de Pearse", "Factor de volabilidad K", k, "", "1.96 − 0.27·ln(ERQD)"))
        ficha(FilaFicha("Modelo de Pearse", "Presión de detonación P2", pd, "MPa", origen))
        b = da.burden_pearse(k, e.diametro_mm, pd, e.std_mpa)
        ficha(FilaFicha("Modelo de Pearse", "Burden", b, "m", "B = K·D/12·√(P2/Std)"))
        if k <= 0:
            raise calc.ErrorDeDatos("El factor K resulta ≤ 0: revisa RQD y JSF")
        return b
    if e.modelo == "Langefors":
        f = da.F_FIJACION[e.inclinacion]
        bmax = da.burden_langefors(e.diametro_mm, exp.densidad_gcc, max(exp.prp, 1e-6),
                                   e.c_roca, f, e.ks)
        longitud = e.altura_banco + e.kj * bmax
        b = da.burden_practico_langefors(bmax, e.emboquille, e.desviacion, longitud)
        ficha(FilaFicha("Langefors", "Burden máximo", bmax, "m", "(D/33)·√(ρe·PRP/(c̄·f·S/B))"))
        ficha(FilaFicha("Langefors", "c̄ usado", da.c_langefors(e.c_roca, bmax), "kg/m³",
                        "c + 0.05 (B ≥ 1.4 m) · c + 0.07/B (B < 1.4 m)"))
        ficha(FilaFicha("Langefors", "Burden práctico", b, "m", "Bmax − e' − db·H"))
        if b <= 0:
            raise calc.ErrorDeDatos("El burden práctico resulta ≤ 0: revisa los errores de perforación")
        return b
    raise calc.ErrorDeDatos(f"Modelo desconocido: {e.modelo}")


def disenar_banco(e: EntradaBanco, explosivo: Explosivo | None) -> tuple[ResultadoMalla, ParamMallaTajo]:
    if explosivo is None:
        raise calc.ErrorDeDatos("Elige un explosivo (Editar → Explosivos para registrarlo)")
    for nombre, v in (("El largo", e.largo), ("El ancho", e.ancho)):
        if v <= 0:
            raise calc.ErrorDeDatos(f"{nombre} del área debe ser mayor que cero")
    r = ResultadoMalla()
    ficha = r.ficha.append
    if e.roca is not None:
        ev = evaluar_roca(e.roca)
        _ficha_roca(ficha, e.roca, ev)
        calidad = {"I": "Competente", "II": "Competente", "III": "Media", "IV": "Suave",
                   "V": "Muy suave"}[ev.clase]
        e = replace(e, c_roca=ev.c, rqd=e.roca.rqd, calidad_roca=calidad,
                    tipo_roca={"Dura": "Dura", "Semidura": "Media", "Blanda": "Blanda"}[ev.dureza],
                    densidad_roca=e.roca.densidad)
        ficha(FilaFicha("Roca", "Aplicado al modelo",
                        {"Konya": f"densidad {e.densidad_roca:g} t/m³",
                         "Ash": f"Tabla I, roca {e.tipo_roca.lower()}",
                         "Ash modificado": f"densidad {e.densidad_roca:g} t/m³",
                         "Pearse": f"RQD {e.rqd:g} %, JSF ({calidad.lower()})",
                         "Langefors": f"c = {ev.c:.3f}"}.get(e.modelo, ""), ""))
    if e.modelo == "Konya":
        b = da.burden_konya(e.diametro_mm, explosivo.densidad_gcc, e.densidad_roca)
        s = da.espaciamiento_konya(e.altura_banco, b, e.con_retardos)
        t = da.taco_konya(b)
        j = da.sobreperforacion_konya(b)
        ficha(FilaFicha("Malla", "Burden", b, "m", "0.012·(2ρe/ρr + 1.5)·De  (Konya)"))
        ficha(FilaFicha("Malla", "Espaciamiento", s, "m",
                        ("(H+7B)/8" if e.altura_banco / b < 4 else "1.4·B") if e.con_retardos
                        else ("(H+2B)/3" if e.altura_banco / b < 4 else "2·B")))
        formula_t, formula_j = "0.7·B", "0.3·B"
    else:
        b = _burden_banco(e, explosivo, ficha)
        s, t, j = e.ks * b, e.kt * b, e.kj * b
        ficha(FilaFicha("Malla", "Espaciamiento", s, "m", f"KS·B (KS = {e.ks:g})"))
        formula_t, formula_j = f"KT·B (KT = {e.kt:g})", f"KJ·B (KJ = {e.kj:g})"
        kl = (e.altura_banco + j) / b
        ficha(FilaFicha("Malla", "KL = L/B", kl, "", "recomendado 1.5–4"))
        if not 1.5 <= kl <= 4:
            r.avisos.append(f"KL = L/B = {kl:.2f}, fuera del rango 1.5–4 del modelo de Ash.")
    longitud = e.altura_banco + j
    filas = max(1, round(e.ancho / b))
    por_fila = max(1, round(e.largo / s) + 1)
    ficha(FilaFicha("Malla", "Relación de rigidez H/B", e.altura_banco / b, ""))
    ficha(FilaFicha("Taladro", "Taco", t, "m", formula_t))
    ficha(FilaFicha("Taladro", "Sobreperforación", j, "m", formula_j))
    ficha(FilaFicha("Taladro", "Longitud de perforación", longitud, "m", "H + J"))
    ficha(FilaFicha("Malla", "Filas × taladros por fila", f"{filas} × {por_fila}", ""))
    if e.altura_banco / b < 1.5:
        r.avisos.append("H/B < 1.5: banco muy bajo para este diámetro (riesgo de proyecciones "
                        "y mala fragmentación). Considera un diámetro menor.")
    if t >= longitud:
        raise calc.ErrorDeDatos("El taco es mayor que el taladro: revisa KT o la altura de banco")
    q = calc.carga_lineal(explosivo.diametro_de_carga(e.diametro_mm), explosivo.densidad_gcc)
    ficha(FilaFicha("Taladro", "Carga lineal", q, "kg/m"))
    param = ParamMallaTajo(filas=filas, pozos_por_fila=por_fila, burden=round(b, 2),
                           espaciamiento=round(s, 2), tresbolillo=e.tresbolillo,
                           longitud=round(longitud, 2), diametro_mm=e.diametro_mm,
                           taco=round(t, 2), explosivo_id=explosivo.id)
    for x, y, _f in posiciones_tajo(param):
        r.pozos.append(PozoAuto(x, y, "Producción", t))
    return r, param
