"""
Equipos de perforación subterránea y selección según la labor.

Catálogo con datos publicados por los fabricantes (hojas técnicas / páginas de producto) y por la clase
S-6 de Perforación y Voladura (jackleg y stoper). TODO es editable: los valores del usuario se guardan
en ~/.barreno3d/equipos.json y reemplazan a los del catálogo.

Criterio de selección (no hay un límite universal; se compara la labor con cada equipo):
- Chimenea (perforación hacia arriba): stoper.
- Tajeo de corte y relleno (perforación horizontal en vetas angostas): jackleg (práctica descrita en la
  tesis de tajeos de Retamas); si el usuario lo permite, un jumbo que quepa.
- Frente de avance: el jumbo más pequeño que cabe en la sección (ancho y alto mínimos de la labor) y
  cuya cobertura abarca la sección; si ninguno cabe, jackleg. El motivo se explica siempre.
Sección mínima de un jumbo: la que da el fabricante si la publica (p. ej. DD311: 3.0 × 3.0 m); si no,
ancho de transporte + 2 × holgura lateral y alto (techo bajo) + holgura superior. Las holguras por
defecto (0.49 m por lado y 0.86 m arriba) salen de comparar el DD311 (2.02 m de ancho, 2.14 m de alto
con techo bajo) con su sección mínima publicada de 3.0 × 3.0 m; se pueden cambiar.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields, replace
from pathlib import Path

TIPOS = {"jumbo": "Jumbo electrohidráulico", "jackleg": "Perforadora manual con barra de avance (jackleg)",
         "stoper": "Perforadora stoper (perforación hacia arriba)"}
LABORES = {"frente": "Frente de avance (galería, crucero, rampa, by-pass)", "chimenea": "Chimenea",
           "tajeo": "Tajeo (corte y relleno, perforación horizontal)"}

HOLGURA_LATERAL = 0.49  # m por lado (DD311: (3.00 − 2.02)/2)
HOLGURA_SUPERIOR = 0.86  # m (DD311: 3.00 − 2.14)

ARCHIVO_USUARIO = Path.home() / ".barreno3d" / "equipos.json"


@dataclass
class Equipo:
    clave: str
    nombre: str
    tipo: str  # jumbo / jackleg / stoper
    brazos: int = 1
    ancho: float = 0.0  # m (ancho de transporte; 0 = equipo manual)
    alto: float = 0.0  # m (techo/canopy abajo)
    largo: float = 0.0  # m
    seccion_min_ancho: float | None = None  # m (si el fabricante la publica)
    seccion_min_alto: float | None = None
    seccion_max_ancho: float | None = None  # m (cobertura máxima publicada)
    seccion_max_alto: float | None = None
    cobertura_m2: float | None = None
    diametro_min_mm: float = 27.0
    diametro_max_mm: float = 64.0
    long_perforacion_max: float = 4.0  # m (con una barra / viga)
    resistencia_mpa: tuple[float, float] | None = None  # rango de roca recomendado
    labores: list[str] = field(default_factory=lambda: ["frente"])
    fuente: str = ""
    nota: str = ""

    def seccion_minima(self) -> tuple[float, float]:
        if self.seccion_min_ancho and self.seccion_min_alto:
            return self.seccion_min_ancho, self.seccion_min_alto
        if self.tipo != "jumbo":
            return (self.seccion_min_ancho or 0.0), (self.seccion_min_alto or 0.0)
        return self.ancho + 2 * HOLGURA_LATERAL, self.alto + HOLGURA_SUPERIOR

    def descripcion_corta(self) -> str:
        if self.tipo == "jumbo":
            a, h = self.seccion_minima()
            return f"{self.nombre} — {self.brazos} brazo(s), sección mínima {a:.2f} × {h:.2f} m"
        return f"{self.nombre} — Ø {self.diametro_min_mm:.0f}–{self.diametro_max_mm:.0f} mm"


CATALOGO: list[Equipo] = [
    Equipo("dd211l", "Sandvik DD211L (perfil bajo)", "jumbo", 1, ancho=2.26, alto=1.38, largo=13.0,
           seccion_min_alto=1.7, cobertura_m2=36, diametro_min_mm=43, diametro_max_mm=64, long_perforacion_max=4.66,
           fuente="Sandvik, hoja técnica DD211L: altura libre desde 1.7 m; ancho de transporte 2 260 mm; "
                  "alto 1 380/1 950 mm; cobertura 36 m²; taladro hasta 4 660 mm",
           nota="Para mantos bajos; el ancho mínimo se calcula con la holgura lateral."),
    Equipo("boomer281", "Epiroc Boomer 281", "jumbo", 1, ancho=1.65, alto=2.10, largo=10.7,
           seccion_max_ancho=6.0, seccion_max_alto=6.0, cobertura_m2=31, diametro_min_mm=43, diametro_max_mm=64,
           long_perforacion_max=3.4,
           fuente="Epiroc/Atlas Copco, Boomer 281: ancho de transporte 1.65 m; galerías hasta 6 × 6 m; "
                  "taladro de 3 405 mm con viga BMH 2831",
           nota="Alto con techo bajo tomado de las medidas de la hoja técnica (≈ 2.1 m)."),
    Equipo("dd311", "Sandvik DD311", "jumbo", 1, ancho=2.02, alto=2.14, largo=12.52,
           seccion_min_ancho=3.0, seccion_min_alto=3.0, seccion_max_ancho=7.2, seccion_max_alto=5.8,
           cobertura_m2=40, diametro_min_mm=43, diametro_max_mm=64, long_perforacion_max=4.66,
           fuente="Sandvik, hoja técnica DD311/DD311D: galería mínima (H × A) 3 000 × 3 000 mm; cobertura 40 m² "
                  "(5.8 × 7.2 m); ancho de transporte 2 020 mm; alto con canopy 2 140 mm; taladro hasta 4 660 mm"),
    Equipo("boomer282", "Epiroc Boomer 282", "jumbo", 2, ancho=1.99, alto=2.30, largo=11.83,
           seccion_max_ancho=8.7, seccion_max_alto=6.3, cobertura_m2=45, diametro_min_mm=43, diametro_max_mm=64,
           long_perforacion_max=4.0,
           fuente="Epiroc, Boomer 282: dos brazos; cobertura hasta 45 m²; galerías hasta 8.7 × 6.3 m; "
                  "ancho 1 990 mm; largo 11 830 mm (BMH 2843)"),
    Equipo("boomerl20", "Epiroc Boomer L20", "jumbo", 2, ancho=2.55, alto=2.58, largo=14.5,
           cobertura_m2=104, diametro_min_mm=43, diametro_max_mm=64, long_perforacion_max=5.5,
           fuente="Epiroc, Boomer L20: cobertura 71–104 m²; ancho de transporte 2 550 mm; largo 14 500 mm; "
                  "alto mínimo con techo protector 2 582 mm",
           nota="Largo de perforación según la viga elegida (editable)."),
    Equipo("jackleg", "Jackleg (p. ej. Epiroc RH 656 W / BBD 94 W / BBC 16 W)", "jackleg", 1,
           seccion_min_ancho=1.2, seccion_min_alto=1.5, diametro_min_mm=27, diametro_max_mm=41,
           long_perforacion_max=2.44, resistencia_mpa=(0, 400), labores=["frente", "tajeo"],
           fuente="Clase S-6 PyV (Epiroc, Underground Drilling): jackleg Ø 27–41 mm; RH 656 W roca blanda "
                  "(< 100 MPa), BBD 94 W media (100–200 MPa), BBC 16 W dura (200–400 MPa)",
           nota="Sección mínima y largo de barra (8') son valores editables: dependen del espacio que necesita "
                "el perforista y de las barras disponibles (E-MIN-8 usa barras cónicas de 4' y 6')."),
    Equipo("stoper", "Stoper (p. ej. Epiroc BBD 46 WS)", "stoper", 1, seccion_min_ancho=1.2, seccion_min_alto=1.2,
           diametro_min_mm=27, diametro_max_mm=41, long_perforacion_max=1.83, labores=["chimenea"],
           fuente="Clase S-6 PyV: stoper para chimeneas, realces y pernos, Ø 27–41 mm; E-MIN-8 (Retamas): "
                  "chimeneas de 5'×5' y 8'×5' con barras de 4' y 6'"),
]


def _cargar_usuario() -> dict:
    try:
        return json.loads(ARCHIVO_USUARIO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def catalogo() -> list[Equipo]:
    """Catálogo con los cambios del usuario aplicados."""
    cambios = _cargar_usuario()
    nombres = {f.name for f in fields(Equipo)}
    lista = []
    for e in CATALOGO:
        c = cambios.get(e.clave, {})
        lista.append(replace(e, **{k: (tuple(v) if k == "resistencia_mpa" and v else v)
                                   for k, v in c.items() if k in nombres and k != "clave"}))
    for clave, c in cambios.items():  # equipos agregados por el usuario
        if clave not in {e.clave for e in CATALOGO} and isinstance(c, dict):
            try:
                lista.append(Equipo(**{k: v for k, v in c.items() if k in nombres}))
            except TypeError:
                pass
    return lista


def guardar_cambios(equipos: list[Equipo]) -> None:
    def _norm(e):  # tuplas y listas se comparan igual
        return json.loads(json.dumps(asdict(e)))
    base = {e.clave: _norm(e) for e in CATALOGO}
    cambios = {}
    for e in equipos:
        d = _norm(e)
        b = base.get(e.clave)
        dif = {k: v for k, v in d.items() if b is None or b.get(k) != v}
        if dif:
            cambios[e.clave] = dif if b is not None else d
    ARCHIVO_USUARIO.parent.mkdir(parents=True, exist_ok=True)
    ARCHIVO_USUARIO.write_text(json.dumps(cambios, ensure_ascii=False, indent=1), encoding="utf-8")


@dataclass
class Seleccion:
    equipo: Equipo
    motivo: str
    evaluados: list[tuple[Equipo, bool, str]] = field(default_factory=list)
    avisos: list[str] = field(default_factory=list)


def evaluar(e: Equipo, ancho: float, alto: float, labor: str, longitud: float | None,
            diametro: float | None) -> tuple[bool, str]:
    if labor not in e.labores:
        return False, f"no se usa en {LABORES.get(labor, labor).split(' (')[0].lower()}"
    amin, hmin = e.seccion_minima()
    if ancho + 1e-9 < amin or alto + 1e-9 < hmin:
        return False, f"necesita al menos {amin:.2f} × {hmin:.2f} m"
    if e.seccion_max_ancho and e.seccion_max_alto and (ancho > e.seccion_max_ancho + 1e-9 or alto > e.seccion_max_alto + 1e-9):
        return False, f"su cobertura llega a {e.seccion_max_ancho:.1f} × {e.seccion_max_alto:.1f} m"
    if e.tipo == "jumbo" and e.cobertura_m2 and ancho * alto * 0.85 > e.cobertura_m2 + 1e-9:
        return False, f"la sección (≈ {ancho * alto * 0.85:.0f} m²) supera su cobertura de {e.cobertura_m2:.0f} m²"
    notas = []
    if diametro and not e.diametro_min_mm - 1e-9 <= diametro <= e.diametro_max_mm + 1e-9:
        if e.tipo != "jumbo":  # un jackleg/stoper no perfora fuera de su rango
            return False, f"perfora Ø {e.diametro_min_mm:.0f}–{e.diametro_max_mm:.0f} mm"
        notas.append(f"Ø {diametro:.0f} mm fuera del rango habitual del equipo ({e.diametro_min_mm:.0f}–"
                     f"{e.diametro_max_mm:.0f} mm): revisa brocas y barras")
    if longitud and longitud > e.long_perforacion_max + 1e-9:
        notas.append(f"taladro de {longitud:.2f} m > {e.long_perforacion_max:.2f} m: requiere barras de extensión")
    return True, "; ".join(notas)


def seleccionar(ancho: float, alto: float, labor: str = "frente", longitud: float | None = None,
                diametro: float | None = None, equipos: list[Equipo] | None = None,
                forzar: str | None = None) -> Seleccion:
    """Equipo recomendado para la labor (o el elegido con «forzar», con su evaluación)."""
    equipos = equipos or catalogo()
    ev = [(e, *evaluar(e, ancho, alto, labor, longitud, diametro)) for e in equipos]
    if forzar:
        e, ok, m = next(((e, ok, m) for e, ok, m in ev if e.clave == forzar), (None, False, ""))
        if e is not None:
            av = [] if ok else [f"{e.nombre}: {m} (elegido por el usuario)"]
            if ok and m:
                av.append(m)
            return Seleccion(e, "elegido por el usuario", ev, av)
    sec = f"{ancho:.2f} × {alto:.2f} m"
    if labor == "chimenea":
        e = next((e for e, ok, _ in ev if ok and e.tipo == "stoper"), None)
        if e:
            return Seleccion(e, f"chimenea de {sec}: perforación hacia arriba con stoper", ev,
                             [m for x, ok, m in ev if x is e and m])
    if labor == "tajeo":
        e = next((e for e, ok, _ in ev if ok and e.tipo == "jackleg"), None)
        if e:
            return Seleccion(e, f"tajeo de {sec}: perforación horizontal con jackleg", ev,
                             [m for x, ok, m in ev if x is e and m])
    jumbos = sorted([(e, m) for e, ok, m in ev if ok and e.tipo == "jumbo"],
                    key=lambda p: (p[0].cobertura_m2 or 99, -p[0].brazos))
    if jumbos and labor == "frente":
        # dos brazos solo si la sección lo justifica (≥ 12 m² de cobertura útil)
        dos = [p for p in jumbos if p[0].brazos >= 2]
        e, m = dos[0] if dos and ancho * alto >= 12.0 else jumbos[0]
        return Seleccion(e, f"frente de {sec}: cabe el jumbo ({e.seccion_minima()[0]:.2f} × "
                            f"{e.seccion_minima()[1]:.2f} m mínimo)", ev, [m] if m else [])
    manual = next((e for e, ok, _ in ev if ok and e.tipo == "jackleg"), None)
    rechazos = "; ".join(f"{e.nombre}: {m}" for e, ok, m in ev if e.tipo == "jumbo" and not ok)
    if manual:
        motivo = f"{LABORES.get(labor, labor).split(' (')[0].lower()} de {sec}: ningún jumbo del catálogo cabe" \
                 + (f" ({rechazos})" if rechazos else "") + " → jackleg"
        return Seleccion(manual, motivo, ev, [m for x, ok, m in ev if x is manual and m])
    # nada cabe: se devuelve el jackleg con aviso
    j = next((e for e in equipos if e.tipo == "jackleg"), equipos[0])
    _, m = evaluar(j, ancho, alto, "frente", longitud, diametro)
    return Seleccion(j, f"sección {sec} fuera de los rangos del catálogo", ev,
                     [f"{j.nombre}: {m}" if m else "revisa los rangos del catálogo de equipos"])


# =========================================================================== scoop (LHD) para la limpieza
@dataclass
class Scoop:
    clave: str
    nombre: str
    ancho: float          # m, ancho total con balde
    alto: float           # m, altura al techo de la cabina / ROPS
    largo: float          # m, largo en posición de acarreo
    balde_m3: float
    ancho_balde: float
    carga_kg: float
    fuente: str
    estimado: str = ""    # medidas no publicadas en la ficha consultada (dibujo aproximado)

    def seccion_minima(self) -> tuple[float, float]:
        return (round(self.ancho + 2 * HOLGURA_SCOOP_LADO, 2), round(self.alto + HOLGURA_SCOOP_TECHO, 2))


# Holguras para que el scoop circule y cargue (editables; no son una norma).
HOLGURA_SCOOP_LADO = 0.45
HOLGURA_SCOOP_TECHO = 0.35

CATALOGO_SCOOP = [
    Scoop("st2g", "Epiroc Scooptram ST2G (1.9 m³)", ancho=1.663, alto=2.1, largo=7.3, balde_m3=1.9, ancho_balde=1.663,
          carga_kg=4000, fuente="Epiroc, especificación técnica Scooptram ST2G (ancho de balde 1663 mm, carga 4000 kg)",
          estimado="alto y largo aproximados para el dibujo (no figuran en la hoja consultada)"),
    Scoop("r1300g", "Cat R1300G (2.8 m³)", ancho=2.185, alto=2.12, largo=8.707, balde_m3=2.8, ancho_balde=2.01,
          carga_kg=6800, fuente="Cat R1300G, especificaciones: ancho con balde 2185 mm, altura al ROPS 2120 mm, "
                                "largo de acarreo 8707 mm; balde 2.8 m³ (2010 mm)"),
    Scoop("r1700", "Cat R1700 (5.7 m³)", ancho=2.86, alto=2.541, largo=10.806, balde_m3=5.7, ancho_balde=2.83,
          carga_kg=15000, fuente="Cat, línea de productos de minería subterránea (R1700: ancho 2860, alto 2541, "
                                 "largo 10 806 mm); balde 5.7–7.5 m³, carga 15 000 kg"),
]


def seleccionar_scoop(ancho: float, alto: float) -> tuple[Scoop | None, str]:
    """El scoop más grande que entra con holgura en la sección (más balde = menos ciclos)."""
    caben = [s for s in CATALOGO_SCOOP if s.seccion_minima()[0] <= ancho + 1e-9 and s.seccion_minima()[1] <= alto + 1e-9]
    if not caben:
        chico = min(CATALOGO_SCOOP, key=lambda s: s.ancho)
        a, h = chico.seccion_minima()
        return None, (f"Ningún scoop del catálogo entra: el más pequeño ({chico.nombre}) necesita ≈ {a:.2f} × {h:.2f} m. "
                      "La limpieza sería con pala neumática y carros mineros o con winche de arrastre.")
    s = max(caben, key=lambda s: s.balde_m3)
    a, h = s.seccion_minima()
    return s, f"{s.nombre}: necesita ≈ {a:.2f} × {h:.2f} m (ancho {s.ancho:.2f} m + {HOLGURA_SCOOP_LADO} m por lado)."
